#!/usr/bin/env python3
"""Collect official YouTube Data API v3 public data for shortlist B (second 30 brands).

The API key is read from YOUTUBE_API_KEY and sent only as x-goog-api-key.
It is never written to files, logs, or URLs.

Writes only to youtube_data_api_b/ and a collection-specific quota file
inside that folder. Does not write to youtube_data_api/ or quota_units.json.
"""
from __future__ import annotations

import csv
import json
import re
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo

sys.path.insert(0, str(Path(__file__).resolve().parent))
from youtube_api_client import (  # noqa: E402
    OUT,
    TASK_QUOTA_CAP,
    YouTubeClient,
    now_hkt,
)

HKT = ZoneInfo("Asia/Hong_Kong")
DEST = OUT / "youtube_data_api_b"
SHORTLIST = OUT / "shortlist_30_b.csv"
QUOTA_PATH_B = DEST / "quota_units.json"
VIDEO_CUTOFF = datetime(2023, 11, 21, tzinfo=timezone.utc)
COMMENT_CUTOFF = datetime(2025, 11, 21, tzinfo=timezone.utc)
MAX_VIDEOS_PER_CHANNEL = 2000
MAX_COMMENT_VIDEOS = 30
SLEEP_S = 0.12

CHANNEL_FIELDS = [
    "brand","channel_role","official_status","channel_id","handle","channel_url",
    "channel_title","custom_url","country","published_at","subscriber_count",
    "hidden_subscriber_count","video_count","channel_view_count","uploads_playlist_id",
    "retrieved_at_hkt",
]
VIDEO_FIELDS = [
    "brand","channel_id","channel_title","video_id","video_url","title","published_at",
    "duration_iso","duration_seconds","view_count","like_count","comment_count",
    "privacy_status","made_for_kids","category_id","tags_count","retrieved_at_hkt",
]
COMMENT_FIELDS = [
    "brand","channel_id","video_id","comment_id","parent_id","author_display_name",
    "text","like_count","reply_count","published_at","updated_at","retrieved_at_hkt",
]


def parse_iso(ts: str | None) -> datetime | None:
    if not ts:
        return None
    try:
        if ts.endswith("Z"):
            return datetime.fromisoformat(ts.replace("Z", "+00:00"))
        return datetime.fromisoformat(ts)
    except ValueError:
        return None


def duration_seconds(iso: str | None) -> int | None:
    if not iso:
        return None
    m = re.fullmatch(r"P(?:(\d+)D)?(?:T(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?)?", iso)
    if not m:
        return None
    d, h, mi, s = (int(x) if x else 0 for x in m.groups())
    return d * 86400 + h * 3600 + mi * 60 + s


def to_int(value: Any) -> int | None:
    if value is None or value == "":
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def write_csv(path: Path, rows: list[dict[str, Any]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        for row in rows:
            w.writerow({k: "" if row.get(k) is None else row.get(k) for k in fields})


def flatten_comments(threads: list[dict], brand: str, channel_id: str, video_id: str, retrieved: str) -> list[dict]:
    out = []
    for th in threads:
        top = ((th.get("snippet") or {}).get("topLevelComment") or {})
        tsn = top.get("snippet") or {}
        cid = top.get("id") or th.get("id")
        if cid:
            out.append({
                "brand": brand,
                "channel_id": channel_id,
                "video_id": video_id,
                "comment_id": cid,
                "parent_id": "",
                "author_display_name": tsn.get("authorDisplayName"),
                "text": tsn.get("textDisplay") or tsn.get("textOriginal"),
                "like_count": to_int(tsn.get("likeCount")),
                "reply_count": to_int((th.get("snippet") or {}).get("totalReplyCount")),
                "published_at": tsn.get("publishedAt"),
                "updated_at": tsn.get("updatedAt"),
                "retrieved_at_hkt": retrieved,
            })
        for rep in ((th.get("replies") or {}).get("comments") or []):
            rsn = rep.get("snippet") or {}
            out.append({
                "brand": brand,
                "channel_id": channel_id,
                "video_id": video_id,
                "comment_id": rep.get("id"),
                "parent_id": rsn.get("parentId") or cid,
                "author_display_name": rsn.get("authorDisplayName"),
                "text": rsn.get("textDisplay") or rsn.get("textOriginal"),
                "like_count": to_int(rsn.get("likeCount")),
                "reply_count": "",
                "published_at": rsn.get("publishedAt"),
                "updated_at": rsn.get("updatedAt"),
                "retrieved_at_hkt": retrieved,
            })
    return out


def persist(channels, videos, comments, coverage, errors, units, note=""):
    DEST.mkdir(parents=True, exist_ok=True)
    write_csv(DEST / "channels.csv", channels, CHANNEL_FIELDS)
    write_csv(DEST / "videos.csv", videos, VIDEO_FIELDS)
    write_csv(DEST / "comments.csv", comments, COMMENT_FIELDS)
    (DEST / "channels.json").write_text(json.dumps(channels, ensure_ascii=False, indent=2) + "\n")
    (DEST / "videos.json").write_text(json.dumps(videos, ensure_ascii=False, indent=2) + "\n")
    (DEST / "comments.json").write_text(json.dumps(comments, ensure_ascii=False, indent=2) + "\n")
    (DEST / "coverage.json").write_text(json.dumps(coverage, ensure_ascii=False, indent=2) + "\n")
    (DEST / "errors.json").write_text(json.dumps(errors, ensure_ascii=False, indent=2) + "\n")
    (DEST / "quota_snapshot.json").write_text(
        json.dumps(
            {
                "units_used_this_task": units,
                "task_cap": TASK_QUOTA_CAP,
                "note": note,
                "at_hkt": now_hkt(),
            },
            indent=2,
        )
        + "\n"
    )


def present_nonzero_comment_count(value: Any) -> bool:
    """True only when comment_count is present and not zero. Missing is not zero."""
    if value is None or value == "":
        return False
    n = to_int(value)
    return n is not None and n != 0


def main() -> int:
    if not SHORTLIST.exists():
        raise SystemExit(f"missing shortlist: {SHORTLIST}")
    short = list(csv.DictReader(SHORTLIST.open()))
    DEST.mkdir(parents=True, exist_ok=True)
    client = YouTubeClient(
        reserve_for_collection=0,
        quota_path=QUOTA_PATH_B,
        load_previous=False,
    )
    retrieved = now_hkt()
    print(
        f"start collection B brands={len(short)} units_already={client.units_used} cap={TASK_QUOTA_CAP} dest={DEST}",
        flush=True,
    )

    channels_out: list[dict[str, Any]] = []
    videos_out: list[dict[str, Any]] = []
    comments_out: list[dict[str, Any]] = []
    coverage: list[dict[str, Any]] = []
    errors: list[dict[str, Any]] = []
    comment_candidates: dict[str, list[dict[str, Any]]] = {}

    # Batch channels.list (1 unit for up to 50 ids)
    ids = [r["channel_id"] for r in short]
    data = client.channels_by_id(",".join(ids))
    if data.get("_error"):
        errors.append({
            "at_hkt": now_hkt(),
            "endpoint": "channels",
            "message": data.get("_error"),
            "reason": data.get("_reason"),
            "status": data.get("_http_status"),
        })
    items = {it["id"]: it for it in (data.get("items") or [])}

    for meta in short:
        cid = meta["channel_id"]
        item = items.get(cid)
        if not item:
            errors.append({
                "at_hkt": now_hkt(),
                "endpoint": "channels",
                "reason": "not_returned",
                "params": {"id": cid},
                "message": meta["brand"],
            })
            print(f"MISSING channel {meta['brand']}", flush=True)
            continue
        snippet = item.get("snippet") or {}
        stats = item.get("statistics") or {}
        content = item.get("contentDetails") or {}
        uploads = ((content.get("relatedPlaylists") or {}).get("uploads")) or ""
        channel_row = {
            "brand": meta["brand"],
            "channel_role": "primary",
            "official_status": "official",
            "channel_id": cid,
            "handle": meta["youtube_handle"],
            "channel_url": meta["youtube_url"],
            "channel_title": snippet.get("title"),
            "custom_url": snippet.get("customUrl"),
            "country": snippet.get("country"),
            "published_at": snippet.get("publishedAt"),
            "subscriber_count": to_int(stats.get("subscriberCount")),
            "hidden_subscriber_count": bool(stats.get("hiddenSubscriberCount")),
            "video_count": to_int(stats.get("videoCount")),
            "channel_view_count": to_int(stats.get("viewCount")),
            "uploads_playlist_id": uploads,
            "retrieved_at_hkt": retrieved,
        }
        channels_out.append(channel_row)

        listed = 0
        in_window: list[str] = []
        published_map: dict[str, str] = {}
        truncated = False
        reached_cutoff = False
        pages = 0
        page_token = None
        if not uploads:
            coverage.append({
                "brand": meta["brand"],
                "channel_id": cid,
                "uploads_playlist_id": "",
                "playlist_pages": 0,
                "videos_listed": 0,
                "videos_in_window": 0,
                "comment_videos_attempted": 0,
                "comments": 0,
                "truncated_at_cap": False,
                "reached_cutoff": False,
                "note": "No uploads playlist id",
            })
            continue

        try:
            while len(in_window) < MAX_VIDEOS_PER_CHANNEL:
                if client.remaining() < 80:
                    raise RuntimeError("quota_headroom")
                page = client.playlist_items(uploads, page_token=page_token, max_results=50)
                pages += 1
                time.sleep(SLEEP_S)
                if page.get("_error"):
                    errors.append({
                        "at_hkt": now_hkt(),
                        "endpoint": "playlistItems",
                        "brand": meta["brand"],
                        "reason": page.get("_reason"),
                        "message": page.get("_error"),
                        "status": page.get("_http_status"),
                    })
                    break
                batch = page.get("items") or []
                if not batch:
                    reached_cutoff = True
                    break
                stop = False
                for it in batch:
                    listed += 1
                    vid = ((it.get("contentDetails") or {}).get("videoId")) or ((it.get("snippet") or {}).get("resourceId") or {}).get("videoId")
                    pub = (it.get("contentDetails") or {}).get("videoPublishedAt") or (it.get("snippet") or {}).get("publishedAt")
                    dt = parse_iso(pub)
                    if dt is not None and dt < VIDEO_CUTOFF:
                        reached_cutoff = True
                        stop = True
                        break
                    if vid and vid not in published_map:
                        in_window.append(vid)
                        published_map[vid] = pub or ""
                        if len(in_window) >= MAX_VIDEOS_PER_CHANNEL:
                            truncated = True
                            stop = True
                            break
                if stop:
                    break
                page_token = page.get("nextPageToken")
                if not page_token:
                    reached_cutoff = True
                    break
        except Exception as e:
            errors.append({
                "at_hkt": now_hkt(),
                "endpoint": "playlistItems",
                "brand": meta["brand"],
                "message": type(e).__name__ + (f": {e}" if str(e) else ""),
            })
            if str(e) == "quota_headroom" or e.__class__.__name__ == "QuotaExceeded":
                persist(channels_out, videos_out, comments_out, coverage, errors, client.units_used, "stopped early")
                print(f"STOP during playlist {meta['brand']} units={client.units_used}", flush=True)
                break

        # videos.list in chunks of 50
        brand_videos = []
        for i in range(0, len(in_window), 50):
            chunk = in_window[i:i+50]
            vdata = client.videos_list(chunk)
            time.sleep(SLEEP_S)
            if vdata.get("_error"):
                errors.append({
                    "at_hkt": now_hkt(),
                    "endpoint": "videos",
                    "brand": meta["brand"],
                    "reason": vdata.get("_reason"),
                    "message": vdata.get("_error"),
                    "status": vdata.get("_http_status"),
                })
                continue
            for v in vdata.get("items") or []:
                st = v.get("statistics") or {}
                sn = v.get("snippet") or {}
                cd = v.get("contentDetails") or {}
                status = v.get("status") or {}
                iso = cd.get("duration")
                row = {
                    "brand": meta["brand"],
                    "channel_id": cid,
                    "channel_title": snippet.get("title"),
                    "video_id": v.get("id"),
                    "video_url": f"https://www.youtube.com/watch?v={v.get('id')}",
                    "title": sn.get("title"),
                    "published_at": sn.get("publishedAt"),
                    "duration_iso": iso,
                    "duration_seconds": duration_seconds(iso),
                    "view_count": to_int(st["viewCount"]) if "viewCount" in st else None,
                    "like_count": to_int(st["likeCount"]) if "likeCount" in st else None,
                    "comment_count": to_int(st["commentCount"]) if "commentCount" in st else None,
                    "privacy_status": status.get("privacyStatus"),
                    "made_for_kids": status.get("madeForKids"),
                    "category_id": sn.get("categoryId"),
                    "tags_count": len(sn.get("tags") or []),
                    "retrieved_at_hkt": retrieved,
                }
                brand_videos.append(row)
                videos_out.append(row)

        # Comment sample: videos on/after COMMENT_CUTOFF with a present non-zero comment_count
        recent = []
        for row in brand_videos:
            dt = parse_iso(row.get("published_at"))
            if dt is not None and dt >= COMMENT_CUTOFF and present_nonzero_comment_count(row.get("comment_count")):
                recent.append(row)
        recent.sort(key=lambda r: r.get("published_at") or "", reverse=True)
        comment_candidates[meta["brand"]] = recent[:MAX_COMMENT_VIDEOS]

        n_window = len(brand_videos)
        n_like_missing = sum(1 for r in brand_videos if "like_count" not in r or r.get("like_count") is None)
        n_comment_missing = sum(1 for r in brand_videos if r.get("comment_count") is None)
        note_parts = []
        if n_window and n_like_missing:
            note_parts.append(f"{n_like_missing}/{n_window} videos missing like_count")
        if n_window and n_comment_missing:
            note_parts.append(f"{n_comment_missing}/{n_window} videos missing comment_count (omitted, not zero)")

        cov = {
            "brand": meta["brand"],
            "channel_id": cid,
            "uploads_playlist_id": uploads,
            "playlist_pages": pages,
            "videos_listed": listed,
            "videos_in_window": n_window,
            "comment_videos_attempted": 0,
            "comments": 0,
            "truncated_at_cap": truncated,
            "reached_cutoff": reached_cutoff,
            "like_count_missing": n_like_missing,
            "comment_count_missing": n_comment_missing,
        }
        if note_parts:
            cov["note"] = "; ".join(note_parts)
        coverage.append(cov)
        print(
            f"{meta['brand']}: window={n_window} listed={listed} pages={pages} "
            f"cutoff={reached_cutoff} cap={truncated} subs={channel_row['subscriber_count']} units={client.units_used}",
            flush=True,
        )
        persist(channels_out, videos_out, comments_out, coverage, errors, client.units_used)

    # Optional comment text if quota remains
    remaining_for_comments = client.remaining() - 200
    if remaining_for_comments >= 30:
        print(f"collecting comment samples; remaining_budget={remaining_for_comments}", flush=True)
        for cov in coverage:
            brand = cov["brand"]
            cid = cov["channel_id"]
            cands = comment_candidates.get(brand) or []
            attempted = 0
            ncom = 0
            for row in cands:
                if client.remaining() < 220:
                    break
                attempted += 1
                resp = client.comment_threads(row["video_id"])
                time.sleep(SLEEP_S)
                if resp.get("_error"):
                    errors.append({
                        "at_hkt": now_hkt(),
                        "endpoint": "commentThreads",
                        "brand": brand,
                        "video_id": row["video_id"],
                        "status": resp.get("_http_status"),
                        "reason": resp.get("_reason"),
                        "message": resp.get("_error"),
                    })
                    continue
                flat = flatten_comments(resp.get("items") or [], brand, cid, row["video_id"], retrieved)
                comments_out.extend(flat)
                ncom += len(flat)
            cov["comment_videos_attempted"] = attempted
            cov["comments"] = ncom
            print(f"comments {brand}: attempted={attempted} rows={ncom} units={client.units_used}", flush=True)
            persist(channels_out, videos_out, comments_out, coverage, errors, client.units_used)
    else:
        print(f"skip comment text; remaining={client.remaining()}", flush=True)

    log = [
        "# YouTube public dataset — STAT6207 LC Home & Lifestyle shortlist B (YouTube Data API v3)",
        "",
        f"Collected {retrieved}, with the official YouTube Data API v3 and an API key sent only in the x-goog-api-key header. The key is not stored in this folder.",
        "",
        "This pull covers the second 30-brand verified shortlist in `../shortlist_30_b.csv`. Public metadata snapshot, not YouTube Analytics. First-round files in `../youtube_data_api/` and `../quota_units.json` were not written by this collector.",
        "",
        "## Method",
        "",
        "- Channels: `channels.list` with `part=snippet,statistics,contentDetails,brandingSettings`",
        "- Uploads: `playlistItems.list` on each channel's uploads playlist, newest first",
        "- Video metrics: `videos.list` with `part=snippet,statistics,contentDetails,status`",
        f"- Video window: published on or after {VIDEO_CUTOFF.date().isoformat()} UTC, newest first, cap of {MAX_VIDEOS_PER_CHANNEL} videos per channel",
        f"- Comment sample: videos published on or after {COMMENT_CUTOFF.date().isoformat()} UTC, up to {MAX_COMMENT_VIDEOS} newest videos per channel that have a present non-zero `comment_count`, one page of up to 100 newest top-level threads plus any replies in the same response. An omitted `comment_count` is treated as missing, not zero. `commentThreads` 403 `commentsDisabled` is recorded in errors.json and collection continues.",
        f"- Estimated quota units used for this collection: {client.units_used} of a {TASK_QUOTA_CAP}-unit task cap (this collection starts at 0; earlier official pulls on the same Pacific-time quota day are counted separately toward the 10,000 daily quota).",
        "",
        "## Coverage",
        "",
        f"- Channels written: {len(channels_out)}",
        f"- Videos written: {len(videos_out)}",
        f"- Comment rows written: {len(comments_out)}",
        "",
    ]
    for row in coverage:
        log.append(
            f"- {row['brand']}: {row.get('videos_in_window', 0)} videos in window "
            f"(listed {row.get('videos_listed', 0)}), comments={row.get('comments', 0)} "
            f"from {row.get('comment_videos_attempted', 0)} videos, "
            f"reached_cutoff={row.get('reached_cutoff')}, truncated_at_cap={row.get('truncated_at_cap')}"
            + (f". Note: {row['note']}" if row.get("note") else "")
        )
    log.extend(["", "## Errors", ""])
    if not errors:
        log.append("- None.")
    else:
        for err in errors:
            log.append(
                f"- {err.get('at_hkt')}: {err.get('endpoint')} status={err.get('status')} "
                f"reason={err.get('reason')} brand={err.get('brand','')} "
                f"video_id={err.get('video_id','')} params={err.get('params')} message={err.get('message')}"
            )
    (DEST / "collection_log.md").write_text("\n".join(log) + "\n", encoding="utf-8")
    persist(channels_out, videos_out, comments_out, coverage, errors, client.units_used, "complete")
    print(
        f"Done. units={client.units_used} channels={len(channels_out)} videos={len(videos_out)} comments={len(comments_out)} errors={len(errors)}",
        flush=True,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
