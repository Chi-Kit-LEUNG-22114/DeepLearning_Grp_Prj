#!/usr/bin/env python3
"""Worldwide last-5-year Trends checks for the second shortlist (batch B).

Writes only to trends_checks_b.csv / trends_checks_b.jsonl.
Reuses decide() / series_stats / TrendsClient from the first screen.
Does not overwrite first-round artifacts.
"""
from __future__ import annotations

import csv
import json
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import check_trends  # noqa: E402
from check_trends import decide, series_stats  # noqa: E402
from trends_client import TrendsClient  # noqa: E402

OUT = Path("/workspace/study_notes/capstone_signals/yt_trends_screen")
DEST = OUT / "trends_checks_b.csv"
RAW = OUT / "trends_checks_b.jsonl"
GEO = ""
TIMEFRAME = "today 5-y"
SLEEP = 6.0
FIELDS = [
    "brand",
    "query",
    "status",
    "reason",
    "n_weeks",
    "max",
    "mean",
    "nonzero_weeks",
    "related_top",
    "related_rising",
    "related_error",
    "timeframe",
    "geo",
]

# Collision-prone names. Avoid self-matching substrings (Baccarat / baccara lesson).
check_trends.WRONG_HINTS.update(
    {
        "MATADOR": [
            "bullfight",
            "bull fighting",
            "bull fighter",
            "torero",
            "corrida",
            "matador records",
            "matador films",
            "dodge matador",
            "el matador",
            "cape",
            "matador restaurant",
        ],
        "HALO EDITION": [
            "halo infinite",
            "halo 2",
            "halo 3",
            "halo 4",
            "halo 5",
            "halo reach",
            "halo wars",
            "master chief",
            "343 industries",
            "halo game",
            "halo combat",
            "halo tv",
            "xbox halo",
            "halo ce",
        ],
        "GINGKO DESIGN": ["ginkgo biloba", "ginkgo tree", "gingko tree", "ginkgo leaf"],
        "HANOIA": ["hanoi vietnam", "visit hanoi"],
        "PARAVEL": ["cair paravel", "narnia", "prince caspian", "cair paravel castle"],
        "STERN PINBALL": ["howard stern", "otto stern"],
        "MANKS": ["manks bank", "manks meaning"],
        "SUDIO": [],
        "LAGUIOLE EN AUBRAC": ["laguiole village"],
        "DE LA ESPADA: MATTHEW HILTON": [],
        "GHIDINI 1961": [],
        "MDF ITALIA": ["mdf board", "medium density"],
        "LOCOMOCEAN": [],
        "BUBEN&ZÖRWEG": [],
        "DE LE CUONA": [],
        "GLAS ITALIA": [],
        "KRISTJANA S WILLIAMS": [],
        "L'ATELIER DU VIN": [],
        "NINM LAB": [],
        "OLYMPIA LE-TAN": ["olympia greece", "olympia washington"],
        "POJ STUDIO": [],
        "SHARGE": [],
        "SOCIETY LIMONTA": [],
        "STTOKE": [],
        "SUCK UK": [],
        "SUZUSAN": [],
        "TECKELL": [],
        "ZENLET": [],
    }
)

# Start with a specific phrase when the bare name is collision-prone.
# Try a more specific alternative only if the first query fails the related-query / series test.
CHECKS = [
    ("BUBEN&ZÖRWEG", ["Buben and Zorweg", "Buben Zorweg"]),
    ("DE LA ESPADA: MATTHEW HILTON", ["De La Espada", "Matthew Hilton furniture"]),
    ("DE LE CUONA", ["De Le Cuona"]),
    ("GHIDINI 1961", ["Ghidini 1961"]),
    ("GINGKO DESIGN", ["Gingko Design"]),
    ("GLAS ITALIA", ["Glas Italia"]),
    ("HALO EDITION", ["Halo Edition", "Halo Edition lighting"]),
    ("HANOIA", ["Hanoia"]),
    ("KRISTJANA S WILLIAMS", ["Kristjana S Williams", "Kristjana Williams"]),
    ("L'ATELIER DU VIN", ["L'Atelier du Vin", "Atelier du Vin"]),
    ("LAGUIOLE EN AUBRAC", ["Laguiole en Aubrac"]),
    ("LOCOMOCEAN", ["Locomocean"]),
    ("MANKS", ["Manks", "Manks furniture", "Manks Hong Kong"]),
    ("MATADOR", ["Matador equipment", "Matador packing cubes", "Matador"]),
    ("MDF ITALIA", ["MDF Italia"]),
    ("NINM LAB", ["Ninm Lab"]),
    ("OLYMPIA LE-TAN", ["Olympia Le Tan", "Olympia Le-Tan"]),
    ("PARAVEL", ["Paravel", "Paravel luggage"]),
    ("POJ STUDIO", ["POJ Studio"]),
    ("SHARGE", ["Sharge"]),
    ("SOCIETY LIMONTA", ["Society Limonta"]),
    ("STERN PINBALL", ["Stern Pinball"]),
    ("STTOKE", ["Sttoke"]),
    ("SUCK UK", ["Suck UK"]),
    ("SUDIO", ["Sudio"]),
    ("SUZUSAN", ["Suzusan"]),
    ("TECKELL", ["Teckell"]),
    ("ZENLET", ["Zenlet"]),
]


def persist(rows: list[dict]) -> None:
    with DEST.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=FIELDS)
        w.writeheader()
        w.writerows(rows)
    with RAW.open("w") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")


def already_done() -> list[dict]:
    if not DEST.exists():
        return []
    with DEST.open() as f:
        return list(csv.DictReader(f))


def fetch_with_retry(client: TrendsClient, kw: str, attempts: int = 5) -> dict:
    last = None
    for i in range(attempts):
        try:
            return client.interest_over_time(kw, TIMEFRAME, GEO)
        except Exception as e:
            last = e
            msg = (type(e).__name__ + ":" + str(e)).lower()
            if "429" in msg or "sorry" in msg or "rate" in msg:
                wait = 25 + 15 * i
                print(f"  rate-limit on {kw!r}, sleep {wait}s (attempt {i+1})", flush=True)
                time.sleep(wait)
                # re-warm cookies
                try:
                    client.s.get("https://trends.google.com/trends/explore?q=Tom%20Dixon", timeout=20)
                except Exception:
                    pass
                continue
            raise
    raise last  # type: ignore[misc]


def main() -> int:
    client = TrendsClient()
    rows = already_done()
    done_pairs = {(r["brand"], r["query"]) for r in rows}
    # If a brand already has a pass, skip remaining queries for it.
    passed_brands = {r["brand"] for r in rows if r.get("status") == "pass"}
    print(f"starting trends checks B, resume_rows={len(rows)} passed={sorted(passed_brands)}", flush=True)
    for brand, queries in CHECKS:
        if brand in passed_brands:
            print(f"skip already-passed {brand}", flush=True)
            continue
        for kw in queries:
            if (brand, kw) in done_pairs:
                print(f"skip cached {brand} | {kw}", flush=True)
                # if last cached was fail, continue to next query
                cached = [r for r in rows if r["brand"] == brand and r["query"] == kw]
                if cached and cached[-1].get("status") == "pass":
                    passed_brands.add(brand)
                    break
                continue
            try:
                time.sleep(SLEEP)
                data = fetch_with_retry(client, kw)
                stats = series_stats(data.get("points") or [])
                tops = data.get("related_top") or []
                risings = data.get("related_rising") or []
                err = data.get("related_error") or ""
                status, reason = decide(brand, kw, stats, tops, risings, err)
                rec = {
                    "brand": brand,
                    "query": kw,
                    "status": status,
                    "reason": reason,
                    "n_weeks": stats["n"],
                    "max": stats["max"],
                    "mean": None if stats["mean"] is None else round(stats["mean"], 3),
                    "nonzero_weeks": stats["nonzero"],
                    "related_top": " | ".join(tops[:15]),
                    "related_rising": " | ".join(risings[:15]),
                    "related_error": err,
                    "timeframe": TIMEFRAME,
                    "geo": "WW",
                }
            except Exception as e:
                rec = {
                    "brand": brand,
                    "query": kw,
                    "status": "error",
                    "reason": type(e).__name__ + ":" + str(e)[:200],
                    "n_weeks": "",
                    "max": "",
                    "mean": "",
                    "nonzero_weeks": "",
                    "related_top": "",
                    "related_rising": "",
                    "related_error": type(e).__name__,
                    "timeframe": TIMEFRAME,
                    "geo": "WW",
                }
                time.sleep(20)
            rows.append(rec)
            done_pairs.add((brand, kw))
            print(
                f"{brand} | {kw} -> {rec['status']} {rec['reason']} "
                f"n={rec.get('n_weeks')} max={rec.get('max')} mean={rec.get('mean')} nz={rec.get('nonzero_weeks')} "
                f"top={str(rec.get('related_top') or '')[:160]}",
                flush=True,
            )
            persist(rows)
            if rec["status"] == "pass":
                passed_brands.add(brand)
                break
    print("wrote", DEST, "rows", len(rows), "passed", len(passed_brands), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
