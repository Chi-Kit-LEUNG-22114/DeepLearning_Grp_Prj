#!/usr/bin/env python3
"""Build shortlist_30_b and screening_log_b from first-screen YouTube data + Trends B."""
from __future__ import annotations

import csv
import json
from pathlib import Path

OUT = Path("/workspace/study_notes/capstone_signals/yt_trends_screen")

# Prior dual-pass (not in first 30), then new Trends-B passes, alphabetical within the new group.
PRIOR13 = [
    "AQUAZZURA",
    "DJI",
    "ELIE BLEU",
    "FOCAL",
    "LOMOGRAPHY",
    "MASTER & DYNAMIC",
    "POLAROID",
    "RIEDEL",
    "SPYRA",
    "STEELSERIES",
    "TAITTINGER",
    "THERAGUN",
    "HENNESSY",
]
NEW17 = [
    "BUBEN&ZÖRWEG",
    "DE LE CUONA",
    "GINGKO DESIGN",
    "GLAS ITALIA",
    "L'ATELIER DU VIN",
    "LAGUIOLE EN AUBRAC",
    "MATADOR",
    "MDF ITALIA",
    "OLYMPIA LE-TAN",
    "POJ STUDIO",
    "SHARGE",
    "SOCIETY LIMONTA",
    "STERN PINBALL",
    "STTOKE",
    "SUCK UK",
    "SUDIO",
    "ZENLET",
]
SHORTLIST = PRIOR13 + NEW17

LOCKED = {
    "AQUAZZURA": "Aquazzura",
    "DJI": "DJI",
    "ELIE BLEU": "Elie Bleu",
    "FOCAL": "Focal speakers",
    "LOMOGRAPHY": "Lomography",
    "MASTER & DYNAMIC": "Master and Dynamic",
    "POLAROID": "Polaroid",
    "RIEDEL": "Riedel",
    "SPYRA": "Spyra",
    "STEELSERIES": "SteelSeries",
    "TAITTINGER": "Taittinger",
    "THERAGUN": "Theragun",
    "HENNESSY": "Hennessy",
    "BUBEN&ZÖRWEG": "Buben Zorweg",
    "DE LE CUONA": "De Le Cuona",
    "GINGKO DESIGN": "Gingko Design",
    "GLAS ITALIA": "Glas Italia",
    "L'ATELIER DU VIN": "L'Atelier du Vin",
    "LAGUIOLE EN AUBRAC": "Laguiole en Aubrac",
    "MATADOR": "Matador equipment",
    "MDF ITALIA": "MDF Italia",
    "OLYMPIA LE-TAN": "Olympia Le Tan",
    "POJ STUDIO": "POJ Studio",
    "SHARGE": "Sharge",
    "SOCIETY LIMONTA": "Society Limonta",
    "STERN PINBALL": "Stern Pinball",
    "STTOKE": "Sttoke",
    "SUCK UK": "Suck UK",
    "SUDIO": "Sudio headphones",
    "ZENLET": "Zenlet",
}

# Locked-query notes for shortlist_30_b.csv `notes` column.
NOTES = {
    "AQUAZZURA": "Prior official YouTube three-metric screen from 21 Nov 2026 HKT reused (no new video/comment pull). Official site aquazzura.com links this channel. First-round Worldwide Trends related queries are the fashion house (not reused as a first-30 brand).",
    "DJI": "Prior official YouTube three-metric screen from 21 Nov 2026 HKT reused. Official site dji.com links this channel. Locked query DJI; first-round related queries were the camera/drone company.",
    "ELIE BLEU": "Prior official YouTube three-metric screen from 21 Nov 2026 HKT reused. Official site eliebleu.com links this channel. First-round Trends related queries matched the humidor/accessories house. Somewhat smaller channel (440 public subscribers).",
    "FOCAL": "Prior official YouTube three-metric screen from 21 Nov 2026 HKT reused. Official site focal.com links this channel. Bare Focal was not used; locked query Focal speakers to avoid focal-length/optics senses.",
    "LOMOGRAPHY": "Prior official YouTube three-metric screen from 21 Nov 2026 HKT reused. Official site lomography.com links this channel. First-round Trends related queries were cameras/film.",
    "MASTER & DYNAMIC": "Prior official YouTube three-metric screen from 21 Nov 2026 HKT reused. Official site masterdynamic.com links this channel. Locked ASCII query Master and Dynamic.",
    "POLAROID": "Prior official YouTube three-metric screen from 21 Nov 2026 HKT reused. Official site polaroid.com links this channel. First-round Trends related queries were the camera/instant-film brand.",
    "RIEDEL": "Prior official YouTube three-metric screen from 21 Nov 2026 HKT reused. Official site riedel.com links this channel. First-round related queries were the wine-glass company (not Riedel Communications).",
    "SPYRA": "Prior official YouTube three-metric screen from 21 Nov 2026 HKT reused. Official site spyra.com links this channel. First-round Trends related queries matched the water-blaster brand.",
    "STEELSERIES": "Prior official YouTube three-metric screen from 21 Nov 2026 HKT reused. Official site steelseries.com links this channel. First-round Trends related queries were gaming peripherals.",
    "TAITTINGER": "Prior official YouTube three-metric screen from 21 Nov 2026 HKT reused. Official site taittinger.com links this channel. Age-gated alcohol brand. First-round Trends related queries were champagne.",
    "THERAGUN": "Prior official YouTube three-metric screen from 21 Nov 2026 HKT reused. Official Theragun/Therabody site links the official Therabody channel (@therabody). Locked query Theragun from the first-round Trends pass.",
    "HENNESSY": "Prior official YouTube three-metric screen from 21 Nov 2026 HKT reused. Official channel confirmed via LinkedIn plus handle and Data API title. Age-gated alcohol brand.",
    "BUBEN&ZÖRWEG": "Official site buben-zorweg.com links this channel. Query 'Buben and Zorweg' was too sparse (5/261 weeks non-zero, mean 1.172). Locked query 'Buben Zorweg' related only to 'buben and zorweg'. Series is modest (66/261 non-zero weeks, mean 5.958) but above the Saint-Louis crystal sparsity bar.",
    "DE LE CUONA": "Official site delecuona.com links this channel. Locked query related queries are de le cuona fabric/fabrics and founder Bernie de le Cuona. Non-zero weeks 60/261, mean 14.192.",
    "GINGKO DESIGN": "Official site gingkodesign.com links this channel. Locked query is the two-word brand name, not bare Gingko/Ginkgo. Interest series 46/261 non-zero weeks, mean 10.808; Google returned no related queries, so entity confirmation is from the specific phrase and series only.",
    "GLAS ITALIA": "Official site glasitalia.com links this channel. Locked query related queries include glas italia dining table. Series is dense (260/261 non-zero weeks, mean 37.28).",
    "L'ATELIER DU VIN": "Official site atelierduvin.com links this channel. Related queries are the wine-opener/accessories brand plus retail locations (Brighton, Abbeville, Carrefour).",
    "LAGUIOLE EN AUBRAC": "Official site laguiole-en-aubrac.fr links this channel. Bare Laguiole was not used. Related queries are knives, corkscrews and cutlery from this maker.",
    "MATADOR": "Official site matadorup.com links @matador_equipment. Bare Matador was not used (bullfighting, records, cars). Locked query 'Matador equipment': 55/261 non-zero weeks, mean 11.989; Google returned no related queries, so collision could not be re-checked from related terms.",
    "MDF ITALIA": "Official site mdfitalia.com links this channel. Bare MDF was not used. Related queries are brand products (Tense table, Flow chair, furniture). One related term mentions MDF as a material ('cinza italia mdf') but the list is led by the furniture house.",
    "OLYMPIA LE-TAN": "Official site olympialetan.com links this channel. Related queries are clutch/book/bags. A minor related term 'hotel olympia le tan' appears; the list is otherwise the fashion brand.",
    "POJ STUDIO": "Official site pojstudio.com links this channel. Interest series is modest (36/261 non-zero weeks, mean 6.199) but above the Saint-Louis crystal sparsity bar; Google returned no related queries.",
    "SHARGE": "Official site sharge.com links this channel. Related queries are the brand's power banks, SSD enclosures and IceMag/Flow products.",
    "SOCIETY LIMONTA": "Official site societylimonta.com links this channel. Related queries include society limonta wien (a stockist/city term) with no other-entity collision visible. Series 178/261 non-zero weeks, mean 34.034.",
    "STERN PINBALL": "Official site sternpinball.com links this channel. Bare Stern was not used. Related queries are pinball machines (Godzilla, Star Wars, Fallout, etc.).",
    "STTOKE": "Official site sttoke.com links this channel. Related queries are the uniquely spelled cup/tumbler brand (including Japanese and Chinese product terms).",
    "SUCK UK": "Official site suck.uk.com links this channel. First related-queries call returned HTTP 429; a retry the same day returned suck uk ltd, suck uk design, and suck uk cat (the gift/design company). Series is dense (261/261 non-zero weeks, mean 35.556).",
    "SUDIO": "Official site sudio.com links this channel. Bare 'Sudio' related queries mixed genuine earbud models with typo collisions for Visual Studio, Google AI Studio and FL Studio. Locked query 'Sudio headphones' related only to 'sudio headphones review'. Series 147/261 non-zero weeks, mean 29.831.",
    "ZENLET": "Official site zenlet.co links this channel. Related queries are wallet products (Zenlet 2/3, Dual Plus).",
}

# Manual Trends decisions for the 28 newly checked brands (for the log).
# status: pass / fail / not_selected (Trends would pass or is borderline, not put on the 30)
REVIEW_28 = {
    "BUBEN&ZÖRWEG": {
        "query": "Buben Zorweg",
        "status": "pass",
        "reason": "Locked 'Buben Zorweg' after 'Buben and Zorweg' failed as too sparse (5/261, mean 1.172). Related: buben and zorweg. Series modest (66/261, mean 5.958) but above Saint-Louis sparsity bar.",
    },
    "DE LA ESPADA: MATTHEW HILTON": {
        "query": "De La Espada",
        "status": "fail",
        "reason": "Bare 'De La Espada' related queries are Spanish 'of the sword' titles, King Arthur 'leyenda de la espada', and web-novel/sword-clan phrases, not the furniture house. 'Matthew Hilton furniture' too sparse (2/261, mean 0.747); 'De La Espada furniture' too sparse (5/261, mean 1.222).",
    },
    "DE LE CUONA": {
        "query": "De Le Cuona",
        "status": "pass",
        "reason": "Related queries are de le cuona fabric/fabrics and Bernie de le Cuona. Series 60/261 non-zero, mean 14.192.",
    },
    "GHIDINI 1961": {
        "query": "Ghidini 1961",
        "status": "fail",
        "reason": "Interest too sparse: 6/261 non-zero weeks, mean 1.034, no related queries. Below the Saint-Louis crystal sparsity bar.",
    },
    "GINGKO DESIGN": {
        "query": "Gingko Design",
        "status": "pass",
        "reason": "Two-word query used, not bare Gingko. Series 46/261 non-zero, mean 10.808, above Saint-Louis bar; no related queries were returned.",
    },
    "GLAS ITALIA": {
        "query": "Glas Italia",
        "status": "pass",
        "reason": "Related queries include glas italia dining table. Series 260/261 non-zero, mean 37.28.",
    },
    "HALO EDITION": {
        "query": "Halo Edition",
        "status": "fail",
        "reason": "Bare 'Halo Edition' related queries are Xbox Series X Halo / Halo Infinite console editions (wrong entity). Alternative 'Halo Edition lighting' too sparse (11/261 non-zero, mean 2.238, no related queries).",
    },
    "HANOIA": {
        "query": "Hanoia",
        "status": "fail",
        "reason": "Related queries are 'la table hanoia' (the lacquer brand's own Hanoi restaurant) and 'hanoia melbourne', a different Northern Vietnamese restaurant in Melbourne documented in local press. Name collision with another entity.",
    },
    "KRISTJANA S WILLIAMS": {
        "query": "Kristjana Williams",
        "status": "fail",
        "reason": "'Kristjana S Williams' too sparse (2/261, mean 0.414). Best alternative 'Kristjana Williams' still too sparse (17/261 non-zero, mean 4.0, no related queries), in the same range as the Saint-Louis crystal fail (20/262, mean ~3.1).",
    },
    "L'ATELIER DU VIN": {
        "query": "L'Atelier du Vin",
        "status": "pass",
        "reason": "Related queries are the wine-opener brand and retail listings (Brighton, Abbeville, Carrefour). Series 166/261 non-zero, mean 27.326.",
    },
    "LAGUIOLE EN AUBRAC": {
        "query": "Laguiole en Aubrac",
        "status": "pass",
        "reason": "Related queries are this maker's knives, corkscrews and cutlery, not bare Laguiole the village/generic knife style.",
    },
    "LOCOMOCEAN": {
        "query": "Locomocean",
        "status": "fail",
        "reason": "Interest too sparse: 9/261 non-zero weeks, mean 1.889, below the Saint-Louis bar (related queries were on-brand neon/lightbox terms). Channel also has only 12 public subscribers.",
    },
    "MANKS": {
        "query": "Manks",
        "status": "fail",
        "reason": "Bare 'Manks' related queries mix Manx-cat terms (manks kedisi, manks cat, kot manks), Manks Road, No Manks Sky, Grupo Manks / Richard Manks with only some Manks HK furniture terms. 'Manks Hong Kong' and 'Manks furniture' returned no interest series (n=0) on two attempts; 'Manks HK' was too sparse (1/261, mean 0.383).",
    },
    "MATADOR": {
        "query": "Matador equipment",
        "status": "pass",
        "reason": "Bare Matador not used. Locked 'Matador equipment' series 55/261 non-zero, mean 11.989, above Saint-Louis bar; no related queries were returned to re-check collisions.",
    },
    "MDF ITALIA": {
        "query": "MDF Italia",
        "status": "pass",
        "reason": "Related queries are Tense/Flow chair and MDF Italia furniture. Bare MDF (board) was not used.",
    },
    "NINM LAB": {
        "query": "Ninm Lab",
        "status": "fail",
        "reason": "Related queries are on-brand (cassette player, CD player, It's Real) but the series is too sparse: 13/261 non-zero weeks, mean 3.372, at or below the Saint-Louis crystal bar (20/262, mean ~3.1).",
    },
    "OLYMPIA LE-TAN": {
        "query": "Olympia Le Tan",
        "status": "pass",
        "reason": "Related queries are clutch, book clutch and bags. A minor 'hotel olympia le tan' term appears; the list is otherwise the fashion brand. Series 225/261, mean 16.337.",
    },
    "PARAVEL": {
        "query": "Paravel luggage",
        "status": "fail",
        "reason": "Bare 'Paravel' related queries include Cair Paravel / Narnia and a Latin school alongside luggage. Alternative 'Paravel luggage' has clean related queries ('paravel luggage reviews') and a dense series (236/261, mean 35.874), but the official channel has only 2 public subscribers and was not used once 30 stronger dual-pass brands were available. Recorded as a Trends near-miss, not placed on the shortlist.",
    },
    "POJ STUDIO": {
        "query": "POJ Studio",
        "status": "pass",
        "reason": "Series modest (36/261 non-zero, mean 6.199) but above the Saint-Louis bar; no related queries were returned.",
    },
    "SHARGE": {
        "query": "Sharge",
        "status": "pass",
        "reason": "Related queries are Sharge power banks, Disk SSD enclosures and IceMag/Flow products. Series 261/261, mean 26.575.",
    },
    "SOCIETY LIMONTA": {
        "query": "Society Limonta",
        "status": "pass",
        "reason": "Related queries include society limonta wien. No other-entity collision visible. Series 178/261, mean 34.034.",
    },
    "STERN PINBALL": {
        "query": "Stern Pinball",
        "status": "pass",
        "reason": "Related queries are Stern pinball machines and titles. Bare Stern was not used.",
    },
    "STTOKE": {
        "query": "Sttoke",
        "status": "pass",
        "reason": "Related queries are Sttoke cups, mugs and tumblers (including JP/ZH product terms). Unique spelling.",
    },
    "SUCK UK": {
        "query": "Suck UK",
        "status": "pass",
        "reason": "First related-queries call HTTP 429; retry returned suck uk ltd, suck uk design, suck uk cat. Series 261/261, mean 35.556.",
    },
    "SUDIO": {
        "query": "Sudio headphones",
        "status": "pass",
        "reason": "Bare 'Sudio' mixed brand earbud queries with Visual Studio / Google AI Studio / FL Studio typos. Locked 'Sudio headphones' related only to 'sudio headphones review'.",
    },
    "SUZUSAN": {
        "query": "Suzusan",
        "status": "fail",
        "reason": "Auto series check passed (28/261 non-zero, mean 6.395, no related queries) and is slightly above the Saint-Louis bar, but the official channel has only 72 public subscribers and no related queries for entity confirmation. Not selected once 30 stronger dual-pass brands were available. Near-miss.",
    },
    "TECKELL": {
        "query": "Teckell",
        "status": "fail",
        "reason": "Interest too sparse: 12/261 non-zero weeks, mean 2.69, no related queries. Below the Saint-Louis crystal sparsity bar. Channel has 74 public subscribers.",
    },
    "ZENLET": {
        "query": "Zenlet",
        "status": "pass",
        "reason": "Related queries are Zenlet wallet products. Series 171/261, mean 20.812.",
    },
}


def load_csv(path: Path) -> list[dict]:
    with path.open() as f:
        return list(csv.DictReader(f))


def append_manks_hk() -> None:
    dest = OUT / "trends_checks_b.csv"
    raw = OUT / "trends_checks_b.jsonl"
    rows = load_csv(dest)
    if any(r["brand"] == "MANKS" and r["query"] == "Manks HK" for r in rows):
        return
    rec = {
        "brand": "MANKS",
        "query": "Manks HK",
        "status": "fail",
        "reason": "interest_too_sparse",
        "n_weeks": 261,
        "max": 100.0,
        "mean": 0.383,
        "nonzero_weeks": 1,
        "related_top": "",
        "related_rising": "",
        "related_error": "",
        "timeframe": "today 5-y",
        "geo": "WW",
    }
    rows.append(rec)
    fields = list(rows[0].keys())
    with dest.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)
    with raw.open("w") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print("appended Manks HK retry to trends_checks_b")


def main() -> None:
    append_manks_hk()
    lc = {r["brand"]: r["url"] for r in load_csv(OUT / "lc_home_lifestyle_brands_live_2026-11-21.csv")}
    logs = {r["brand"]: r for r in load_csv(OUT / "screening_log.csv")}
    assert all(b in logs for b in SHORTLIST)
    assert all(b in lc for b in SHORTLIST)
    assert len(SHORTLIST) == 30
    assert len(set(SHORTLIST)) == 30

    short_fields = [
        "brand",
        "lc_url",
        "youtube_url",
        "youtube_handle",
        "channel_id",
        "subscriber_count",
        "likes_ok",
        "comments_ok",
        "n_recent_videos_checked",
        "n_with_likes",
        "n_with_comments",
        "locked_trends_query",
        "trends_status",
        "notes",
        "channel_thumbnail_url",
        "channel_thumbnail_path",
        "video_id",
        "video_thumbnail_url",
        "video_thumbnail_path",
    ]
    short_rows = []
    for b in SHORTLIST:
        r = logs[b]
        short_rows.append(
            {
                "brand": b,
                "lc_url": lc[b],
                "youtube_url": r["youtube_url"],
                "youtube_handle": r["youtube_handle"],
                "channel_id": r["channel_id"],
                "subscriber_count": r["subscriber_count"],
                "likes_ok": r["likes_ok"],
                "comments_ok": r["comments_ok"],
                "n_recent_videos_checked": r["n_recent_videos_checked"],
                "n_with_likes": r["n_with_likes"],
                "n_with_comments": r["n_with_comments"],
                "locked_trends_query": LOCKED[b],
                "trends_status": "pass",
                "notes": NOTES[b],
                "channel_thumbnail_url": "",
                "channel_thumbnail_path": "",
                "video_id": "",
                "video_thumbnail_url": "",
                "video_thumbnail_path": "",
            }
        )

    with (OUT / "shortlist_30_b.csv").open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=short_fields)
        w.writeheader()
        w.writerows(short_rows)

    # screening log B: 13 prior dual-pass + all 28 newly Trends-checked
    log_fields = [
        "brand",
        "in_live_lc_hl",
        "youtube_status",
        "youtube_fail_reason",
        "youtube_url",
        "youtube_handle",
        "channel_id",
        "channel_title",
        "subscriber_count",
        "likes_ok",
        "comments_ok",
        "n_recent_videos_checked",
        "n_with_likes",
        "n_with_comments",
        "evidence_type",
        "evidence_url",
        "locked_trends_query",
        "trends_status",
        "trends_reason",
        "in_shortlist_30_b",
        "notes",
    ]
    log_rows = []
    for b in PRIOR13:
        r = logs[b]
        log_rows.append(
            {
                "brand": b,
                "in_live_lc_hl": "yes",
                "youtube_status": r["youtube_status"],
                "youtube_fail_reason": r["youtube_fail_reason"],
                "youtube_url": r["youtube_url"],
                "youtube_handle": r["youtube_handle"],
                "channel_id": r["channel_id"],
                "channel_title": r["channel_title"],
                "subscriber_count": r["subscriber_count"],
                "likes_ok": r["likes_ok"],
                "comments_ok": r["comments_ok"],
                "n_recent_videos_checked": r["n_recent_videos_checked"],
                "n_with_likes": r["n_with_likes"],
                "n_with_comments": r["n_with_comments"],
                "evidence_type": r["evidence_type"],
                "evidence_url": r["evidence_url"],
                "locked_trends_query": LOCKED[b],
                "trends_status": "pass",
                "trends_reason": "Prior first-round Worldwide Trends pass reused; not re-pulled in batch B.",
                "in_shortlist_30_b": "yes",
                "notes": "Prior dual-pass brand held out of the first 30; included in shortlist B. YouTube three-metric results reused from the 21 Nov 2026 official Data API screen. " + (r.get("notes") or ""),
            }
        )
    for b, rev in REVIEW_28.items():
        r = logs[b]
        in_sl = "yes" if b in SHORTLIST else "no"
        q = rev["query"] if rev["status"] == "pass" and b in SHORTLIST else (rev["query"] if rev["status"] == "pass" else rev["query"])
        # For fails, still record the query that was evaluated / best tried
        if b in LOCKED and in_sl == "yes":
            q = LOCKED[b]
        log_rows.append(
            {
                "brand": b,
                "in_live_lc_hl": "yes",
                "youtube_status": r["youtube_status"],
                "youtube_fail_reason": r["youtube_fail_reason"],
                "youtube_url": r["youtube_url"],
                "youtube_handle": r["youtube_handle"],
                "channel_id": r["channel_id"],
                "channel_title": r["channel_title"],
                "subscriber_count": r["subscriber_count"],
                "likes_ok": r["likes_ok"],
                "comments_ok": r["comments_ok"],
                "n_recent_videos_checked": r["n_recent_videos_checked"],
                "n_with_likes": r["n_with_likes"],
                "n_with_comments": r["n_with_comments"],
                "evidence_type": r["evidence_type"],
                "evidence_url": r["evidence_url"],
                "locked_trends_query": q if rev["status"] == "pass" and in_sl == "yes" else (q if b in ("PARAVEL", "SUZUSAN") else ""),
                "trends_status": "pass" if in_sl == "yes" else ("pass_not_selected" if b in ("PARAVEL", "SUZUSAN") else "fail"),
                "trends_reason": rev["reason"],
                "in_shortlist_30_b": in_sl,
                "notes": (r.get("notes") or "").strip(),
            }
        )
    log_rows.sort(key=lambda r: r["brand"])
    with (OUT / "screening_log_b.csv").open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=log_fields)
        w.writeheader()
        w.writerows(log_rows)

    # Markdown
    def md_escape(s: str) -> str:
        return s.replace("|", "\\|")

    lines = []
    lines.append("# Lane Crawford Home & Lifestyle YouTube + Trends shortlist B")
    lines.append("")
    lines.append(
        "Second verified data-availability shortlist of **30** brands. "
        "None of these brands overlap the first shortlist of 30 in `shortlist_30.csv`. "
        "Universe: **403** unique brands on the live Lane Crawford HK Home & Lifestyle directory fetched 21 November 2026, 01:00 HKT from https://www.lanecrawford.com.hk/brand/home-lifestyle/ (saved as `lc_home_lifestyle_brands_live_2026-11-21.csv`). "
        "LANE CRAWFORD and LANE CRAWFORD TRAVEL were excluded as the retailer itself. "
        "This is an **availability shortlist, not a random sample**."
    )
    lines.append("")
    lines.append(
        "YouTube metrics are reused from the official YouTube Data API v3 three-metric screen already run on 21 November 2026 HKT (subscribers via `channels.list` statistics; likes and comments via `videos.list` field presence on a recent public-video sample). "
        "A value of 0 counts as present; a missing `likeCount` or `commentCount` field is a fail. "
        "No new 3-year video or comment collection was run for this second shortlist."
    )
    lines.append("")
    lines.append(
        "Google Trends checks for the 17 newly admitted brands were Worldwide (`geo` empty), last 5 years (`today 5-y`), run 21 November 2026, 12:03-12:12 HKT, using related queries plus interest-over-time completeness, with the same series rule as the first screen and the same Saint-Louis crystal sparsity bar (too few non-zero weeks and a very low mean). "
        "Brands with Celine-like name collision were excluded even if YouTube passed. "
        "The 13 brands that already dual-passed in the first screen but were held out of the first 30 were included here without re-pulling Trends."
    )
    lines.append("")
    lines.append(
        "Of 28 YouTube-pass brands that still needed Trends checks, 17 were admitted to this shortlist, 9 failed Trends (wrong entity or too-sparse series), and 2 were near-misses not selected (Paravel luggage would pass a specific query but the channel has 2 subscribers; Suzusan is slightly above the sparsity bar but has 72 subscribers and no related queries). "
        "No extra official-channel hunt was required to reach 30."
    )
    lines.append("")
    lines.append("Subscriber counts may be rounded by YouTube. Alcohol brands (Taittinger, Hennessy) are often age-gated on consumer sites; the public Data API still returned the listed statistics.")
    lines.append("")
    lines.append("Channel and recent-video thumbnails (official Data API `snippet.thumbnails` and `i.ytimg.com` CDN) are under `thumbnails_b/`. Contact sheets: `thumbnails_b/shortlist_30_b_channel_thumbs.png` and `thumbnails_b/shortlist_30_b_video_thumbs.png`.")
    lines.append("")
    lines.append("| # | Brand | YouTube | Subscribers (public API) | Locked Trends query |")
    lines.append("|---|-------|---------|--------------------------|---------------------|")
    for i, row in enumerate(short_rows, 1):
        handle = row["youtube_handle"]
        url = row["youtube_url"]
        lines.append(
            f"| {i} | {md_escape(row['brand'])} | [{handle}]({url}) | {row['subscriber_count']} | `{row['locked_trends_query']}` |"
        )
    lines.append("")
    lines.append("## Per-brand YouTube sample and notes")
    lines.append("")
    for row in short_rows:
        b = row["brand"]
        r = logs[b]
        lines.append(f"### {b}")
        lines.append("")
        lines.append(f"- Lane Crawford: {row['lc_url']}")
        lines.append(f"- YouTube: {row['youtube_url']} (`{row['channel_id']}`)")
        lines.append(f"- Subscribers: {row['subscriber_count']} (public API; may be rounded)")
        lines.append(
            f"- Recent videos checked: {row['n_recent_videos_checked']}; likes field present on {row['n_with_likes']}; comments field present on {row['n_with_comments']}"
        )
        lines.append(f"- Locked Trends query: `{row['locked_trends_query']}` (Worldwide, today 5-y) — pass")
        if b in PRIOR13:
            ev = f"Evidence: {r['evidence_type']} {r['evidence_url']}.".strip()
            lines.append(f"- {NOTES[b]} {ev}")
        else:
            lines.append(f"- {NOTES[b]}")
        lines.append("")

    lines.append("## Caveats")
    lines.append("")
    lines.append("- Availability screening only; not a probability sample of the 403-brand universe and not a random subset of YouTube-pass brands.")
    lines.append("- Gingko Design, Matador (query: Matador equipment) and POJ Studio returned no Google related-queries list; admission rests on a specific phrase plus an interest series above the Saint-Louis sparsity bar.")
    lines.append("- Buben Zorweg and POJ Studio have relatively modest non-zero-week counts (66/261 and 36/261). De Le Cuona is 60/261.")
    lines.append("- De Le Cuona comments field was present on 14 of 15 recent videos (still a YouTube pass under the sample rule).")
    lines.append("- Bare Sudio was rejected for Visual Studio / AI Studio / FL Studio typo collisions; the locked query is Sudio headphones.")
    lines.append("- Taittinger and Hennessy are age-gated alcohol brands.")
    lines.append("- Theragun is represented by the official Therabody channel.")
    lines.append("- Official-channel evidence for Hennessy is LinkedIn plus handle, confirmed in the Data API, not an official-site footer backlink.")
    lines.append("- Thumbnail paths were filled after this table was drafted; see the CSV columns `channel_thumbnail_path` and `video_thumbnail_path`.")
    lines.append("")
    lines.append("## Near-misses and Trends fails among the 28 newly checked brands")
    lines.append("")
    lines.append("YouTube already passed for all 28. Decisions below are Trends and selection only.")
    lines.append("")
    fails_order = [
        "DE LA ESPADA: MATTHEW HILTON",
        "GHIDINI 1961",
        "HALO EDITION",
        "HANOIA",
        "KRISTJANA S WILLIAMS",
        "LOCOMOCEAN",
        "MANKS",
        "NINM LAB",
        "TECKELL",
        "PARAVEL",
        "SUZUSAN",
    ]
    for b in fails_order:
        rev = REVIEW_28[b]
        r = logs[b]
        tag = "near-miss, not selected" if b in ("PARAVEL", "SUZUSAN") else "Trends fail"
        lines.append(f"- **{b}** ({tag}; {r['subscriber_count']} public subscribers): {rev['reason']}")
    lines.append("")

    (OUT / "shortlist_30_b.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("wrote", OUT / "shortlist_30_b.csv", "rows", len(short_rows))
    print("wrote", OUT / "screening_log_b.csv", "rows", len(log_rows))
    print("wrote", OUT / "shortlist_30_b.md")


if __name__ == "__main__":
    main()
