#!/usr/bin/env python3
"""Official YouTube Data API v3 client with quota tracking.

Reads YOUTUBE_API_KEY from the environment and sends it only as the
x-goog-api-key header. The key is never written to files, logs, or URLs.
"""
from __future__ import annotations

import json
import os
import re
import time
from datetime import datetime
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo

import requests

HKT = ZoneInfo("Asia/Hong_Kong")
API_BASE = "https://www.googleapis.com/youtube/v3"
# Hard cap for this whole job (screening + collection). Leave daily remainder unused.
TASK_QUOTA_CAP = 5000
QUOTA_COSTS = {
    "channels": 1,
    "playlistItems": 1,
    "videos": 1,
    "commentThreads": 1,
    "search": 100,
}
OUT = Path("/workspace/study_notes/capstone_signals/yt_trends_screen")
QUOTA_PATH = OUT / "quota_units.json"


def now_hkt() -> str:
    return datetime.now(HKT).strftime("%Y-%m-%d %H:%M:%S HKT")


class QuotaExceeded(RuntimeError):
    pass


class YouTubeClient:
    def __init__(
        self,
        reserve_for_collection: int = 0,
        *,
        quota_path: Path | None = None,
        load_previous: bool = True,
    ) -> None:
        key = os.environ.get("YOUTUBE_API_KEY", "")
        if not key:
            raise RuntimeError("YOUTUBE_API_KEY is not set")
        self._key = key
        self.units_used = 0
        self.reserve_for_collection = reserve_for_collection
        self.calls: list[dict[str, Any]] = []
        self.quota_path = Path(quota_path) if quota_path else QUOTA_PATH
        if load_previous and self.quota_path.exists():
            try:
                prev = json.loads(self.quota_path.read_text())
                self.units_used = int(prev.get("units_used", 0))
            except Exception:
                pass
        self.session = requests.Session()
        self.session.headers.update({"Accept": "application/json"})

    def remaining(self) -> int:
        return TASK_QUOTA_CAP - self.units_used

    def _persist(self) -> None:
        # Never include the key.
        self.quota_path.parent.mkdir(parents=True, exist_ok=True)
        self.quota_path.write_text(
            json.dumps(
                {
                    "units_used": self.units_used,
                    "task_cap": TASK_QUOTA_CAP,
                    "remaining": self.remaining(),
                    "updated_at_hkt": now_hkt(),
                    "n_calls": len(self.calls),
                    "calls": self.calls,
                },
                indent=2,
            )
            + "\n"
        )

    def _get(self, endpoint: str, params: dict[str, Any], cost: int | None = None) -> dict[str, Any]:
        cost = QUOTA_COSTS[endpoint] if cost is None else cost
        if self.units_used + cost > TASK_QUOTA_CAP - self.reserve_for_collection:
            self._persist()
            raise QuotaExceeded(
                f"refusing {endpoint} cost={cost}: used={self.units_used} cap={TASK_QUOTA_CAP} reserve={self.reserve_for_collection}"
            )
        # Key only in header, never in params/URL.
        safe_params = {k: v for k, v in params.items() if k.lower() not in {"key", "api_key", "apikey"}}
        headers = {"x-goog-api-key": self._key, "Accept": "application/json"}
        url = f"{API_BASE}/{endpoint}"
        last_err = None
        for attempt in range(4):
            try:
                r = self.session.get(url, params=safe_params, headers=headers, timeout=30)
            except requests.RequestException as e:
                last_err = e
                time.sleep(0.6 * (attempt + 1))
                continue
            # Charge quota for successful or most error responses that count;
            # Google typically charges for successful requests. 4xx invalid may still cost 1.
            if r.status_code != 401:
                self.units_used += cost
                self.calls.append(
                    {
                        "at_hkt": now_hkt(),
                        "endpoint": endpoint,
                        "cost": cost,
                        "status": r.status_code,
                        "units_used": self.units_used,
                        "params": {
                            k: v
                            for k, v in safe_params.items()
                            if k in {"id", "forHandle", "forUsername", "playlistId", "videoId", "part", "pageToken", "maxResults", "order"}
                        },
                    }
                )
                self._persist()
            if r.status_code == 200:
                return r.json()
            if r.status_code in {429, 500, 503} and attempt < 3:
                time.sleep(1.5 * (attempt + 1))
                continue
            # Do not include request URL (could theoretically have been misbuilt).
            try:
                body = r.json()
                err = body.get("error", {})
                msg = err.get("message", r.text[:200])
                reason = ""
                if err.get("errors"):
                    reason = err["errors"][0].get("reason", "")
            except Exception:
                msg, reason = r.text[:200], ""
            return {"_http_status": r.status_code, "_error": msg, "_reason": reason, "items": []}
        raise RuntimeError(f"{endpoint} failed after retries: {type(last_err).__name__}")

    def channels_by_handle(self, handle: str) -> dict[str, Any]:
        h = handle if handle.startswith("@") else f"@{handle}"
        return self._get(
            "channels",
            {"part": "snippet,statistics,contentDetails,brandingSettings", "forHandle": h},
        )

    def channels_by_id(self, channel_id: str) -> dict[str, Any]:
        return self._get(
            "channels",
            {"part": "snippet,statistics,contentDetails,brandingSettings", "id": channel_id},
        )

    def channels_by_username(self, username: str) -> dict[str, Any]:
        return self._get(
            "channels",
            {"part": "snippet,statistics,contentDetails,brandingSettings", "forUsername": username},
        )

    def playlist_items(self, playlist_id: str, page_token: str | None = None, max_results: int = 15) -> dict[str, Any]:
        params: dict[str, Any] = {
            "part": "snippet,contentDetails",
            "playlistId": playlist_id,
            "maxResults": min(max_results, 50),
        }
        if page_token:
            params["pageToken"] = page_token
        return self._get("playlistItems", params)

    def videos_list(self, video_ids: list[str]) -> dict[str, Any]:
        if not video_ids:
            return {"items": []}
        return self._get(
            "videos",
            {
                "part": "snippet,statistics,contentDetails,status",
                "id": ",".join(video_ids),
                "maxResults": 50,
            },
        )

    def comment_threads(self, video_id: str, page_token: str | None = None) -> dict[str, Any]:
        params: dict[str, Any] = {
            "part": "snippet,replies",
            "videoId": video_id,
            "maxResults": 100,
            "order": "time",
            "textFormat": "plainText",
        }
        if page_token:
            params["pageToken"] = page_token
        return self._get("commentThreads", params)


def parse_channel_url(url: str) -> dict[str, str]:
    """Parse a YouTube channel URL into lookup type + value."""
    u = url.strip()
    u = re.sub(r"[#?].*$", "", u)
    u = u.rstrip("/")
    m = re.search(r"youtube\.com/channel/(UC[\w-]+)", u, re.I)
    if m:
        return {"type": "id", "value": m.group(1)}
    m = re.search(r"youtube\.com/@([\w.-]+)", u, re.I)
    if m:
        return {"type": "handle", "value": "@" + m.group(1)}
    m = re.search(r"youtube\.com/user/([\w.-]+)", u, re.I)
    if m:
        return {"type": "username", "value": m.group(1)}
    m = re.search(r"youtube\.com/c/([\w.-]+)", u, re.I)
    if m:
        return {"type": "custom", "value": m.group(1)}
    m = re.search(r"youtube\.com/([\w.-]+)$", u, re.I)
    if m and m.group(1).lower() not in {"watch", "playlist", "embed", "shorts", "live", "results", "feed", "paid_memberships", "iframe_api"}:
        return {"type": "custom", "value": m.group(1)}
    return {"type": "unknown", "value": u}


def pick_channel_item(data: dict[str, Any]) -> dict[str, Any] | None:
    items = data.get("items") or []
    return items[0] if items else None
