#!/usr/bin/env python3
"""Minimal Google Trends client (Worldwide interest + related queries)."""
from __future__ import annotations

import json
import time
from typing import Any
from urllib.parse import quote, urlencode

import requests

EXPLORE = "https://trends.google.com/trends/api/explore"
MULTILINE = "https://trends.google.com/trends/api/widgetdata/multiline"
RELATED = "https://trends.google.com/trends/api/widgetdata/relatedsearches"


class TrendsClient:
    def __init__(self) -> None:
        self.s = requests.Session()
        self.s.headers.update(
            {
                "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
                "Accept": "application/json, text/plain, */*",
                "Accept-Language": "en-US,en;q=0.9",
                "Referer": "https://trends.google.com/trends/explore",
            }
        )
        # Warm cookies
        try:
            self.s.get("https://trends.google.com/trends/explore?q=Tom%20Dixon", timeout=20)
        except requests.RequestException:
            pass

    def _strip(self, text: str) -> Any:
        text = text.lstrip()
        if text.startswith(")]}'"):
            text = text.split("\n", 1)[-1] if "\n" in text else text[4:]
            text = text.lstrip()
        return json.loads(text)

    def explore(self, keyword: str, timeframe: str = "today 5-y", geo: str = "") -> dict[str, Any]:
        req = {
            "comparisonItem": [{"keyword": keyword, "geo": geo, "time": timeframe}],
            "category": 0,
            "property": "",
        }
        params = {"hl": "en-US", "tz": "0", "req": json.dumps(req, separators=(",", ":"))}
        r = self.s.get(EXPLORE, params=params, timeout=30)
        if r.status_code != 200:
            raise RuntimeError(f"explore_http_{r.status_code}:{r.text[:180]}")
        return self._strip(r.text)

    def interest_over_time(self, keyword: str, timeframe: str = "today 5-y", geo: str = "") -> dict[str, Any]:
        data = self.explore(keyword, timeframe, geo)
        widgets = data.get("widgets") or []
        timeseries = None
        related = None
        token_ts = token_rq = None
        req_ts = req_rq = None
        for w in widgets:
            id_ = (w.get("id") or w.get("title") or "")
            typ = (w.get("title") or "") + " " + (w.get("type") or "") + " " + (w.get("id") or "")
            if w.get("id") == "TIMESERIES" or "Interest over time" in typ:
                timeseries = w
                token_ts = w.get("token")
                req_ts = w.get("request")
            if w.get("id") == "RELATED_QUERIES" or "Related queries" in typ:
                related = w
                token_rq = w.get("token")
                req_rq = w.get("request")
        out: dict[str, Any] = {"points": [], "related_top": [], "related_rising": []}
        if token_ts and req_ts is not None:
            params = {
                "hl": "en-US",
                "tz": "0",
                "req": json.dumps(req_ts, separators=(",", ":")),
                "token": token_ts,
            }
            r = self.s.get(MULTILINE, params=params, timeout=30)
            if r.status_code != 200:
                raise RuntimeError(f"timeseries_http_{r.status_code}:{r.text[:180]}")
            body = self._strip(r.text)
            default = (body.get("default") or {})
            for p in default.get("timelineData") or []:
                vals = p.get("value") or []
                out["points"].append({"time": p.get("formattedTime") or p.get("time"), "value": vals[0] if vals else None})
        if token_rq and req_rq is not None:
            params = {
                "hl": "en-US",
                "tz": "0",
                "req": json.dumps(req_rq, separators=(",", ":")),
                "token": token_rq,
            }
            r = self.s.get(RELATED, params=params, timeout=30)
            if r.status_code != 200:
                # related often rate-limits independently
                out["related_error"] = f"related_http_{r.status_code}"
            else:
                body = self._strip(r.text)
                ranked = ((body.get("default") or {}).get("rankedList") or [])
                # typically [top, rising]
                if len(ranked) >= 1:
                    out["related_top"] = [it.get("query") for it in ranked[0].get("rankedKeyword") or [] if it.get("query")]
                if len(ranked) >= 2:
                    out["related_rising"] = [it.get("query") for it in ranked[1].get("rankedKeyword") or [] if it.get("query")]
        return out


if __name__ == "__main__":
    c = TrendsClient()
    for kw in ["Tom Dixon", "Celine"]:
        t0 = time.time()
        d = c.interest_over_time(kw)
        vals = [p["value"] for p in d["points"] if p["value"] is not None]
        print(
            kw,
            "n",
            len(vals),
            "max",
            max(vals) if vals else None,
            "mean",
            round(sum(vals) / len(vals), 2) if vals else None,
            "top",
            d["related_top"][:8],
            "rising",
            d["related_rising"][:8],
            "err",
            d.get("related_error"),
            "sec",
            round(time.time() - t0, 1),
        )
        time.sleep(2)
