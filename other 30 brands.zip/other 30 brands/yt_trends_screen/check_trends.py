#!/usr/bin/env python3
"""Check Google Trends ambiguity for YouTube-pass brands."""
from __future__ import annotations

import csv
import json
import time
from pathlib import Path

from trends_client import TrendsClient

OUT = Path("/workspace/study_notes/capstone_signals/yt_trends_screen")
DEST = OUT / "trends_checks.csv"
RAW = OUT / "trends_checks.jsonl"
GEO = ""
TIMEFRAME = "today 5-y"
SLEEP = 3.0

CHECKS = [
    ("Tom Dixon", ["Tom Dixon"]),
    ("Flos", ["Flos lighting", "Flos lamp", "Flos"]),
    ("Moët & Chandon", ["Moet Chandon", "Moët & Chandon"]),
    ("Dom Pérignon", ["Dom Perignon"]),
    ("Aesop", ["Aesop"]),
    ("Jo Malone London", ["Jo Malone London"]),
    ("Buccellati", ["Buccellati"]),
    ("Maison Margiela", ["Maison Margiela"]),
    ("Bang & Olufsen", ["Bang and Olufsen", "Bang & Olufsen"]),
    ("Herman Miller", ["Herman Miller"]),
    ("Fritz Hansen", ["Fritz Hansen"]),
    ("Carl Hansen & Søn", ["Carl Hansen", "Carl Hansen Son"]),
    ("Vitra", ["Vitra"]),
    ("Cassina", ["Cassina"]),
    ("Knoll", ["Knoll furniture", "Knoll"]),
    ("B&B Italia", ["B&B Italia", "B and B Italia"]),
    ("Artemide", ["Artemide"]),
    ("Louis Poulsen", ["Louis Poulsen"]),
    ("Kartell", ["Kartell"]),
    ("Devialet", ["Devialet"]),
    ("Bowers & Wilkins", ["Bowers and Wilkins", "Bowers & Wilkins"]),
    ("Sennheiser", ["Sennheiser"]),
    ("Baccarat", ["Baccarat crystal", "Baccarat glass", "Baccarat"]),
    ("Christofle", ["Christofle"]),
    ("Riedel", ["Riedel"]),
    ("Saint-Louis", ["Saint-Louis crystal", "Saint Louis crystal", "Saint-Louis Cristal"]),
    ("Lasvit", ["Lasvit"]),
    ("Fornasetti", ["Fornasetti"]),
    ("Maison Francis Kurkdjian", ["Maison Francis Kurkdjian", "Francis Kurkdjian"]),
    ("Tom Ford", ["Tom Ford"]),
    ("Loewe", ["Loewe"]),
    ("Fortnum & Mason", ["Fortnum and Mason", "Fortnum & Mason"]),
    ("Hennessy", ["Hennessy"]),
    ("The Macallan", ["The Macallan", "Macallan"]),
    ("Ruinart", ["Ruinart"]),
    ("Taittinger", ["Taittinger"]),
    ("Cotopaxi", ["Cotopaxi"]),
    ("DJI", ["DJI"]),
    ("Polaroid", ["Polaroid"]),
    ("Jura", ["Jura coffee", "Jura coffee machine"]),
    ("THERAGUN", ["Theragun", "Therabody"]),
    ("Master & Dynamic", ["Master and Dynamic", "Master & Dynamic"]),
    ("Focal", ["Focal speakers", "Focal loudspeakers"]),
    ("Aquazzura", ["Aquazzura"]),
    ("Bordallo Pinheiro", ["Bordallo Pinheiro"]),
    ("Vista Alegre", ["Vista Alegre"]),
    ("Elie Bleu", ["Elie Bleu"]),
    ("Stanley", ["Stanley 1913", "Stanley tumbler"]),
    ("ClassiCon", ["ClassiCon"]),
    ("Lomography", ["Lomography"]),
    ("Steelseries", ["SteelSeries"]),
    ("HOTO", ["HOTO"]),
    ("SPYRA", ["Spyra"]),
    ("Kodak", ["Kodak"]),
]

# Wrong-entity substrings in related queries (case-insensitive).
WRONG_HINTS = {
    "Baccarat": ["casino", "gambling", "baccara", "chemin", "poker", "blackjack", "how to play", "punto"],
    "Flos": ["flow"],
    "Knoll": ["stock price", "knoll inc stock"],
    "Loewe": ["loewe tv", "fernseher", "television", "loewe klang", "oled"],
    "Vitra": ["vitraam", "vitra tile", "vitra bathroom"],
    "Aesop": ["fable", "aesop rock", "lyrics", "aesop's"],
    "Riedel": ["riedel communications", "riedel bolzano", "artistate"],
    "Saint-Louis": ["missouri", "cardinals", "gateway", "senegal", "rams", "blues"],
    "Jura": ["mountains", "canton", "whisky", "whiskey", "island"],
    "Focal": ["focal length", "focal point", "epilepsy", "seizure"],
    "Stanley": ["playoff", "hockey", "morgan stanley", "stanley cup finals", "measuring tape", "fatmax"],
    "Cotopaxi": ["volcano", "ecuador", "climb", "summit"],
    "Vista Alegre": ["rio ", "neighborhood"],
    "Kodak": [],
    "Hennessy": [],
    "DJI": ["dow jones"] if False else [],
    "Polaroid": [],
    "Cassina": ["cassina de"],
    "Kartell": ["kartell legal", "law firm"],
}


def hints_hit(brand: str, terms: list[str]) -> list[str]:
    blob = " | ".join(terms).lower()
    return [h for h in WRONG_HINTS.get(brand, []) if h.lower() in blob]


def series_stats(points: list[dict]) -> dict:
    vals = [p["value"] for p in points if p.get("value") is not None]
    if not vals:
        return {"n": 0, "max": None, "sum": None, "nonzero": 0, "mean": None, "all_zero": True}
    return {
        "n": len(vals),
        "max": float(max(vals)),
        "sum": float(sum(vals)),
        "nonzero": int(sum(1 for v in vals if v > 0)),
        "mean": float(sum(vals) / len(vals)),
        "all_zero": bool(max(vals) <= 0 or sum(vals) <= 0),
    }


def decide(brand: str, kw: str, stats: dict, tops: list[str], risings: list[str], related_err: str) -> tuple[str, str]:
    if stats["n"] == 0 or stats["max"] is None:
        return "fail", "no_interest_series"
    if stats["all_zero"]:
        return "fail", "interest_all_zero_or_sparse"
    if stats["n"] and stats["nonzero"] / stats["n"] < 0.15 and (stats["mean"] or 0) < 2:
        return "fail", "interest_too_sparse"
    top_hits = hints_hit(brand, tops)
    if top_hits:
        return "fail", "related_wrong_entity:" + ",".join(top_hits)
    # If related queries clearly show the brand's product category, pass.
    if related_err and not tops:
        return "unchecked", "related_queries_unavailable"
    return "pass", "series_ok_related_ok"


def main():
    client = TrendsClient()
    rows = []
    print("starting trends checks", flush=True)
    for brand, queries in CHECKS:
        for kw in queries:
            try:
                time.sleep(SLEEP)
                data = client.interest_over_time(kw, TIMEFRAME, GEO)
                stats = series_stats(data.get("points") or [])
                tops = data.get("related_top") or []
                risings = data.get("related_rising") or []
                err = data.get("related_error") or ""
                status, reason = decide(brand, kw, stats, tops, risings, err)
                rec = {
                    "brand": brand,
                    "query": kw,
                    "status": status,
                    "reason": reason,
                    "n_weeks": stats["n"],
                    "max": stats["max"],
                    "mean": None if stats["mean"] is None else round(stats["mean"], 3),
                    "nonzero_weeks": stats["nonzero"],
                    "related_top": " | ".join(tops[:15]),
                    "related_rising": " | ".join(risings[:15]),
                    "related_error": err,
                    "timeframe": TIMEFRAME,
                    "geo": "WW",
                }
            except Exception as e:
                rec = {
                    "brand": brand,
                    "query": kw,
                    "status": "error",
                    "reason": type(e).__name__ + ":" + str(e)[:200],
                    "n_weeks": "",
                    "max": "",
                    "mean": "",
                    "nonzero_weeks": "",
                    "related_top": "",
                    "related_rising": "",
                    "related_error": type(e).__name__,
                    "timeframe": TIMEFRAME,
                    "geo": "WW",
                }
                msg = rec["reason"].lower()
                if "429" in msg or "sorry" in msg or "rate" in msg:
                    time.sleep(25)
            rows.append(rec)
            print(
                f"{brand} | {kw} -> {rec['status']} {rec['reason']} max={rec.get('max')} top={str(rec.get('related_top') or '')[:140]}",
                flush=True,
            )
            # persist incrementally
            fields = ["brand","query","status","reason","n_weeks","max","mean","nonzero_weeks","related_top","related_rising","related_error","timeframe","geo"]
            with DEST.open("w", newline="") as f:
                w = csv.DictWriter(f, fieldnames=fields)
                w.writeheader(); w.writerows(rows)
            with RAW.open("w") as f:
                for r in rows:
                    f.write(json.dumps(r, ensure_ascii=False) + "\n")
            if rec["status"] == "pass":
                break
    print("wrote", DEST, "rows", len(rows), flush=True)


if __name__ == "__main__":
    main()
