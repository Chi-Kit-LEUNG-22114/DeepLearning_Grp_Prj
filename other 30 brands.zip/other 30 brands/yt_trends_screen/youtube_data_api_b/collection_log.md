# YouTube public dataset — STAT6207 LC Home & Lifestyle shortlist B (YouTube Data API v3)

Collected 2026-11-21 12:23:08 HKT, with the official YouTube Data API v3 and an API key sent only in the x-goog-api-key header. The key is not stored in this folder.

This pull covers the second 30-brand verified shortlist in `../shortlist_30_b.csv`. Public metadata snapshot, not YouTube Analytics. First-round files in `../youtube_data_api/` and `../quota_units.json` were not written by this collector.

## Method

- Channels: `channels.list` with `part=snippet,statistics,contentDetails,brandingSettings`
- Uploads: `playlistItems.list` on each channel's uploads playlist, newest first
- Video metrics: `videos.list` with `part=snippet,statistics,contentDetails,status`
- Video window: published on or after 2023-11-21 UTC, newest first, cap of 2000 videos per channel
- Comment sample: videos published on or after 2025-11-21 UTC, up to 30 newest videos per channel that have a present non-zero `comment_count`, one page of up to 100 newest top-level threads plus any replies in the same response. An omitted `comment_count` is treated as missing, not zero. `commentThreads` 403 `commentsDisabled` is recorded in errors.json and collection continues.
- Estimated quota units used for this collection: 410 of a 5000-unit task cap (this collection starts at 0; earlier official pulls on the same Pacific-time quota day are counted separately toward the 10,000 daily quota).

## Coverage

- Channels written: 30
- Videos written: 3932
- Comment rows written: 1832

- AQUAZZURA: 53 videos in window (listed 54), comments=0 from 0 videos, reached_cutoff=True, truncated_at_cap=False
- DJI: 2000 videos in window (listed 2000), comments=470 from 30 videos, reached_cutoff=False, truncated_at_cap=True
- ELIE BLEU: 0 videos in window (listed 1), comments=0 from 0 videos, reached_cutoff=True, truncated_at_cap=False
- FOCAL: 57 videos in window (listed 58), comments=76 from 13 videos, reached_cutoff=True, truncated_at_cap=False
- LOMOGRAPHY: 88 videos in window (listed 89), comments=88 from 19 videos, reached_cutoff=True, truncated_at_cap=False
- MASTER & DYNAMIC: 5 videos in window (listed 6), comments=0 from 0 videos, reached_cutoff=True, truncated_at_cap=False
- POLAROID: 26 videos in window (listed 27), comments=18 from 3 videos, reached_cutoff=True, truncated_at_cap=False
- RIEDEL: 40 videos in window (listed 41), comments=15 from 2 videos, reached_cutoff=True, truncated_at_cap=False
- SPYRA: 161 videos in window (listed 162), comments=298 from 11 videos, reached_cutoff=True, truncated_at_cap=False. Note: 2/161 videos missing comment_count (omitted, not zero)
- STEELSERIES: 232 videos in window (listed 233), comments=344 from 30 videos, reached_cutoff=True, truncated_at_cap=False. Note: 2/232 videos missing like_count; 9/232 videos missing comment_count (omitted, not zero)
- TAITTINGER: 84 videos in window (listed 85), comments=0 from 0 videos, reached_cutoff=True, truncated_at_cap=False
- THERAGUN: 107 videos in window (listed 108), comments=35 from 13 videos, reached_cutoff=True, truncated_at_cap=False
- HENNESSY: 62 videos in window (listed 63), comments=1 from 1 videos, reached_cutoff=True, truncated_at_cap=False
- BUBEN&ZÖRWEG: 27 videos in window (listed 28), comments=8 from 7 videos, reached_cutoff=True, truncated_at_cap=False
- DE LE CUONA: 27 videos in window (listed 28), comments=0 from 0 videos, reached_cutoff=True, truncated_at_cap=False. Note: 6/27 videos missing like_count; 6/27 videos missing comment_count (omitted, not zero)
- GINGKO DESIGN: 40 videos in window (listed 41), comments=1 from 1 videos, reached_cutoff=True, truncated_at_cap=False
- GLAS ITALIA: 14 videos in window (listed 15), comments=0 from 0 videos, reached_cutoff=True, truncated_at_cap=False
- L'ATELIER DU VIN: 11 videos in window (listed 12), comments=0 from 0 videos, reached_cutoff=True, truncated_at_cap=False
- LAGUIOLE EN AUBRAC: 1 videos in window (listed 2), comments=0 from 0 videos, reached_cutoff=True, truncated_at_cap=False
- MATADOR: 72 videos in window (listed 73), comments=198 from 29 videos, reached_cutoff=True, truncated_at_cap=False
- MDF ITALIA: 21 videos in window (listed 22), comments=0 from 0 videos, reached_cutoff=True, truncated_at_cap=False
- OLYMPIA LE-TAN: 20 videos in window (listed 21), comments=2 from 2 videos, reached_cutoff=True, truncated_at_cap=False
- POJ STUDIO: 20 videos in window (listed 21), comments=7 from 1 videos, reached_cutoff=True, truncated_at_cap=False
- SHARGE: 83 videos in window (listed 84), comments=59 from 12 videos, reached_cutoff=True, truncated_at_cap=False
- SOCIETY LIMONTA: 9 videos in window (listed 10), comments=0 from 0 videos, reached_cutoff=True, truncated_at_cap=False
- STERN PINBALL: 529 videos in window (listed 530), comments=197 from 30 videos, reached_cutoff=True, truncated_at_cap=False. Note: 3/529 videos missing comment_count (omitted, not zero)
- STTOKE: 2 videos in window (listed 3), comments=1 from 1 videos, reached_cutoff=True, truncated_at_cap=False
- SUCK UK: 13 videos in window (listed 14), comments=5 from 5 videos, reached_cutoff=True, truncated_at_cap=False
- SUDIO: 75 videos in window (listed 76), comments=4 from 3 videos, reached_cutoff=True, truncated_at_cap=False
- ZENLET: 53 videos in window (listed 54), comments=5 from 3 videos, reached_cutoff=True, truncated_at_cap=False

## Errors

- None.

## Emoji stripping

After the API files were written, Unicode emoji, dingbats, emoticons, variation selectors, and ZWJ emoji sequences were removed from text fields in the CSV/JSON/Markdown files in this folder (notably comment text and video titles). Accented letters (for example Zörweg) and trademark signs such as ™ were kept. A cell that contained only emoji was left empty. A post-strip scan found zero remaining emoji in the delivered files.
