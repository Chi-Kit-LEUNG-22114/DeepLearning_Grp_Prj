# Lane Crawford Home & Lifestyle YouTube + Trends shortlist B

Second verified data-availability shortlist of **30** brands. None of these brands overlap the first shortlist of 30 in `shortlist_30.csv`. Universe: **403** unique brands on the live Lane Crawford HK Home & Lifestyle directory fetched 21 November 2026, 01:00 HKT from https://www.lanecrawford.com.hk/brand/home-lifestyle/ (saved as `lc_home_lifestyle_brands_live_2026-11-21.csv`). LANE CRAWFORD and LANE CRAWFORD TRAVEL were excluded as the retailer itself. This is an **availability shortlist, not a random sample**.

YouTube metrics are reused from the official YouTube Data API v3 three-metric screen already run on 21 November 2026 HKT (subscribers via `channels.list` statistics; likes and comments via `videos.list` field presence on a recent public-video sample). A value of 0 counts as present; a missing `likeCount` or `commentCount` field is a fail. No new 3-year video or comment collection was run for this second shortlist.

Google Trends checks for the 17 newly admitted brands were Worldwide (`geo` empty), last 5 years (`today 5-y`), run 21 November 2026, 12:03-12:12 HKT, using related queries plus interest-over-time completeness, with the same series rule as the first screen and the same Saint-Louis crystal sparsity bar (too few non-zero weeks and a very low mean). Brands with Celine-like name collision were excluded even if YouTube passed. The 13 brands that already dual-passed in the first screen but were held out of the first 30 were included here without re-pulling Trends.

Of 28 YouTube-pass brands that still needed Trends checks, 17 were admitted to this shortlist, 9 failed Trends (wrong entity or too-sparse series), and 2 were near-misses not selected (Paravel luggage would pass a specific query but the channel has 2 subscribers; Suzusan is slightly above the sparsity bar but has 72 subscribers and no related queries). No extra official-channel hunt was required to reach 30.

Subscriber counts may be rounded by YouTube. Alcohol brands (Taittinger, Hennessy) are often age-gated on consumer sites; the public Data API still returned the listed statistics.

Channel and recent-video thumbnails (official Data API `snippet.thumbnails` and `i.ytimg.com` CDN) are under `thumbnails_b/`. Contact sheets: `thumbnails_b/shortlist_30_b_channel_thumbs.png` and `thumbnails_b/shortlist_30_b_video_thumbs.png`.

| # | Brand | YouTube | Subscribers (public API) | Locked Trends query |
|---|-------|---------|--------------------------|---------------------|
| 1 | AQUAZZURA | [@aquazzuraofficial](https://www.youtube.com/@aquazzuraofficial) | 760 | `Aquazzura` |
| 2 | DJI | [@dji](https://www.youtube.com/@dji) | 6720000 | `DJI` |
| 3 | ELIE BLEU | [@eliebleu4576](https://www.youtube.com/@eliebleu4576) | 440 | `Elie Bleu` |
| 4 | FOCAL | [@focalofficial](https://www.youtube.com/@focalofficial) | 21800 | `Focal speakers` |
| 5 | LOMOGRAPHY | [@lomographicsociety](https://www.youtube.com/@lomographicsociety) | 28600 | `Lomography` |
| 6 | MASTER & DYNAMIC | [@masterdynamic](https://www.youtube.com/@masterdynamic) | 3450 | `Master and Dynamic` |
| 7 | POLAROID | [@polaroidofficial](https://www.youtube.com/@polaroidofficial) | 28400 | `Polaroid` |
| 8 | RIEDEL | [@riedelthewineglasscompany](https://www.youtube.com/@riedelthewineglasscompany) | 5250 | `Riedel` |
| 9 | SPYRA | [@spyra_official](https://www.youtube.com/@spyra_official) | 57500 | `Spyra` |
| 10 | STEELSERIES | [@steelseries](https://www.youtube.com/@steelseries) | 200000 | `SteelSeries` |
| 11 | TAITTINGER | [@champagnetaittinger](https://www.youtube.com/@champagnetaittinger) | 868 | `Taittinger` |
| 12 | THERAGUN | [@therabody](https://www.youtube.com/@therabody) | 28700 | `Theragun` |
| 13 | HENNESSY | [@hennessyofficial](https://www.youtube.com/@hennessyofficial) | 52300 | `Hennessy` |
| 14 | BUBEN&ZÖRWEG | [@buben-zorweg](https://www.youtube.com/@buben-zorweg) | 1160 | `Buben Zorweg` |
| 15 | DE LE CUONA | [@delecuona.](https://www.youtube.com/@delecuona.) | 134 | `De Le Cuona` |
| 16 | GINGKO DESIGN | [@gingkodesign](https://www.youtube.com/@gingkodesign) | 1000 | `Gingko Design` |
| 17 | GLAS ITALIA | [@glasitalia1105](https://www.youtube.com/@glasitalia1105) | 414 | `Glas Italia` |
| 18 | L'ATELIER DU VIN | [@latelierduvin](https://www.youtube.com/@latelierduvin) | 211 | `L'Atelier du Vin` |
| 19 | LAGUIOLE EN AUBRAC | [@laguioleenaubrac](https://www.youtube.com/@laguioleenaubrac) | 397 | `Laguiole en Aubrac` |
| 20 | MATADOR | [@matador_equipment](https://www.youtube.com/@matador_equipment) | 10500 | `Matador equipment` |
| 21 | MDF ITALIA | [@mdfitaliaitfurniture](https://www.youtube.com/@mdfitaliaitfurniture) | 748 | `MDF Italia` |
| 22 | OLYMPIA LE-TAN | [@olympialetanofficial](https://www.youtube.com/@olympialetanofficial) | 131 | `Olympia Le Tan` |
| 23 | POJ STUDIO | [@pojstudiokyoto](https://www.youtube.com/@pojstudiokyoto) | 4900 | `POJ Studio` |
| 24 | SHARGE | [@sharge_official](https://www.youtube.com/@sharge_official) | 4820 | `Sharge` |
| 25 | SOCIETY LIMONTA | [@society-limonta](https://www.youtube.com/@society-limonta) | 161 | `Society Limonta` |
| 26 | STERN PINBALL | [@sternpinballinc](https://www.youtube.com/@sternpinballinc) | 38800 | `Stern Pinball` |
| 27 | STTOKE | [@sttokeofficial](https://www.youtube.com/@sttokeofficial) | 232 | `Sttoke` |
| 28 | SUCK UK | [@suckuklondon](https://www.youtube.com/@suckuklondon) | 399 | `Suck UK` |
| 29 | SUDIO | [@sudio8600](https://www.youtube.com/@sudio8600) | 1210 | `Sudio headphones` |
| 30 | ZENLET | [@zenlet](https://www.youtube.com/@zenlet) | 1510 | `Zenlet` |

## Per-brand YouTube sample and notes

### AQUAZZURA

- Lane Crawford: https://www.lanecrawford.com.hk/brand/24600003/aquazzura/lifestyle/
- YouTube: https://www.youtube.com/@aquazzuraofficial (`UCEQDGk6sU4gQ_Ceaptr11kA`)
- Subscribers: 760 (public API; may be rounded)
- Recent videos checked: 15; likes field present on 15; comments field present on 15
- Locked Trends query: `Aquazzura` (Worldwide, today 5-y) — pass
- Prior official YouTube three-metric screen from 21 Nov 2026 HKT reused (no new video/comment pull). Official site aquazzura.com links this channel. First-round Worldwide Trends related queries are the fashion house (not reused as a first-30 brand). Evidence: official_site https://www.aquazzura.com/.

### DJI

- Lane Crawford: https://www.lanecrawford.com.hk/brand/34900008/dji/lifestyle/
- YouTube: https://www.youtube.com/@dji (`UCsNGtpqGsyw0U6qEG-WHadA`)
- Subscribers: 6720000 (public API; may be rounded)
- Recent videos checked: 15; likes field present on 15; comments field present on 15
- Locked Trends query: `DJI` (Worldwide, today 5-y) — pass
- Prior official YouTube three-metric screen from 21 Nov 2026 HKT reused. Official site dji.com links this channel. Locked query DJI; first-round related queries were the camera/drone company. Evidence: official_site https://www.dji.com/.

### ELIE BLEU

- Lane Crawford: https://www.lanecrawford.com.hk/brand/88103754/elie-bleu/lifestyle/
- YouTube: https://www.youtube.com/@eliebleu4576 (`UC7Jr4h-OkULj2TxFEYC-YTw`)
- Subscribers: 440 (public API; may be rounded)
- Recent videos checked: 7; likes field present on 7; comments field present on 7
- Locked Trends query: `Elie Bleu` (Worldwide, today 5-y) — pass
- Prior official YouTube three-metric screen from 21 Nov 2026 HKT reused. Official site eliebleu.com links this channel. First-round Trends related queries matched the humidor/accessories house. Somewhat smaller channel (440 public subscribers). Evidence: official_site https://www.eliebleu.com/.

### FOCAL

- Lane Crawford: https://www.lanecrawford.com.hk/brand/109703753/focal/lifestyle/
- YouTube: https://www.youtube.com/@focalofficial (`UC-kXA30N76cKmcpKSwE94cw`)
- Subscribers: 21800 (public API; may be rounded)
- Recent videos checked: 15; likes field present on 15; comments field present on 15
- Locked Trends query: `Focal speakers` (Worldwide, today 5-y) — pass
- Prior official YouTube three-metric screen from 21 Nov 2026 HKT reused. Official site focal.com links this channel. Bare Focal was not used; locked query Focal speakers to avoid focal-length/optics senses. Evidence: official_site https://www.focal.com/.

### LOMOGRAPHY

- Lane Crawford: https://www.lanecrawford.com.hk/brand/29100005/lomography/lifestyle/
- YouTube: https://www.youtube.com/@lomographicsociety (`UCuClVwSDvx65IPPQyFHrs1A`)
- Subscribers: 28600 (public API; may be rounded)
- Recent videos checked: 15; likes field present on 15; comments field present on 15
- Locked Trends query: `Lomography` (Worldwide, today 5-y) — pass
- Prior official YouTube three-metric screen from 21 Nov 2026 HKT reused. Official site lomography.com links this channel. First-round Trends related queries were cameras/film. Evidence: official_site https://www.lomography.com/.

### MASTER & DYNAMIC

- Lane Crawford: https://www.lanecrawford.com.hk/brand/37800002/master-dynamic/lifestyle/
- YouTube: https://www.youtube.com/@masterdynamic (`UCOcUBfuHBD5EfVpw5Mol4_w`)
- Subscribers: 3450 (public API; may be rounded)
- Recent videos checked: 15; likes field present on 15; comments field present on 15
- Locked Trends query: `Master and Dynamic` (Worldwide, today 5-y) — pass
- Prior official YouTube three-metric screen from 21 Nov 2026 HKT reused. Official site masterdynamic.com links this channel. Locked ASCII query Master and Dynamic. Evidence: official_site https://www.masterdynamic.com/.

### POLAROID

- Lane Crawford: https://www.lanecrawford.com.hk/brand/29100006/polaroid/lifestyle/
- YouTube: https://www.youtube.com/@polaroidofficial (`UCpCw0nllY4Jq9PH0mC2lyKA`)
- Subscribers: 28400 (public API; may be rounded)
- Recent videos checked: 15; likes field present on 15; comments field present on 15
- Locked Trends query: `Polaroid` (Worldwide, today 5-y) — pass
- Prior official YouTube three-metric screen from 21 Nov 2026 HKT reused. Official site polaroid.com links this channel. First-round Trends related queries were the camera/instant-film brand. Evidence: official_site https://www.polaroid.com/.

### RIEDEL

- Lane Crawford: https://www.lanecrawford.com.hk/brand/700446/riedel/lifestyle/
- YouTube: https://www.youtube.com/@riedelthewineglasscompany (`UCydDCtx1AMNY4crLbIJpgKQ`)
- Subscribers: 5250 (public API; may be rounded)
- Recent videos checked: 15; likes field present on 15; comments field present on 15
- Locked Trends query: `Riedel` (Worldwide, today 5-y) — pass
- Prior official YouTube three-metric screen from 21 Nov 2026 HKT reused. Official site riedel.com links this channel. First-round related queries were the wine-glass company (not Riedel Communications). Evidence: official_site https://www.riedel.com/.

### SPYRA

- Lane Crawford: https://www.lanecrawford.com.hk/brand/133103753/spyra/lifestyle/
- YouTube: https://www.youtube.com/@spyra_official (`UCkPwZZxEr2RLOYkk1tOTrHQ`)
- Subscribers: 57500 (public API; may be rounded)
- Recent videos checked: 15; likes field present on 15; comments field present on 15
- Locked Trends query: `Spyra` (Worldwide, today 5-y) — pass
- Prior official YouTube three-metric screen from 21 Nov 2026 HKT reused. Official site spyra.com links this channel. First-round Trends related queries matched the water-blaster brand. Evidence: official_site https://spyra.com/.

### STEELSERIES

- Lane Crawford: https://www.lanecrawford.com.hk/brand/94303757/steelseries/lifestyle/
- YouTube: https://www.youtube.com/@steelseries (`UC541jp3JO5e09cPtTcOImiQ`)
- Subscribers: 200000 (public API; may be rounded)
- Recent videos checked: 15; likes field present on 15; comments field present on 15
- Locked Trends query: `SteelSeries` (Worldwide, today 5-y) — pass
- Prior official YouTube three-metric screen from 21 Nov 2026 HKT reused. Official site steelseries.com links this channel. First-round Trends related queries were gaming peripherals. Evidence: official_site https://steelseries.com/.

### TAITTINGER

- Lane Crawford: https://www.lanecrawford.com.hk/brand/91703753/taittinger/lifestyle/
- YouTube: https://www.youtube.com/@champagnetaittinger (`UCXUF1Gy6eSLieEEelZa9s2Q`)
- Subscribers: 868 (public API; may be rounded)
- Recent videos checked: 15; likes field present on 15; comments field present on 15
- Locked Trends query: `Taittinger` (Worldwide, today 5-y) — pass
- Prior official YouTube three-metric screen from 21 Nov 2026 HKT reused. Official site taittinger.com links this channel. Age-gated alcohol brand. First-round Trends related queries were champagne. Evidence: official_site https://www.taittinger.com/.

### THERAGUN

- Lane Crawford: https://www.lanecrawford.com.hk/brand/69103756/theragun/lifestyle/
- YouTube: https://www.youtube.com/@therabody (`UCgA-nI5zzB38T_OsRK9030A`)
- Subscribers: 28700 (public API; may be rounded)
- Recent videos checked: 15; likes field present on 15; comments field present on 15
- Locked Trends query: `Theragun` (Worldwide, today 5-y) — pass
- Prior official YouTube three-metric screen from 21 Nov 2026 HKT reused. Official Theragun/Therabody site links the official Therabody channel (@therabody). Locked query Theragun from the first-round Trends pass. Evidence: official_site https://www.therabody.com/.

### HENNESSY

- Lane Crawford: https://www.lanecrawford.com.hk/brand/26500007/hennessy/lifestyle/
- YouTube: https://www.youtube.com/@hennessyofficial (`UCXZTMQJa-x3jTYqaEQEUV4g`)
- Subscribers: 52300 (public API; may be rounded)
- Recent videos checked: 15; likes field present on 15; comments field present on 15
- Locked Trends query: `Hennessy` (Worldwide, today 5-y) — pass
- Prior official YouTube three-metric screen from 21 Nov 2026 HKT reused. Official channel confirmed via LinkedIn plus handle and Data API title. Age-gated alcohol brand. Evidence: linkedin_plus_handle https://www.linkedin.com/company/hennessy.

### BUBEN&ZÖRWEG

- Lane Crawford: https://www.lanecrawford.com.hk/brand/150014/buben-z-rweg/lifestyle/
- YouTube: https://www.youtube.com/@buben-zorweg (`UCvHxUwqz24sKleua-6Wa9IA`)
- Subscribers: 1160 (public API; may be rounded)
- Recent videos checked: 15; likes field present on 15; comments field present on 15
- Locked Trends query: `Buben Zorweg` (Worldwide, today 5-y) — pass
- Official site buben-zorweg.com links this channel. Query 'Buben and Zorweg' was too sparse (5/261 weeks non-zero, mean 1.172). Locked query 'Buben Zorweg' related only to 'buben and zorweg'. Series is modest (66/261 non-zero weeks, mean 5.958) but above the Saint-Louis crystal sparsity bar.

### DE LE CUONA

- Lane Crawford: https://www.lanecrawford.com.hk/brand/111803753/de-le-cuona/lifestyle/
- YouTube: https://www.youtube.com/@delecuona. (`UCdkpGCVF0QRCNR6KYm4BV1g`)
- Subscribers: 134 (public API; may be rounded)
- Recent videos checked: 15; likes field present on 15; comments field present on 14
- Locked Trends query: `De Le Cuona` (Worldwide, today 5-y) — pass
- Official site delecuona.com links this channel. Locked query related queries are de le cuona fabric/fabrics and founder Bernie de le Cuona. Non-zero weeks 60/261, mean 14.192.

### GINGKO DESIGN

- Lane Crawford: https://www.lanecrawford.com.hk/brand/129203764/gingko-design/lifestyle/
- YouTube: https://www.youtube.com/@gingkodesign (`UCDkwXqWRPB7ljCztVfTpnmA`)
- Subscribers: 1000 (public API; may be rounded)
- Recent videos checked: 15; likes field present on 15; comments field present on 15
- Locked Trends query: `Gingko Design` (Worldwide, today 5-y) — pass
- Official site gingkodesign.com links this channel. Locked query is the two-word brand name, not bare Gingko/Ginkgo. Interest series 46/261 non-zero weeks, mean 10.808; Google returned no related queries, so entity confirmation is from the specific phrase and series only.

### GLAS ITALIA

- Lane Crawford: https://www.lanecrawford.com.hk/brand/69668/glas-italia/lifestyle/
- YouTube: https://www.youtube.com/@glasitalia1105 (`UCFUD5dRFSR0BlemSSv5M0VQ`)
- Subscribers: 414 (public API; may be rounded)
- Recent videos checked: 15; likes field present on 15; comments field present on 15
- Locked Trends query: `Glas Italia` (Worldwide, today 5-y) — pass
- Official site glasitalia.com links this channel. Locked query related queries include glas italia dining table. Series is dense (260/261 non-zero weeks, mean 37.28).

### L'ATELIER DU VIN

- Lane Crawford: https://www.lanecrawford.com.hk/brand/1400186/l-atelier-du-vin/lifestyle/
- YouTube: https://www.youtube.com/@latelierduvin (`UC9FH4HWP6c8T2P6KZnE1fvQ`)
- Subscribers: 211 (public API; may be rounded)
- Recent videos checked: 15; likes field present on 15; comments field present on 15
- Locked Trends query: `L'Atelier du Vin` (Worldwide, today 5-y) — pass
- Official site atelierduvin.com links this channel. Related queries are the wine-opener/accessories brand plus retail locations (Brighton, Abbeville, Carrefour).

### LAGUIOLE EN AUBRAC

- Lane Crawford: https://www.lanecrawford.com.hk/brand/100203754/laguiole-en-aubrac/lifestyle/
- YouTube: https://www.youtube.com/@laguioleenaubrac (`UCFfDUsWGPjz8VgFBH-wbL3w`)
- Subscribers: 397 (public API; may be rounded)
- Recent videos checked: 6; likes field present on 6; comments field present on 6
- Locked Trends query: `Laguiole en Aubrac` (Worldwide, today 5-y) — pass
- Official site laguiole-en-aubrac.fr links this channel. Bare Laguiole was not used. Related queries are knives, corkscrews and cutlery from this maker.

### MATADOR

- Lane Crawford: https://www.lanecrawford.com.hk/brand/124803753/matador/lifestyle/
- YouTube: https://www.youtube.com/@matador_equipment (`UCt74XhA7X0Q6EojB3AhoRtg`)
- Subscribers: 10500 (public API; may be rounded)
- Recent videos checked: 15; likes field present on 15; comments field present on 15
- Locked Trends query: `Matador equipment` (Worldwide, today 5-y) — pass
- Official site matadorup.com links @matador_equipment. Bare Matador was not used (bullfighting, records, cars). Locked query 'Matador equipment': 55/261 non-zero weeks, mean 11.989; Google returned no related queries, so collision could not be re-checked from related terms.

### MDF ITALIA

- Lane Crawford: https://www.lanecrawford.com.hk/brand/142703759/mdf-italia/lifestyle/
- YouTube: https://www.youtube.com/@mdfitaliaitfurniture (`UChHHxZNE-TtDdYEgMdHxMpw`)
- Subscribers: 748 (public API; may be rounded)
- Recent videos checked: 15; likes field present on 15; comments field present on 15
- Locked Trends query: `MDF Italia` (Worldwide, today 5-y) — pass
- Official site mdfitalia.com links this channel. Bare MDF was not used. Related queries are brand products (Tense table, Flow chair, furniture). One related term mentions MDF as a material ('cinza italia mdf') but the list is led by the furniture house.

### OLYMPIA LE-TAN

- Lane Crawford: https://www.lanecrawford.com.hk/brand/52503755/olympia-le-tan/lifestyle/
- YouTube: https://www.youtube.com/@olympialetanofficial (`UCpiTCJeiF3ceJo_upvAmv2w`)
- Subscribers: 131 (public API; may be rounded)
- Recent videos checked: 15; likes field present on 15; comments field present on 15
- Locked Trends query: `Olympia Le Tan` (Worldwide, today 5-y) — pass
- Official site olympialetan.com links this channel. Related queries are clutch/book/bags. A minor related term 'hotel olympia le tan' appears; the list is otherwise the fashion brand.

### POJ STUDIO

- Lane Crawford: https://www.lanecrawford.com.hk/brand/124103753/poj-studio/lifestyle/
- YouTube: https://www.youtube.com/@pojstudiokyoto (`UCMvhhkiketG53DOu3OvEx0g`)
- Subscribers: 4900 (public API; may be rounded)
- Recent videos checked: 15; likes field present on 15; comments field present on 15
- Locked Trends query: `POJ Studio` (Worldwide, today 5-y) — pass
- Official site pojstudio.com links this channel. Interest series is modest (36/261 non-zero weeks, mean 6.199) but above the Saint-Louis crystal sparsity bar; Google returned no related queries.

### SHARGE

- Lane Crawford: https://www.lanecrawford.com.hk/brand/123203753/sharge/lifestyle/
- YouTube: https://www.youtube.com/@sharge_official (`UCtWMZEAOSWhZIDOdwMG7JaQ`)
- Subscribers: 4820 (public API; may be rounded)
- Recent videos checked: 15; likes field present on 15; comments field present on 15
- Locked Trends query: `Sharge` (Worldwide, today 5-y) — pass
- Official site sharge.com links this channel. Related queries are the brand's power banks, SSD enclosures and IceMag/Flow products.

### SOCIETY LIMONTA

- Lane Crawford: https://www.lanecrawford.com.hk/brand/700315/society-limonta/lifestyle/
- YouTube: https://www.youtube.com/@society-limonta (`UCepEorQyECPiZSEGN91U33A`)
- Subscribers: 161 (public API; may be rounded)
- Recent videos checked: 15; likes field present on 15; comments field present on 15
- Locked Trends query: `Society Limonta` (Worldwide, today 5-y) — pass
- Official site societylimonta.com links this channel. Related queries include society limonta wien (a stockist/city term) with no other-entity collision visible. Series 178/261 non-zero weeks, mean 34.034.

### STERN PINBALL

- Lane Crawford: https://www.lanecrawford.com.hk/brand/81503754/stern-pinball/lifestyle/
- YouTube: https://www.youtube.com/@sternpinballinc (`UCxpi_Z_1emaKs909Oiop_-A`)
- Subscribers: 38800 (public API; may be rounded)
- Recent videos checked: 15; likes field present on 15; comments field present on 15
- Locked Trends query: `Stern Pinball` (Worldwide, today 5-y) — pass
- Official site sternpinball.com links this channel. Bare Stern was not used. Related queries are pinball machines (Godzilla, Star Wars, Fallout, etc.).

### STTOKE

- Lane Crawford: https://www.lanecrawford.com.hk/brand/82003753/sttoke/lifestyle/
- YouTube: https://www.youtube.com/@sttokeofficial (`UChntzwYDNa_NFqP92vRIO0g`)
- Subscribers: 232 (public API; may be rounded)
- Recent videos checked: 15; likes field present on 15; comments field present on 15
- Locked Trends query: `Sttoke` (Worldwide, today 5-y) — pass
- Official site sttoke.com links this channel. Related queries are the uniquely spelled cup/tumbler brand (including Japanese and Chinese product terms).

### SUCK UK

- Lane Crawford: https://www.lanecrawford.com.hk/brand/56703776/suck-uk/lifestyle/
- YouTube: https://www.youtube.com/@suckuklondon (`UCoxOcuAS--hXOcCfipElA1w`)
- Subscribers: 399 (public API; may be rounded)
- Recent videos checked: 15; likes field present on 15; comments field present on 15
- Locked Trends query: `Suck UK` (Worldwide, today 5-y) — pass
- Official site suck.uk.com links this channel. First related-queries call returned HTTP 429; a retry the same day returned suck uk ltd, suck uk design, and suck uk cat (the gift/design company). Series is dense (261/261 non-zero weeks, mean 35.556).

### SUDIO

- Lane Crawford: https://www.lanecrawford.com.hk/brand/65403753/sudio/lifestyle/
- YouTube: https://www.youtube.com/@sudio8600 (`UCWf5NCzMk7GI0XNNJ6tTS5w`)
- Subscribers: 1210 (public API; may be rounded)
- Recent videos checked: 15; likes field present on 15; comments field present on 15
- Locked Trends query: `Sudio headphones` (Worldwide, today 5-y) — pass
- Official site sudio.com links this channel. Bare 'Sudio' related queries mixed genuine earbud models with typo collisions for Visual Studio, Google AI Studio and FL Studio. Locked query 'Sudio headphones' related only to 'sudio headphones review'. Series 147/261 non-zero weeks, mean 29.831.

### ZENLET

- Lane Crawford: https://www.lanecrawford.com.hk/brand/132303753/zenlet/lifestyle/
- YouTube: https://www.youtube.com/@zenlet (`UCZcO6_up-wqzcn6WskqjG5A`)
- Subscribers: 1510 (public API; may be rounded)
- Recent videos checked: 15; likes field present on 15; comments field present on 15
- Locked Trends query: `Zenlet` (Worldwide, today 5-y) — pass
- Official site zenlet.co links this channel. Related queries are wallet products (Zenlet 2/3, Dual Plus).

## Caveats

- Availability screening only; not a probability sample of the 403-brand universe and not a random subset of YouTube-pass brands.
- Gingko Design, Matador (query: Matador equipment) and POJ Studio returned no Google related-queries list; admission rests on a specific phrase plus an interest series above the Saint-Louis sparsity bar.
- Buben Zorweg and POJ Studio have relatively modest non-zero-week counts (66/261 and 36/261). De Le Cuona is 60/261.
- De Le Cuona comments field was present on 14 of 15 recent videos (still a YouTube pass under the sample rule).
- Bare Sudio was rejected for Visual Studio / AI Studio / FL Studio typo collisions; the locked query is Sudio headphones.
- Taittinger and Hennessy are age-gated alcohol brands.
- Theragun is represented by the official Therabody channel.
- Official-channel evidence for Hennessy is LinkedIn plus handle, confirmed in the Data API, not an official-site footer backlink.
- Thumbnail paths are in the CSV columns `channel_thumbnail_path` and `video_thumbnail_path`. Contact sheets: `thumbnails_b/shortlist_30_b_channel_thumbs.png` and `thumbnails_b/shortlist_30_b_video_thumbs.png`. The official Suck UK channel avatar is an all-white 800x800 image, so it appears as a blank square on the channel sheet.

## Near-misses and Trends fails among the 28 newly checked brands

YouTube already passed for all 28. Decisions below are Trends and selection only.

- **DE LA ESPADA: MATTHEW HILTON** (Trends fail; 141 public subscribers): Bare 'De La Espada' related queries are Spanish 'of the sword' titles, King Arthur 'leyenda de la espada', and web-novel/sword-clan phrases, not the furniture house. 'Matthew Hilton furniture' too sparse (2/261, mean 0.747); 'De La Espada furniture' too sparse (5/261, mean 1.222).
- **GHIDINI 1961** (Trends fail; 66 public subscribers): Interest too sparse: 6/261 non-zero weeks, mean 1.034, no related queries. Below the Saint-Louis crystal sparsity bar.
- **HALO EDITION** (Trends fail; 259 public subscribers): Bare 'Halo Edition' related queries are Xbox Series X Halo / Halo Infinite console editions (wrong entity). Alternative 'Halo Edition lighting' too sparse (11/261 non-zero, mean 2.238, no related queries).
- **HANOIA** (Trends fail; 667 public subscribers): Related queries are 'la table hanoia' (the lacquer brand's own Hanoi restaurant) and 'hanoia melbourne', a different Northern Vietnamese restaurant in Melbourne documented in local press. Name collision with another entity.
- **KRISTJANA S WILLIAMS** (Trends fail; 205 public subscribers): 'Kristjana S Williams' too sparse (2/261, mean 0.414). Best alternative 'Kristjana Williams' still too sparse (17/261 non-zero, mean 4.0, no related queries), in the same range as the Saint-Louis crystal fail (20/262, mean ~3.1).
- **LOCOMOCEAN** (Trends fail; 12 public subscribers): Interest too sparse: 9/261 non-zero weeks, mean 1.889, below the Saint-Louis bar (related queries were on-brand neon/lightbox terms). Channel also has only 12 public subscribers.
- **MANKS** (Trends fail; 198 public subscribers): Bare 'Manks' related queries mix Manx-cat terms (manks kedisi, manks cat, kot manks), Manks Road, No Manks Sky, Grupo Manks / Richard Manks with only some Manks HK furniture terms. 'Manks Hong Kong' and 'Manks furniture' returned no interest series (n=0) on two attempts; 'Manks HK' was too sparse (1/261, mean 0.383).
- **NINM LAB** (Trends fail; 376 public subscribers): Related queries are on-brand (cassette player, CD player, It's Real) but the series is too sparse: 13/261 non-zero weeks, mean 3.372, at or below the Saint-Louis crystal bar (20/262, mean ~3.1).
- **TECKELL** (Trends fail; 74 public subscribers): Interest too sparse: 12/261 non-zero weeks, mean 2.69, no related queries. Below the Saint-Louis crystal sparsity bar. Channel has 74 public subscribers.
- **PARAVEL** (near-miss, not selected; 2 public subscribers): Bare 'Paravel' related queries include Cair Paravel / Narnia and a Latin school alongside luggage. Alternative 'Paravel luggage' has clean related queries ('paravel luggage reviews') and a dense series (236/261, mean 35.874), but the official channel has only 2 public subscribers and was not used once 30 stronger dual-pass brands were available. Recorded as a Trends near-miss, not placed on the shortlist.
- **SUZUSAN** (near-miss, not selected; 72 public subscribers): Auto series check passed (28/261 non-zero, mean 6.395, no related queries) and is slightly above the Saint-Louis bar, but the official channel has only 72 public subscribers and no related queries for entity confirmation. Not selected once 30 stronger dual-pass brands were available. Near-miss.

