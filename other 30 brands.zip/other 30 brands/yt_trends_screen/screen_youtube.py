#!/usr/bin/env python3
"""Screen official YouTube channels for subscriber/like/comment field presence.

Uses only the official YouTube Data API v3. The API key is read from
YOUTUBE_API_KEY and sent only as x-goog-api-key. It is never written out.
"""
from __future__ import annotations

import csv
import json
import re
import sys
import time
from pathlib import Path

import requests

# Local client (no key in this file)
sys.path.insert(0, str(Path(__file__).resolve().parent))
from youtube_api_client import (  # noqa: E402
    OUT,
    YouTubeClient,
    now_hkt,
    parse_channel_url,
    pick_channel_item,
)

CANDIDATES = OUT / "screen_candidates.csv"
LOG = OUT / "screening_yt_raw.csv"
JSONL = OUT / "screening_yt_raw.jsonl"
UA = "Mozilla/5.0 (compatible; STAT6207-research/1.0)"


def resolve_custom_channel_id(url: str) -> str | None:
    """Identify a channel ID from a public YouTube channel page (not metrics)."""
    try:
        r = requests.get(
            url,
            headers={"User-Agent": UA, "Accept-Language": "en-US,en;q=0.9"},
            timeout=20,
            allow_redirects=True,
        )
    except requests.RequestException:
        return None
    text = r.text or ""
    m = re.search(r'<link rel="canonical" href="https://www\.youtube\.com/channel/(UC[\w-]+)"', text)
    if m:
        return m.group(1)
    m = re.search(r'"channelId":"(UC[\w-]+)"', text)
    if m:
        return m.group(1)
    m = re.search(r"youtube\.com/channel/(UC[\w-]+)", text)
    if m:
        return m.group(1)
    return None


def channel_lookup(client: YouTubeClient, url: str) -> tuple[dict, str]:
    parsed = parse_channel_url(url)
    data = {"items": []}
    method = parsed["type"]
    if parsed["type"] == "id":
        data = client.channels_by_id(parsed["value"])
    elif parsed["type"] == "handle":
        data = client.channels_by_handle(parsed["value"])
    elif parsed["type"] == "username":
        data = client.channels_by_username(parsed["value"])
        if not pick_channel_item(data):
            # Legacy usernames sometimes now only work as handles/custom.
            data2 = client.channels_by_handle("@" + parsed["value"])
            if pick_channel_item(data2):
                data, method = data2, "username_as_handle"
    elif parsed["type"] == "custom":
        data = client.channels_by_handle("@" + parsed["value"])
        method = "custom_as_handle"
        if not pick_channel_item(data):
            cid = resolve_custom_channel_id(url)
            if cid:
                data = client.channels_by_id(cid)
                method = "custom_html_id"
            else:
                method = "custom_unresolved"
    else:
        # try handle-like
        cid = resolve_custom_channel_id(url)
        if cid:
            data = client.channels_by_id(cid)
            method = "html_id"
    return data, method


def official_signals(item: dict, brand: str) -> dict:
    snippet = item.get("snippet") or {}
    branding = (item.get("brandingSettings") or {}).get("channel") or {}
    title = snippet.get("title") or ""
    desc = (snippet.get("description") or "") + "\n" + (branding.get("description") or "")
    custom = (snippet.get("customUrl") or branding.get("unsubscribedTrailer") or "")
    # website is not always present; sometimes in description
    urls = re.findall(r"https?://[^\s]+", desc)
    title_l = title.lower()
    brand_l = brand.lower()
    # loose token overlap
    brand_tokens = [t for t in re.split(r"[^a-z0-9]+", brand_l) if t and t not in {"and", "the", "de", "la", "le", "du", "of"}]
    title_hit = all(t in title_l for t in brand_tokens[:2]) if brand_tokens else False
    return {
        "channel_title": title,
        "custom_url": snippet.get("customUrl") or "",
        "description_urls": " ".join(urls[:6]),
        "title_matches_brand": str(title_hit),
    }


def screen_one(client: YouTubeClient, row: dict) -> dict:
    brand = row["brand"]
    url = row["youtube_url"]
    out = {
        "brand": brand,
        "lc_checked": "yes",
        "youtube_url_input": url,
        "evidence_url": row.get("evidence_url") or "",
        "evidence_type": row.get("evidence_type") or "",
        "lookup_method": "",
        "channel_id": "",
        "youtube_handle": "",
        "youtube_url": "",
        "channel_title": "",
        "custom_url": "",
        "subscriber_count": "",
        "hidden_subscriber_count": "",
        "video_count": "",
        "uploads_playlist_id": "",
        "n_recent_videos_checked": "0",
        "n_with_likes": "0",
        "n_with_comments": "0",
        "likes_ok": "no",
        "comments_ok": "no",
        "subs_ok": "no",
        "youtube_status": "fail",
        "youtube_fail_reason": "",
        "title_matches_brand": "",
        "description_urls": "",
        "notes": row.get("notes") or "",
        "retrieved_at_hkt": now_hkt(),
        "api_error": "",
    }
    try:
        data, method = channel_lookup(client, url)
    except Exception as e:
        out["lookup_method"] = "error"
        out["youtube_fail_reason"] = "api_error"
        out["api_error"] = type(e).__name__
        return out
    out["lookup_method"] = method
    if data.get("_error"):
        out["api_error"] = str(data.get("_reason") or data.get("_error") or "")[:200]
    item = pick_channel_item(data)
    if not item:
        out["youtube_fail_reason"] = "channel_not_resolved"
        return out

    snippet = item.get("snippet") or {}
    stats = item.get("statistics") or {}
    content = item.get("contentDetails") or {}
    sig = official_signals(item, brand)
    out.update({k: sig[k] for k in sig})
    out["channel_id"] = item.get("id") or ""
    custom = (snippet.get("customUrl") or "").strip()
    out["custom_url"] = custom
    if custom.startswith("@"):
        out["youtube_handle"] = custom
        out["youtube_url"] = f"https://www.youtube.com/{custom}"
    else:
        out["youtube_handle"] = custom
        out["youtube_url"] = f"https://www.youtube.com/channel/{out['channel_id']}" if out["channel_id"] else url

    hidden = stats.get("hiddenSubscriberCount")
    out["hidden_subscriber_count"] = str(hidden)
    if "subscriberCount" in stats:
        out["subscriber_count"] = stats.get("subscriberCount")
        out["subs_ok"] = "yes"
    elif hidden is True:
        out["subs_ok"] = "no"
        out["youtube_fail_reason"] = "hidden_subs"
    else:
        out["subs_ok"] = "no"
        out["youtube_fail_reason"] = "subscriberCount_missing"

    out["video_count"] = stats.get("videoCount") or ""
    uploads = ((content.get("relatedPlaylists") or {}).get("uploads")) or ""
    out["uploads_playlist_id"] = uploads

    video_ids: list[str] = []
    if uploads:
        plist = client.playlist_items(uploads, max_results=15)
        if plist.get("_error"):
            out["api_error"] = (out["api_error"] + " " + str(plist.get("_reason") or plist.get("_error"))).strip()[:200]
        for it in plist.get("items") or []:
            vid = ((it.get("contentDetails") or {}).get("videoId")) or ((it.get("snippet") or {}).get("resourceId") or {}).get("videoId")
            if vid and vid not in video_ids:
                video_ids.append(vid)
    out["n_recent_videos_checked"] = str(len(video_ids))

    n_likes = 0
    n_comments = 0
    if video_ids:
        vdata = client.videos_list(video_ids)
        if vdata.get("_error"):
            out["api_error"] = (out["api_error"] + " " + str(vdata.get("_reason") or vdata.get("_error"))).strip()[:200]
        for v in vdata.get("items") or []:
            st = v.get("statistics") or {}
            if "likeCount" in st:
                n_likes += 1
            if "commentCount" in st:
                n_comments += 1
    out["n_with_likes"] = str(n_likes)
    out["n_with_comments"] = str(n_comments)
    n = len(video_ids)
    need = 3 if n >= 3 else max(n, 1)
    if n == 0:
        out["likes_ok"] = "no"
        out["comments_ok"] = "no"
        reasons = [out["youtube_fail_reason"]] if out["youtube_fail_reason"] else []
        reasons.append("no_recent_public_videos")
        out["youtube_fail_reason"] = ";".join([r for r in reasons if r])
    else:
        out["likes_ok"] = "yes" if n_likes >= need else "no"
        out["comments_ok"] = "yes" if n_comments >= need else "no"
        reasons = [out["youtube_fail_reason"]] if out["youtube_fail_reason"] and out["subs_ok"] != "yes" else []
        if out["likes_ok"] != "yes":
            reasons.append("likes_missing")
        if out["comments_ok"] != "yes":
            reasons.append("comments_missing")
        out["youtube_fail_reason"] = ";".join(reasons)

    if out["subs_ok"] == "yes" and out["likes_ok"] == "yes" and out["comments_ok"] == "yes":
        out["youtube_status"] = "pass"
        out["youtube_fail_reason"] = ""
    else:
        out["youtube_status"] = "fail"
    return out


def main() -> int:
    client = YouTubeClient(reserve_for_collection=0)
    rows = list(csv.DictReader(CANDIDATES.open()))
    print(f"candidates={len(rows)} units_already={client.units_used}", flush=True)
    results = []
    if LOG.exists():
        # resume by brand
        done = {r["brand"]: r for r in csv.DictReader(LOG.open())}
    else:
        done = {}
    fields = None
    for i, row in enumerate(rows, 1):
        brand = row["brand"]
        if brand in done and done[brand].get("channel_id"):
            print(f"[{i}/{len(rows)}] skip cached {brand}", flush=True)
            results.append(done[brand])
            continue
        try:
            rec = screen_one(client, row)
        except Exception as e:
            if e.__class__.__name__ == "QuotaExceeded" or "refusing" in str(e):
                print(f"STOP quota: {e}", flush=True)
                break
            rec = {
                "brand": brand,
                "youtube_status": "fail",
                "youtube_fail_reason": "exception",
                "api_error": type(e).__name__,
                "retrieved_at_hkt": now_hkt(),
            }
        results.append(rec)
        print(
            f"[{i}/{len(rows)}] {brand} {rec.get('youtube_status')} "
            f"subs={rec.get('subscriber_count') or '-'} likes={rec.get('n_with_likes')}/{rec.get('n_recent_videos_checked')} "
            f"comments={rec.get('n_with_comments')} reason={rec.get('youtube_fail_reason') or 'ok'} units={client.units_used}",
            flush=True,
        )
        time.sleep(0.08)
        # incremental write
        fields = list(rec.keys())
        with LOG.open("w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
            w.writeheader()
            for r in results:
                w.writerow(r)
        with JSONL.open("w") as f:
            for r in results:
                f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print(f"done brands={len(results)} units_used={client.units_used}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
