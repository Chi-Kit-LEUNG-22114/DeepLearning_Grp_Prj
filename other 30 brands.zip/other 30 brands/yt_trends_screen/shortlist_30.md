# Lane Crawford Home & Lifestyle YouTube + Trends shortlist

Verified data-availability shortlist of **30** brands. Universe: **403** unique brands on the live Lane Crawford HK Home & Lifestyle directory fetched 21 November 2026, 01:00 HKT from https://www.lanecrawford.com.hk/brand/home-lifestyle/ (saved as `lc_home_lifestyle_brands_live_2026-11-21.csv`). LANE CRAWFORD and LANE CRAWFORD TRAVEL were excluded as the retailer itself. This is **not** a random sample.

YouTube metrics are from the official YouTube Data API v3 only (subscribers via `channels.list` statistics; likes and comments via `videos.list` field presence on a recent public-video sample). A value of 0 counts as present; a missing `likeCount` or `commentCount` field is a fail. Google Trends checks were Worldwide (`geo` empty), last 5 years, using related queries plus interest-over-time completeness. Brands with Celine-like name collision were excluded even if YouTube passed.

Subscriber counts may be rounded by YouTube. Alcohol brands are often age-gated on consumer sites; the public Data API still returned the listed statistics.

| # | Brand | YouTube | Subscribers (public API) | Locked Trends query |
|---|-------|---------|--------------------------|---------------------|
| 1 | TOM DIXON | [@tomdixonstudio](https://www.youtube.com/@tomdixonstudio) | 1670 | `Tom Dixon` |
| 2 | FLOS | [@flosofficialchannel](https://www.youtube.com/@flosofficialchannel) | 3410 | `Flos lighting` |
| 3 | MOËT & CHANDON | [@moet](https://www.youtube.com/@moet) | 10800 | `Moet Chandon` |
| 4 | DOM PÉRIGNON | [@domperignonofficial](https://www.youtube.com/@domperignonofficial) | 13200 | `Dom Perignon` |
| 5 | JO MALONE LONDON | [@jomalonelondon](https://www.youtube.com/@jomalonelondon) | 23800 | `Jo Malone London` |
| 6 | BUCCELLATI | [@buccellatimilan](https://www.youtube.com/@buccellatimilan) | 3040 | `Buccellati` |
| 7 | MAISON MARGIELA | [@maisonmargiela](https://www.youtube.com/@maisonmargiela) | 127000 | `Maison Margiela` |
| 8 | BANG & OLUFSEN | [@bangolufsen](https://www.youtube.com/@bangolufsen) | 70900 | `Bang and Olufsen` |
| 9 | HERMAN MILLER | [@hermanmiller](https://www.youtube.com/@hermanmiller) | 15400 | `Herman Miller` |
| 10 | FRITZ HANSEN | [@fritzhansen1872](https://www.youtube.com/@fritzhansen1872) | 7150 | `Fritz Hansen` |
| 11 | CARL HANSEN & SØN | [@carlhansenandson](https://www.youtube.com/@carlhansenandson) | 11400 | `Carl Hansen` |
| 12 | B&B ITALIA | [@bebitalia](https://www.youtube.com/@bebitalia) | 5690 | `B&B Italia` |
| 13 | ARTEMIDE | [@artemideofficial](https://www.youtube.com/@artemideofficial) | 2530 | `Artemide` |
| 14 | LOUIS POULSEN | [@louispoulsenlighting](https://www.youtube.com/@louispoulsenlighting) | 2830 | `Louis Poulsen` |
| 15 | KARTELL | [@kartellpeople](https://www.youtube.com/@kartellpeople) | 3310 | `Kartell` |
| 16 | DEVIALET | [@devialet](https://www.youtube.com/@devialet) | 62700 | `Devialet` |
| 17 | BOWERS & WILKINS | [@bowerswilkins](https://www.youtube.com/@bowerswilkins) | 31100 | `Bowers and Wilkins` |
| 18 | SENNHEISER | [@sennheiser](https://www.youtube.com/@sennheiser) | 163000 | `Sennheiser` |
| 19 | CHRISTOFLE | [@christofleparis](https://www.youtube.com/@christofleparis) | 1510 | `Christofle` |
| 20 | FORNASETTI | [@fornasettiofficial](https://www.youtube.com/@fornasettiofficial) | 1390 | `Fornasetti` |
| 21 | MAISON FRANCIS KURKDJIAN | [@maisonfranciskurkdjian](https://www.youtube.com/@maisonfranciskurkdjian) | 12200 | `Maison Francis Kurkdjian` |
| 22 | TOM FORD | [@tomford](https://www.youtube.com/@tomford) | 91400 | `Tom Ford` |
| 23 | FORTNUM & MASON | [@fortnums](https://www.youtube.com/@fortnums) | 10400 | `Fortnum and Mason` |
| 24 | THE MACALLAN | [@themacallanwhisky](https://www.youtube.com/@themacallanwhisky) | 36600 | `The Macallan` |
| 25 | RUINART | [@ruinart](https://www.youtube.com/@ruinart) | 1760 | `Ruinart` |
| 26 | LASVIT | [@lasvitdesign](https://www.youtube.com/@lasvitdesign) | 10100 | `Lasvit` |
| 27 | BACCARAT | [@baccarat](https://www.youtube.com/@baccarat) | 6700 | `Baccarat crystal` |
| 28 | JURA | [@jura_coffee](https://www.youtube.com/@jura_coffee) | 17100 | `Jura coffee` |
| 29 | CLASSICON | [@classicondesign](https://www.youtube.com/@classicondesign) | 146 | `ClassiCon` |
| 30 | BORDALLO PINHEIRO | [@bordallopinheiro1884](https://www.youtube.com/@bordallopinheiro1884) | 1030 | `Bordallo Pinheiro` |

## Per-brand YouTube sample and notes

### TOM DIXON

- Lane Crawford: https://www.lanecrawford.com.hk/brand/1400333/tom-dixon/lifestyle/
- YouTube: https://www.youtube.com/@tomdixonstudio (`UCYFvC_53VNaaONDneGnLlXg`)
- Subscribers: 1670 (public API; may be rounded)
- Recent videos checked: 6; likes field present on 6; comments field present on 6
- Locked Trends query: `Tom Dixon` (Worldwide, today 5-y) — pass
- Prior official pull 20 Nov 2026 HKT reused for YouTube three-metric check (all 6 window videos had like_count and comment_count). Official site tomdixon.net links user/tomdixonstudio1, which is this channel. Trends related queries are lighting/furniture products.

### FLOS

- Lane Crawford: https://www.lanecrawford.com.hk/brand/44900007/flos/lifestyle/
- YouTube: https://www.youtube.com/@flosofficialchannel (`UCC51A913fgRpiQMdyesY9Tg`)
- Subscribers: 3410 (public API; may be rounded)
- Recent videos checked: 15; likes field present on 15; comments field present on 15
- Locked Trends query: `Flos lighting` (Worldwide, today 5-y) — pass
- Prior official pull reused (comment_count and like_count present on the 3-year video set). Bare 'Flos' was not used; locked query 'Flos lighting' related queries are track/outdoor lighting and country sites, not a different entity.

### MOËT & CHANDON

- Lane Crawford: https://www.lanecrawford.com.hk/brand/128103755/mo-t-chandon/lifestyle/
- YouTube: https://www.youtube.com/@moet (`UCJ8WERTOF24KMoDlh1ntqiQ`)
- Subscribers: 10800 (public API; may be rounded)
- Recent videos checked: 15; likes field present on 15; comments field present on 15
- Locked Trends query: `Moet Chandon` (Worldwide, today 5-y) — pass
- Prior official pull reused. Locked query 'Moet Chandon' (ASCII form used by Trends) related queries are champagne/imperial/brut/rose. Age-gated alcohol brand. Subscriber counts may be rounded.

### DOM PÉRIGNON

- Lane Crawford: https://www.lanecrawford.com.hk/brand/11700002/dom-p-rignon/lifestyle/
- YouTube: https://www.youtube.com/@domperignonofficial (`UCjcOmBKPKzAT6aPPTpKpbKQ`)
- Subscribers: 13200 (public API; may be rounded)
- Recent videos checked: 15; likes field present on 15; comments field present on 15
- Locked Trends query: `Dom Perignon` (Worldwide, today 5-y) — pass
- Prior official pull reused. Handle @domperignonofficial; official-site backlink was not found in fetched domperignon.com HTML, but channel title matches and Trends/related queries are champagne vintages. Age-gated alcohol brand.

### JO MALONE LONDON

- Lane Crawford: https://www.lanecrawford.com.hk/brand/700274/jo-malone-london/lifestyle/
- YouTube: https://www.youtube.com/@jomalonelondon (`UCWMSJ5L5Zvkr9JfflU4JMUA`)
- Subscribers: 23800 (public API; may be rounded)
- Recent videos checked: 15; likes field present on 15; comments field present on 15
- Locked Trends query: `Jo Malone London` (Worldwide, today 5-y) — pass
- Official Jo Malone regional site footer links youtube.com/user/JoMaloneLondon2012 (now @jomalonelondon). Also analysed successfully in asgm4 Worldwide Trends.

### BUCCELLATI

- Lane Crawford: https://www.lanecrawford.com.hk/brand/28000002/buccellati/lifestyle/
- YouTube: https://www.youtube.com/@buccellatimilan (`UChqTytoWtj9iB7LqtEz6NEw`)
- Subscribers: 3040 (public API; may be rounded)
- Recent videos checked: 15; likes field present on 15; comments field present on 15
- Locked Trends query: `Buccellati` (Worldwide, today 5-y) — pass
- Channel @buccellatimilan title Buccellati; LinkedIn company page lists this YouTube. Related queries are jewelry. Also in asgm4 Worldwide Trends.

### MAISON MARGIELA

- Lane Crawford: https://www.lanecrawford.com.hk/brand/700044/maison-margiela/lifestyle/
- YouTube: https://www.youtube.com/@maisonmargiela (`UCOKkerman2d_SmGj8P4_JEw`)
- Subscribers: 127000 (public API; may be rounded)
- Recent videos checked: 15; likes field present on 15; comments field present on 15
- Locked Trends query: `Maison Margiela` (Worldwide, today 5-y) — pass
- Channel @maisonmargiela exact title match; LinkedIn company page lists this YouTube. Related queries are shoes/tabi/perfume. Also in asgm4 Worldwide Trends.

### BANG & OLUFSEN

- Lane Crawford: https://www.lanecrawford.com.hk/brand/33500001/bang-olufsen/lifestyle/
- YouTube: https://www.youtube.com/@bangolufsen (`UCdxzd8LCzByrM0b8ZnYVPiw`)
- Subscribers: 70900 (public API; may be rounded)
- Recent videos checked: 15; likes field present on 15; comments field present on 15
- Locked Trends query: `Bang and Olufsen` (Worldwide, today 5-y) — pass
- Official site links youtube.com/user/bangolufsen (@bangolufsen). Locked ASCII 'Bang and Olufsen'; related queries are speakers/headphones/Beoplay.

### HERMAN MILLER

- Lane Crawford: https://www.lanecrawford.com.hk/brand/21600005/herman-miller/lifestyle/
- YouTube: https://www.youtube.com/@hermanmiller (`UCa5vnT9F0swEROK8mv9tCjg`)
- Subscribers: 15400 (public API; may be rounded)
- Recent videos checked: 15; likes field present on 15; comments field present on 15
- Locked Trends query: `Herman Miller` (Worldwide, today 5-y) — pass
- Used global @hermanmiller (title Herman Miller). The official site, after an Asia geo-redirect, also linked user/hermanmillerasia, which was not used as the primary channel. Related queries are Aeron/Embody chairs.

### FRITZ HANSEN

- Lane Crawford: https://www.lanecrawford.com.hk/brand/37600001/fritz-hansen/lifestyle/
- YouTube: https://www.youtube.com/@fritzhansen1872 (`UCA9_nuVJ4zFfoU3kylbJL-g`)
- Subscribers: 7150 (public API; may be rounded)
- Recent videos checked: 15; likes field present on 15; comments field present on 15
- Locked Trends query: `Fritz Hansen` (Worldwide, today 5-y) — pass
- Channel @fritzhansen1872 title FRITZ HANSEN; LinkedIn company page lists this YouTube. Related queries are chairs/tables/Egg chair.

### CARL HANSEN & SØN

- Lane Crawford: https://www.lanecrawford.com.hk/brand/38100010/carl-hansen-s-n/lifestyle/
- YouTube: https://www.youtube.com/@carlhansenandson (`UCswaYe3040m8dyNXzBkn8qg`)
- Subscribers: 11400 (public API; may be rounded)
- Recent videos checked: 15; likes field present on 15; comments field present on 15
- Locked Trends query: `Carl Hansen` (Worldwide, today 5-y) — pass
- Channel @carlhansenandson title is exactly Carl Hansen & Søn. Official site HTML did not expose a YouTube footer link in this fetch. Related queries are wishbone/CH24 chairs.

### B&B ITALIA

- Lane Crawford: https://www.lanecrawford.com.hk/brand/84403753/b-b-italia/lifestyle/
- YouTube: https://www.youtube.com/@bebitalia (`UCNZJfY2fgijZigm0cbmAYmQ`)
- Subscribers: 5690 (public API; may be rounded)
- Recent videos checked: 15; likes field present on 15; comments field present on 15
- Locked Trends query: `B&B Italia` (Worldwide, today 5-y) — pass
- Official site links user/bebitalia (@bebitalia). Related queries are sofa/Camaleonda/furniture.

### ARTEMIDE

- Lane Crawford: https://www.lanecrawford.com.hk/brand/700417/artemide/lifestyle/
- YouTube: https://www.youtube.com/@artemideofficial (`UCnDW-VURJiCUM9hOosIapHQ`)
- Subscribers: 2530 (public API; may be rounded)
- Recent videos checked: 15; likes field present on 15; comments field present on 15
- Locked Trends query: `Artemide` (Worldwide, today 5-y) — pass
- Official site links user/ArtemideVideoChannel (@artemideofficial). Related queries are dominated by Tolomeo/lamps; 'Artemide hotel' also appears and is residual, not series-dominating.

### LOUIS POULSEN

- Lane Crawford: https://www.lanecrawford.com.hk/brand/18700326/louis-poulsen/lifestyle/
- YouTube: https://www.youtube.com/@louispoulsenlighting (`UCzKev7B6wfHA1LsCNXb9m7Q`)
- Subscribers: 2830 (public API; may be rounded)
- Recent videos checked: 15; likes field present on 15; comments field present on 15
- Locked Trends query: `Louis Poulsen` (Worldwide, today 5-y) — pass
- Official site links user/LouisPoulsenLighting. Related queries are PH/Panthella lamps.

### KARTELL

- Lane Crawford: https://www.lanecrawford.com.hk/brand/700263/kartell/lifestyle/
- YouTube: https://www.youtube.com/@kartellpeople (`UC9eG5gHxX4fetRZNirg50Kg`)
- Subscribers: 3310 (public API; may be rounded)
- Recent videos checked: 15; likes field present on 15; comments field present on 15
- Locked Trends query: `Kartell` (Worldwide, today 5-y) — pass
- Official site links user/kartellpeople. Related queries are Componibili/chairs/lamps.

### DEVIALET

- Lane Crawford: https://www.lanecrawford.com.hk/brand/46900001/devialet/lifestyle/
- YouTube: https://www.youtube.com/@devialet (`UCD5zxVIHcJBNSpBl9wRIddA`)
- Subscribers: 62700 (public API; may be rounded)
- Recent videos checked: 15; likes field present on 15; comments field present on 15
- Locked Trends query: `Devialet` (Worldwide, today 5-y) — pass
- Channel @devialet exact title; LinkedIn company page lists this YouTube. Related queries are Phantom/Mania/Gemini speakers.

### BOWERS & WILKINS

- Lane Crawford: https://www.lanecrawford.com.hk/brand/98403753/bowers-wilkins/lifestyle/
- YouTube: https://www.youtube.com/@bowerswilkins (`UCnr7fLmlMAcT-4fWOwtaDbg`)
- Subscribers: 31100 (public API; may be rounded)
- Recent videos checked: 15; likes field present on 15; comments field present on 15
- Locked Trends query: `Bowers and Wilkins` (Worldwide, today 5-y) — pass
- Official site links @bowerswilkins. Locked ASCII 'Bowers and Wilkins'; related queries are PX7/speakers/earbuds.

### SENNHEISER

- Lane Crawford: https://www.lanecrawford.com.hk/brand/71493/sennheiser/lifestyle/
- YouTube: https://www.youtube.com/@sennheiser (`UCiKPFvWsJBlucrYU8kJMkaQ`)
- Subscribers: 163000 (public API; may be rounded)
- Recent videos checked: 15; likes field present on 15; comments field present on 15
- Locked Trends query: `Sennheiser` (Worldwide, today 5-y) — pass
- Official site links youtube.com/c/sennheiser (@sennheiser). Related queries are headphones/Momentum/HD. Large official catalogue; collection may be volume-capped.

### CHRISTOFLE

- Lane Crawford: https://www.lanecrawford.com.hk/brand/130103756/christofle/lifestyle/
- YouTube: https://www.youtube.com/@christofleparis (`UChhWuceUIkHW8K4kxEFrCIg`)
- Subscribers: 1510 (public API; may be rounded)
- Recent videos checked: 15; likes field present on 15; comments field present on 15
- Locked Trends query: `Christofle` (Worldwide, today 5-y) — pass
- Channel @christofleparis title Christofle. Related queries are silver/flatware.

### FORNASETTI

- Lane Crawford: https://www.lanecrawford.com.hk/brand/59374/fornasetti/lifestyle/
- YouTube: https://www.youtube.com/@fornasettiofficial (`UC-LRSO3tWyXFzObkPRWWAKQ`)
- Subscribers: 1390 (public API; may be rounded)
- Recent videos checked: 15; likes field present on 15; comments field present on 15
- Locked Trends query: `Fornasetti` (Worldwide, today 5-y) — pass
- Official site links this channel (@fornasettiofficial). Related queries are plates/wallpaper/candles.

### MAISON FRANCIS KURKDJIAN

- Lane Crawford: https://www.lanecrawford.com.hk/brand/4100014/maison-francis-kurkdjian/lifestyle/
- YouTube: https://www.youtube.com/@maisonfranciskurkdjian (`UCTj44UFzFZXrvFhY_N84xRA`)
- Subscribers: 12200 (public API; may be rounded)
- Recent videos checked: 15; likes field present on 15; comments field present on 15
- Locked Trends query: `Maison Francis Kurkdjian` (Worldwide, today 5-y) — pass
- Channel @maisonfranciskurkdjian exact title; LinkedIn company page lists this YouTube. Related queries are Baccarat Rouge 540 and other fragrances (the perfume name, not a Trends collision with the crystal house as the focal query).

### TOM FORD

- Lane Crawford: https://www.lanecrawford.com.hk/brand/700367/tom-ford/lifestyle/
- YouTube: https://www.youtube.com/@tomford (`UCi7nMpXuCXT_SUOOE6Yy2ag`)
- Subscribers: 91400 (public API; may be rounded)
- Recent videos checked: 15; likes field present on 15; comments field present on 15
- Locked Trends query: `Tom Ford` (Worldwide, today 5-y) — pass
- Channel @tomford exact title. Related queries are perfume/fashion. LC lists the brand on the Home & Lifestyle directory.

### FORTNUM & MASON

- Lane Crawford: https://www.lanecrawford.com.hk/brand/1113019/fortnum-mason/lifestyle/
- YouTube: https://www.youtube.com/@fortnums (`UCYcGoWHz0tJYTSqPhpkt1Ng`)
- Subscribers: 10400 (public API; may be rounded)
- Recent videos checked: 15; likes field present on 7; comments field present on 15
- Locked Trends query: `Fortnum and Mason` (Worldwide, today 5-y) — pass
- Channel @fortnums title Fortnum & Mason; channel description links fortnumandmason.com. Related queries are tea/afternoon tea/hampers. Like counts were present on 7 of 15 recent videos (still several, so likes_ok).

### THE MACALLAN

- Lane Crawford: https://www.lanecrawford.com.hk/brand/2300001/the-macallan/lifestyle/
- YouTube: https://www.youtube.com/@themacallanwhisky (`UCFgN7m_XSuPA2R__ZOxy8ew`)
- Subscribers: 36600 (public API; may be rounded)
- Recent videos checked: 15; likes field present on 15; comments field present on 15
- Locked Trends query: `The Macallan` (Worldwide, today 5-y) — pass
- Channel @themacallanwhisky title The Macallan; LinkedIn company page lists this YouTube. Related queries are whisky ages/prices. Age-gated alcohol brand.

### RUINART

- Lane Crawford: https://www.lanecrawford.com.hk/brand/46000016/ruinart/lifestyle/
- YouTube: https://www.youtube.com/@ruinart (`UCsjIPs45_X6jATzNrpHCz4A`)
- Subscribers: 1760 (public API; may be rounded)
- Recent videos checked: 15; likes field present on 15; comments field present on 15
- Locked Trends query: `Ruinart` (Worldwide, today 5-y) — pass
- Official site links user/Ruinart (@ruinart). Related queries are champagne/blanc de blancs. Age-gated alcohol brand.

### LASVIT

- Lane Crawford: https://www.lanecrawford.com.hk/brand/71233/lasvit/lifestyle/
- YouTube: https://www.youtube.com/@lasvitdesign (`UCEFYsjkU0z39n7xWpaGjfDw`)
- Subscribers: 10100 (public API; may be rounded)
- Recent videos checked: 15; likes field present on 15; comments field present on 15
- Locked Trends query: `Lasvit` (Worldwide, today 5-y) — pass
- Official site links user/LASVITCOM (@lasvitdesign). Related queries are lighting/Nový Bor/installations.

### BACCARAT

- Lane Crawford: https://www.lanecrawford.com.hk/brand/700061/baccarat/lifestyle/
- YouTube: https://www.youtube.com/@baccarat (`UCiIMavt991Xn_pLecTMwYWQ`)
- Subscribers: 6700 (public API; may be rounded)
- Recent videos checked: 15; likes field present on 15; comments field present on 15
- Locked Trends query: `Baccarat crystal` (Worldwide, today 5-y) — pass
- Official site links user/BACCARATTV (@baccarat). Bare 'Baccarat' is unusable (casino + Baccarat Rouge 540 perfume). Locked 'Baccarat crystal' related queries are glasses/vase/decanter for this house. An earlier automatic hint falsely flagged the substring 'baccara'; the related-query list was reviewed and is on-brand.

### JURA

- Lane Crawford: https://www.lanecrawford.com.hk/brand/49100017/jura/lifestyle/
- YouTube: https://www.youtube.com/@jura_coffee (`UCZC8v_QLZoCsFlkxnIUX-Vw`)
- Subscribers: 17100 (public API; may be rounded)
- Recent videos checked: 15; likes field present on 15; comments field present on 15
- Locked Trends query: `Jura coffee` (Worldwide, today 5-y) — pass
- Channel @jura_coffee description links jura.com. Bare 'Jura' would collide with the mountains/canton/whisky; locked 'Jura coffee' related queries are coffee machines (Z10/E6/S8).

### CLASSICON

- Lane Crawford: https://www.lanecrawford.com.hk/brand/22000011/classicon/lifestyle/
- YouTube: https://www.youtube.com/@classicondesign (`UCydnBjuhfNg98-gwq4EiqOw`)
- Subscribers: 146 (public API; may be rounded)
- Recent videos checked: 14; likes field present on 7; comments field present on 7
- Locked Trends query: `ClassiCon` (Worldwide, today 5-y) — pass
- Official site links user/ClassiConDesign (@classicondesign). Related queries are furniture/tables/tube light. Recent-video sample had likeCount and commentCount on 7 of 14 videos (still several, so both metrics pass).

### BORDALLO PINHEIRO

- Lane Crawford: https://www.lanecrawford.com.hk/brand/110003753/bordallo-pinheiro/lifestyle/
- YouTube: https://www.youtube.com/@bordallopinheiro1884 (`UCO7zn1uMrDR21tF9HNhU0mA`)
- Subscribers: 1030 (public API; may be rounded)
- Recent videos checked: 15; likes field present on 15; comments field present on 15
- Locked Trends query: `Bordallo Pinheiro` (Worldwide, today 5-y) — pass
- Official site links user/bordallopinheiro1884. Related queries are cabbage plates/Portugal pottery.

## Alternates (YouTube three-metric pass + Trends pass, not in the 30)

Use these if a shortlisted brand later proves impractical to collect: Bordallo Pinheiro is already in the 30. Further dual-passes include Taittinger (`Taittinger`), Hennessy (`Hennessy`, age-gated), Elie Bleu (`Elie Bleu`), Master & Dynamic (`Master and Dynamic`), Theragun via the official Therabody channel (`Theragun`), Lomography (`Lomography`), DJI (`DJI`), SteelSeries (`SteelSeries`), Polaroid (`Polaroid`; some true-crime photo queries appear but still refer to Polaroid images), SPYRA (`Spyra`), and Focal (`Focal speakers`; do not use bare Focal).

## Explicit exclusions (do not pad the 30 with these)

- **LEGO** (`@LEGO`): official, subscribers and likes present, but `comment_count` was omitted on all 2,000 pulled videos and `commentThreads` returned 403 `commentsDisabled`. Henry's assigned brand; kept in the screening log, not in the 30.
- **AESOP**: official-looking `@aesopskincare` (channel header links aesop.com) passed YouTube, and asgm4 used `Aesop`, but a fresh Worldwide related-query pull included Aesop Rock, Aesop's Fables, and Aesop Frontline/login alongside skincare. Excluded to avoid a Celine-type collision.
- **VITRA**: official YouTube pass, but related queries mix the Swiss furniture house with Turkish VitrA bathroom ware. `Vitra furniture` still returned bathroom furniture.
- **CASSINA**: official YouTube pass; bare `Cassina` related queries are led by the town Cassina de' Pecchi. `Cassina furniture` had a usable series but no related queries in the retry, so it was left unchecked and out of the 30.
- **KNOLL** / `Knoll furniture`: related queries mix Parker Knoll, Walter Knoll, and Miller Knoll.
- **LOEWE**: official YouTube pass; related queries include Loewe TV as well as fashion bags.
- **COTOPAXI**: official YouTube pass; brand products dominate but volcano/Ecuador queries are also in the top related list.
- **VISTA ALEGRE**: official YouTube pass; Trends related queries are almost all place/hotel/street names, not the porcelain brand.
- **STANLEY**: official `@Stanley1913` YouTube pass; `Stanley 1913` related queries include `1913 stanley cup` (hockey), and `Stanley tumbler` still surfaces `stanley cup`.
- **KODAK**: official YouTube pass; top related query is Kodak Black (the rapper).
- **HOTO**: official YouTube pass; related queries mix tools with 'hoto meaning' / other-language uses.
- **SAINT-LOUIS** / `Saint-Louis crystal`: series too sparse (20 of 262 weeks non-zero, mean about 3, no related queries).
- **BOTTEGA VENETA**: official channel, but `likeCount` missing on the 15-video sample.
- **TEENAGE ENGINEERING**: official channel, `likeCount` present on only 1 of 15 recent videos.
- **VEUVE CLICQUOT**: official channel, `commentCount` missing on all 15 recent videos.
- **JELLYCAT**: asgm4 Trends-OK, but no YouTube link on jellycat.com (Instagram/TikTok/Facebook/Twitter only). `@jellycatlondon` self-describes as official but was left unverified. `@JellycatOfficial` is an unrelated fan/Roblox channel.
- **LOUISE ROE** and **MISETTE**: first-pass site guesses pointed at the wrong entities (a TV presenter's channel; a French auction-house channel). Not treated as official.
- **LANE CRAWFORD** / **LANE CRAWFORD TRAVEL**: retailer itself, excluded by design.

See `screening_log.csv` for every brand checked.

## Official YouTube collection (21 November 2026, 01:25 HKT)

Public Data API pull for all 30 shortlisted channels is in `youtube_data_api/`. Window: published on or after 21 November 2023 UTC; cap 2,000 videos per channel. All 30 channels reached the three-year cutoff before the cap (none truncated). Snapshot: 30 channels, 2,873 videos, 1,677 public comment-text rows from a recent-year sample. Task quota used for screening plus collection: 922 of a 5,000-unit cap.

Subscriber counts in the shortlist table match this collection snapshot and may be rounded by YouTube.

Upload density varies a lot. Sennheiser (613), Fortnum & Mason (428), Baccarat (285) and Jura (219) are relatively dense. Artemide (4, all on one day), Ruinart (3), ClassiCon (3) and Tom Dixon (6) post rarely, so Velocity series will be sparse.

Field-presence caveat from the full window (the shortlist pass itself used a recent ~15-video sample):

- Fortnum & Mason: `likeCount` is present on only 29 of 428 window videos (comments are present on 425). Likes are usable on a minority of videos, not the full series.
- Devialet: `commentCount` present on 93 of 106 videos.
- A few other channels are missing the like or comment field on one video only.
- Some recent videos return `commentsDisabled` when fetching comment *text* (B&B Italia, Kartell, Fornasetti, and a few others). That is separate from video-level `commentCount` field presence, which was the shortlist rule.

Jo Malone London's 118 uploads all fall between 3 September 2025 and 10 November 2026, so there is no three-year YouTube history on this channel.
