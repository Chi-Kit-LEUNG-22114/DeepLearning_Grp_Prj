#!/usr/bin/env python3
"""Fetch official brand sites and extract YouTube links. No API key used."""
from __future__ import annotations

import csv
import re
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from urllib.parse import urljoin, urlparse

import requests

OUT = Path("/workspace/study_notes/capstone_signals/yt_trends_screen")
SITES = OUT / "official_sites_priority.csv"
DEST = OUT / "official_site_youtube_links.csv"

UA = "Mozilla/5.0 (compatible; STAT6207-research/1.0; +https://example.local)"
YT_RE = re.compile(
    r"https?://(?:www\.)?(?:youtube\.com|youtu\.be)/[^\s\"'<>\\]+",
    re.I,
)
HANDLE_RE = re.compile(r"(?:youtube\.com)/(?:@[\w.-]+|channel/[\w-]+|user/[\w.-]+|c/[\w.-]+|jomalonelondon)", re.I)

def clean_url(u: str) -> str:
    u = u.replace("&amp;", "&").rstrip(").,;")
    u = u.split("?")[0].split("#")[0]
    return u

def extract(html: str) -> list[str]:
    found = []
    for m in YT_RE.finditer(html):
        found.append(clean_url(m.group(0)))
    # also protocol-relative and href='/youtube'
    for m in re.finditer(r"(?:href|content)\s*=\s*[\"']([^\"']*youtube\.com[^\"']+)[\"']", html, re.I):
        found.append(clean_url(m.group(1)))
    # bare youtube.com/@handle
    for m in re.finditer(r"youtube\.com/(?:@[\w.-]+|channel/[\w-]+|user/[\w.-]+|c/[\w.-]+)", html, re.I):
        found.append("https://www." + clean_url(m.group(0)))
    # unique, prefer channel-like
    uniq = []
    seen = set()
    for u in found:
        if not u.startswith("http"):
            if u.startswith("//"):
                u = "https:" + u
            else:
                continue
        key = u.lower().rstrip("/")
        if key in seen:
            continue
        seen.add(key)
        uniq.append(u)
    return uniq

def fetch(url: str, timeout=18) -> tuple[int | None, str, str]:
    try:
        r = requests.get(
            url,
            headers={"User-Agent": UA, "Accept": "text/html,application/xhtml+xml"},
            timeout=timeout,
            allow_redirects=True,
        )
        return r.status_code, str(r.url), r.text or ""
    except Exception as e:
        return None, url, f"ERROR:{type(e).__name__}"

def extra_paths(base: str) -> list[str]:
    # light extra pages that often hold social links
    roots = [base if base.endswith("/") else base + "/"]
    extras = ["", "about", "about-us", "contact", "contact-us", "our-story", "footer"]
    out = []
    for r in roots:
        for e in extras:
            out.append(urljoin(r, e))
    # unique
    seen=set(); res=[]
    for u in out:
        if u not in seen:
            seen.add(u); res.append(u)
    return res[:4]  # homepage + 3

def main():
    rows = []
    with SITES.open() as f:
        for row in csv.DictReader(f):
            brand = (row.get("brand") or "").strip()
            site = (row.get("official_site") or "").strip()
            if not brand or not site.startswith("http"):
                continue
            if " or " in site or " skip" in site.lower() or site.endswith("?"):
                # skip messy
                if " or " in site or "?" in site:
                    site = site.split()[0]
                if not site.startswith("http"):
                    continue
            rows.append((brand, site))
    # unique by brand, first site wins
    seenb=set(); clean=[]
    for b,s in rows:
        if b in seenb:
            continue
        seenb.add(b)
        clean.append((b,s))
    print(f"brands with sites: {len(clean)}", flush=True)

    results = []
    def work(item):
        brand, site = item
        pages = extra_paths(site)
        all_links = []
        statuses = []
        final_urls = []
        err = ""
        # homepage first, only follow extras if no channel-like link
        for i, url in enumerate(pages):
            code, final, html = fetch(url)
            statuses.append(f"{code}")
            final_urls.append(final)
            if html.startswith("ERROR:"):
                err = html
                continue
            links = extract(html)
            all_links.extend(links)
            if any(re.search(r"/(@|channel/|user/|c/)", u, re.I) for u in links) and i == 0:
                break
            if i >= 1 and any(re.search(r"/(@|channel/|user/|c/)", u, re.I) for u in links):
                break
        # unique links
        uniq=[]; seen=set()
        for u in all_links:
            k=u.lower().rstrip("/")
            if k in seen: continue
            seen.add(k); uniq.append(u)
        channelish = [u for u in uniq if re.search(r"youtube\.com/(@|channel/|user/|c/|jomalonelondon)(?:/|$)", u, re.I)]
        watchish = [u for u in uniq if u not in channelish]
        return {
            "brand": brand,
            "official_site": site,
            "final_url": final_urls[0] if final_urls else site,
            "http_status": statuses[0] if statuses else "",
            "youtube_channel_links": " | ".join(channelish),
            "other_youtube_links": " | ".join(watchish[:8]),
            "n_youtube_links": str(len(uniq)),
            "error": err,
        }

    with ThreadPoolExecutor(max_workers=12) as ex:
        futs = [ex.submit(work, item) for item in clean]
        done=0
        for fut in as_completed(futs):
            results.append(fut.result())
            done += 1
            if done % 15 == 0:
                print(f"fetched {done}/{len(clean)}", flush=True)

    results.sort(key=lambda r: r["brand"])
    fields = ["brand","official_site","final_url","http_status","youtube_channel_links","other_youtube_links","n_youtube_links","error"]
    with DEST.open("w", newline="") as f:
        w=csv.DictWriter(f, fieldnames=fields)
        w.writeheader(); w.writerows(results)
    with_ch = sum(1 for r in results if r["youtube_channel_links"])
    print(f"wrote {DEST} rows={len(results)} with_channel_links={with_ch}")

if __name__ == "__main__":
    main()
