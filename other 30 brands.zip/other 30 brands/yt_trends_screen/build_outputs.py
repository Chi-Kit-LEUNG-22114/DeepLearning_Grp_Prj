#!/usr/bin/env python3
"""Build shortlist_30 and screening_log from verified screening results."""
from __future__ import annotations

import csv
from pathlib import Path

OUT = Path("/workspace/study_notes/capstone_signals/yt_trends_screen")
LIVE = OUT / "lc_home_lifestyle_brands_live_2026-11-21.csv"
YT = OUT / "screening_yt_raw.csv"
PRIOR_CH = Path("/workspace/study_notes/youtube_henry_brands/youtube_data_api/channels.csv")
PRIOR_VID = Path("/workspace/study_notes/youtube_henry_brands/youtube_data_api/videos.csv")

SHORTLIST = [
    {
        "brand": "TOM DIXON",
        "locked_trends_query": "Tom Dixon",
        "trends_status": "pass",
        "notes": "Prior official pull 20 Nov 2026 HKT reused for YouTube three-metric check (all 6 window videos had like_count and comment_count). Official site tomdixon.net links user/tomdixonstudio1, which is this channel. Trends related queries are lighting/furniture products.",
        "source": "prior",
    },
    {
        "brand": "FLOS",
        "locked_trends_query": "Flos lighting",
        "trends_status": "pass",
        "notes": "Prior official pull reused (comment_count and like_count present on the 3-year video set). Bare 'Flos' was not used; locked query 'Flos lighting' related queries are track/outdoor lighting and country sites, not a different entity.",
        "source": "prior",
    },
    {
        "brand": "MOËT & CHANDON",
        "locked_trends_query": "Moet Chandon",
        "trends_status": "pass",
        "notes": "Prior official pull reused. Locked query 'Moet Chandon' (ASCII form used by Trends) related queries are champagne/imperial/brut/rose. Age-gated alcohol brand. Subscriber counts may be rounded.",
        "source": "prior",
    },
    {
        "brand": "DOM PÉRIGNON",
        "locked_trends_query": "Dom Perignon",
        "trends_status": "pass",
        "notes": "Prior official pull reused. Handle @domperignonofficial; official-site backlink was not found in fetched domperignon.com HTML, but channel title matches and Trends/related queries are champagne vintages. Age-gated alcohol brand.",
        "source": "prior",
    },
    {
        "brand": "JO MALONE LONDON",
        "locked_trends_query": "Jo Malone London",
        "trends_status": "pass",
        "notes": "Official Jo Malone regional site footer links youtube.com/user/JoMaloneLondon2012 (now @jomalonelondon). Also analysed successfully in asgm4 Worldwide Trends.",
        "source": "api",
    },
    {
        "brand": "BUCCELLATI",
        "locked_trends_query": "Buccellati",
        "trends_status": "pass",
        "notes": "Channel @buccellatimilan title Buccellati; LinkedIn company page lists this YouTube. Related queries are jewelry. Also in asgm4 Worldwide Trends.",
        "source": "api",
    },
    {
        "brand": "MAISON MARGIELA",
        "locked_trends_query": "Maison Margiela",
        "trends_status": "pass",
        "notes": "Channel @maisonmargiela exact title match; LinkedIn company page lists this YouTube. Related queries are shoes/tabi/perfume. Also in asgm4 Worldwide Trends.",
        "source": "api",
    },
    {
        "brand": "BANG & OLUFSEN",
        "locked_trends_query": "Bang and Olufsen",
        "trends_status": "pass",
        "notes": "Official site links youtube.com/user/bangolufsen (@bangolufsen). Locked ASCII 'Bang and Olufsen'; related queries are speakers/headphones/Beoplay.",
        "source": "api",
    },
    {
        "brand": "HERMAN MILLER",
        "locked_trends_query": "Herman Miller",
        "trends_status": "pass",
        "notes": "Used global @hermanmiller (title Herman Miller). The official site, after an Asia geo-redirect, also linked user/hermanmillerasia, which was not used as the primary channel. Related queries are Aeron/Embody chairs.",
        "source": "api",
    },
    {
        "brand": "FRITZ HANSEN",
        "locked_trends_query": "Fritz Hansen",
        "trends_status": "pass",
        "notes": "Channel @fritzhansen1872 title FRITZ HANSEN; LinkedIn company page lists this YouTube. Related queries are chairs/tables/Egg chair.",
        "source": "api",
    },
    {
        "brand": "CARL HANSEN & SØN",
        "locked_trends_query": "Carl Hansen",
        "trends_status": "pass",
        "notes": "Channel @carlhansenandson title is exactly Carl Hansen & Søn. Official site HTML did not expose a YouTube footer link in this fetch. Related queries are wishbone/CH24 chairs.",
        "source": "api",
    },
    {
        "brand": "B&B ITALIA",
        "locked_trends_query": "B&B Italia",
        "trends_status": "pass",
        "notes": "Official site links user/bebitalia (@bebitalia). Related queries are sofa/Camaleonda/furniture.",
        "source": "api",
    },
    {
        "brand": "ARTEMIDE",
        "locked_trends_query": "Artemide",
        "trends_status": "pass",
        "notes": "Official site links user/ArtemideVideoChannel (@artemideofficial). Related queries are dominated by Tolomeo/lamps; 'Artemide hotel' also appears and is residual, not series-dominating.",
        "source": "api",
    },
    {
        "brand": "LOUIS POULSEN",
        "locked_trends_query": "Louis Poulsen",
        "trends_status": "pass",
        "notes": "Official site links user/LouisPoulsenLighting. Related queries are PH/Panthella lamps.",
        "source": "api",
    },
    {
        "brand": "KARTELL",
        "locked_trends_query": "Kartell",
        "trends_status": "pass",
        "notes": "Official site links user/kartellpeople. Related queries are Componibili/chairs/lamps.",
        "source": "api",
    },
    {
        "brand": "DEVIALET",
        "locked_trends_query": "Devialet",
        "trends_status": "pass",
        "notes": "Channel @devialet exact title; LinkedIn company page lists this YouTube. Related queries are Phantom/Mania/Gemini speakers.",
        "source": "api",
    },
    {
        "brand": "BOWERS & WILKINS",
        "locked_trends_query": "Bowers and Wilkins",
        "trends_status": "pass",
        "notes": "Official site links @bowerswilkins. Locked ASCII 'Bowers and Wilkins'; related queries are PX7/speakers/earbuds.",
        "source": "api",
    },
    {
        "brand": "SENNHEISER",
        "locked_trends_query": "Sennheiser",
        "trends_status": "pass",
        "notes": "Official site links youtube.com/c/sennheiser (@sennheiser). Related queries are headphones/Momentum/HD. Large official catalogue; collection may be volume-capped.",
        "source": "api",
    },
    {
        "brand": "CHRISTOFLE",
        "locked_trends_query": "Christofle",
        "trends_status": "pass",
        "notes": "Channel @christofleparis title Christofle. Related queries are silver/flatware.",
        "source": "api",
    },
    {
        "brand": "FORNASETTI",
        "locked_trends_query": "Fornasetti",
        "trends_status": "pass",
        "notes": "Official site links this channel (@fornasettiofficial). Related queries are plates/wallpaper/candles.",
        "source": "api",
    },
    {
        "brand": "MAISON FRANCIS KURKDJIAN",
        "locked_trends_query": "Maison Francis Kurkdjian",
        "trends_status": "pass",
        "notes": "Channel @maisonfranciskurkdjian exact title; LinkedIn company page lists this YouTube. Related queries are Baccarat Rouge 540 and other fragrances (the perfume name, not a Trends collision with the crystal house as the focal query).",
        "source": "api",
    },
    {
        "brand": "TOM FORD",
        "locked_trends_query": "Tom Ford",
        "trends_status": "pass",
        "notes": "Channel @tomford exact title. Related queries are perfume/fashion. LC lists the brand on the Home & Lifestyle directory.",
        "source": "api",
    },
    {
        "brand": "FORTNUM & MASON",
        "locked_trends_query": "Fortnum and Mason",
        "trends_status": "pass",
        "notes": "Channel @fortnums title Fortnum & Mason; channel description links fortnumandmason.com. Related queries are tea/afternoon tea/hampers. Like counts were present on 7 of 15 recent videos (still several, so likes_ok).",
        "source": "api",
    },
    {
        "brand": "THE MACALLAN",
        "locked_trends_query": "The Macallan",
        "trends_status": "pass",
        "notes": "Channel @themacallanwhisky title The Macallan; LinkedIn company page lists this YouTube. Related queries are whisky ages/prices. Age-gated alcohol brand.",
        "source": "api",
    },
    {
        "brand": "RUINART",
        "locked_trends_query": "Ruinart",
        "trends_status": "pass",
        "notes": "Official site links user/Ruinart (@ruinart). Related queries are champagne/blanc de blancs. Age-gated alcohol brand.",
        "source": "api",
    },
    {
        "brand": "LASVIT",
        "locked_trends_query": "Lasvit",
        "trends_status": "pass",
        "notes": "Official site links user/LASVITCOM (@lasvitdesign). Related queries are lighting/Nový Bor/installations.",
        "source": "api",
    },
    {
        "brand": "BACCARAT",
        "locked_trends_query": "Baccarat crystal",
        "trends_status": "pass",
        "notes": "Official site links user/BACCARATTV (@baccarat). Bare 'Baccarat' is unusable (casino + Baccarat Rouge 540 perfume). Locked 'Baccarat crystal' related queries are glasses/vase/decanter for this house. An earlier automatic hint falsely flagged the substring 'baccara'; the related-query list was reviewed and is on-brand.",
        "source": "api",
    },
    {
        "brand": "JURA",
        "locked_trends_query": "Jura coffee",
        "trends_status": "pass",
        "notes": "Channel @jura_coffee description links jura.com. Bare 'Jura' would collide with the mountains/canton/whisky; locked 'Jura coffee' related queries are coffee machines (Z10/E6/S8).",
        "source": "api",
    },
    {
        "brand": "CLASSICON",
        "locked_trends_query": "ClassiCon",
        "trends_status": "pass",
        "notes": "Official site links user/ClassiConDesign (@classicondesign). Related queries are furniture/tables/tube light. Recent-video sample had likeCount and commentCount on 7 of 14 videos (still several, so both metrics pass).",
        "source": "api",
    },
    {
        "brand": "BORDALLO PINHEIRO",
        "locked_trends_query": "Bordallo Pinheiro",
        "trends_status": "pass",
        "notes": "Official site links user/bordallopinheiro1884. Related queries are cabbage plates/Portugal pottery.",
        "source": "api",
    },
]


def load_live():
    return {r["brand"]: r for r in csv.DictReader(LIVE.open())}


def load_yt():
    rows = list(csv.DictReader(YT.open()))
    # index by uppercase LC-style name where possible
    out = {}
    for r in rows:
        out[r["brand"].strip().upper()] = r
        out[r["brand"].strip()] = r
    return out


def prior_metrics():
    ch = {r["brand"]: r for r in csv.DictReader(PRIOR_CH.open())}
    vids = list(csv.DictReader(PRIOR_VID.open()))
    from collections import defaultdict
    by = defaultdict(list)
    for v in vids:
        by[v["brand"]].append(v)
    out = {}
    mapping = {
        "TOM DIXON": "Tom Dixon",
        "FLOS": "Flos",
        "MOËT & CHANDON": "Moët & Chandon",
        "DOM PÉRIGNON": "Dom Pérignon",
        "LEGO": "LEGO",
    }
    for lc, name in mapping.items():
        c = ch[name]
        vs = sorted(by[name], key=lambda x: x.get("published_at") or "", reverse=True)
        sample = vs[:15]
        n = len(sample)
        n_likes = sum(1 for v in sample if v.get("like_count") not in (None, ""))
        n_comm = sum(1 for v in sample if v.get("comment_count") not in (None, ""))
        handle = c.get("handle") or ""
        out[lc] = {
            "youtube_url": c.get("channel_url") or (f"https://www.youtube.com/{handle}" if handle else ""),
            "youtube_handle": handle,
            "channel_id": c.get("channel_id") or "",
            "subscriber_count": c.get("subscriber_count") or "",
            "likes_ok": "yes" if (n_likes >= (3 if n >= 3 else max(n, 1))) else "no",
            "comments_ok": "yes" if (n_comm >= (3 if n >= 3 else max(n, 1))) else "no",
            "n_recent_videos_checked": str(n),
            "n_with_likes": str(n_likes),
            "n_with_comments": str(n_comm),
            "channel_title": c.get("channel_title") or "",
            "hidden_subscriber_count": c.get("hidden_subscriber_count") or "",
            "video_count": c.get("video_count") or "",
        }
    return out


def main():
    live = load_live()
    yt = load_yt()
    prior = prior_metrics()
    fields = [
        "brand", "lc_url", "youtube_url", "youtube_handle", "channel_id",
        "subscriber_count", "likes_ok", "comments_ok", "n_recent_videos_checked",
        "n_with_likes", "n_with_comments", "locked_trends_query", "trends_status", "notes",
    ]
    rows = []
    for item in SHORTLIST:
        brand = item["brand"]
        lc = live[brand]
        if item["source"] == "prior":
            y = prior[brand]
        else:
            # map LC all-caps to screening brand names
            key = brand
            # screening used title-ish names
            aliases = {
                "JO MALONE LONDON": "JO MALONE LONDON",
                "BANG & OLUFSEN": "BANG & OLUFSEN",
                "CARL HANSEN & SØN": "CARL HANSEN & SØN",
                "B&B ITALIA": "B&B ITALIA",
                "BOWERS & WILKINS": "BOWERS & WILKINS",
                "MAISON FRANCIS KURKDJIAN": "MAISON FRANCIS KURKDJIAN",
                "FORTNUM & MASON": "FORTNUM & MASON",
                "THE MACALLAN": "THE MACALLAN",
                "BORDALLO PINHEIRO": "BORDALLO PINHEIRO",
                "CLASSICON": "CLASSICON",
            }
            yraw = yt.get(key) or yt.get(brand.title()) 
            # direct upper keys were stored
            if not yraw:
                # try all yt keys
                for k,v in yt.items():
                    if k.upper() == brand.upper() or k.replace("&","AND").upper()==brand.upper():
                        yraw=v
                        break
            if not yraw:
                raise SystemExit(f"missing yt row for {brand} keys sample={list(yt)[:5]}")
            y = {
                "youtube_url": yraw.get("youtube_url") or "",
                "youtube_handle": yraw.get("youtube_handle") or yraw.get("custom_url") or "",
                "channel_id": yraw.get("channel_id") or "",
                "subscriber_count": yraw.get("subscriber_count") or "",
                "likes_ok": yraw.get("likes_ok") or "",
                "comments_ok": yraw.get("comments_ok") or "",
                "n_recent_videos_checked": yraw.get("n_recent_videos_checked") or "",
                "n_with_likes": yraw.get("n_with_likes") or "",
                "n_with_comments": yraw.get("n_with_comments") or "",
            }
        rec = {
            "brand": brand,
            "lc_url": lc["url"],
            "youtube_url": y["youtube_url"],
            "youtube_handle": y["youtube_handle"],
            "channel_id": y["channel_id"],
            "subscriber_count": y["subscriber_count"],
            "likes_ok": y["likes_ok"],
            "comments_ok": y["comments_ok"],
            "n_recent_videos_checked": y["n_recent_videos_checked"],
            "n_with_likes": y["n_with_likes"],
            "n_with_comments": y["n_with_comments"],
            "locked_trends_query": item["locked_trends_query"],
            "trends_status": item["trends_status"],
            "notes": item["notes"],
        }
        rows.append(rec)
    with (OUT / "shortlist_30.csv").open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader(); w.writerows(rows)
    # markdown
    lines = [
        "# Lane Crawford Home & Lifestyle YouTube + Trends shortlist",
        "",
        "Verified data-availability shortlist of **30** brands. Universe: **403** unique brands on the live Lane Crawford HK Home & Lifestyle directory fetched 21 November 2026, 01:00 HKT from https://www.lanecrawford.com.hk/brand/home-lifestyle/ (saved as `lc_home_lifestyle_brands_live_2026-11-21.csv`). LANE CRAWFORD and LANE CRAWFORD TRAVEL were excluded as the retailer itself. This is **not** a random sample.",
        "",
        "YouTube metrics are from the official YouTube Data API v3 only (subscribers via `channels.list` statistics; likes and comments via `videos.list` field presence on a recent public-video sample). A value of 0 counts as present; a missing `likeCount` or `commentCount` field is a fail. Google Trends checks were Worldwide (`geo` empty), last 5 years, using related queries plus interest-over-time completeness. Brands with Celine-like name collision were excluded even if YouTube passed.",
        "",
        "Subscriber counts may be rounded by YouTube. Alcohol brands are often age-gated on consumer sites; the public Data API still returned the listed statistics.",
        "",
        "| # | Brand | YouTube | Subscribers (public API) | Locked Trends query |",
        "|---|-------|---------|--------------------------|---------------------|",
    ]
    for i, r in enumerate(rows, 1):
        handle = r["youtube_handle"] or r["channel_id"]
        lines.append(
            f"| {i} | {r['brand']} | [{handle}]({r['youtube_url']}) | {r['subscriber_count']} | `{r['locked_trends_query']}` |"
        )
    lines += [
        "",
        "## Per-brand YouTube sample and notes",
        "",
    ]
    for r in rows:
        lines.append(f"### {r['brand']}")
        lines.append("")
        lines.append(f"- Lane Crawford: {r['lc_url']}")
        lines.append(f"- YouTube: {r['youtube_url']} (`{r['channel_id']}`)")
        lines.append(f"- Subscribers: {r['subscriber_count']} (public API; may be rounded)")
        lines.append(f"- Recent videos checked: {r['n_recent_videos_checked']}; likes field present on {r['n_with_likes']}; comments field present on {r['n_with_comments']}")
        lines.append(f"- Locked Trends query: `{r['locked_trends_query']}` (Worldwide, today 5-y) — {r['trends_status']}")
        lines.append(f"- {r['notes']}")
        lines.append("")
    lines += [
        "## Alternates (YouTube three-metric pass + Trends pass, not in the 30)",
        "",
        "Use these if a shortlisted brand later proves impractical to collect: Bordallo Pinheiro is already in the 30. Further dual-passes include Taittinger (`Taittinger`), Hennessy (`Hennessy`, age-gated), Elie Bleu (`Elie Bleu`), Master & Dynamic (`Master and Dynamic`), Theragun via the official Therabody channel (`Theragun`), Lomography (`Lomography`), DJI (`DJI`), SteelSeries (`SteelSeries`), Polaroid (`Polaroid`; some true-crime photo queries appear but still refer to Polaroid images), SPYRA (`Spyra`), and Focal (`Focal speakers`; do not use bare Focal).",
        "",
        "## Explicit exclusions (do not pad the 30 with these)",
        "",
        "- **LEGO** (`@LEGO`): official, subscribers and likes present, but `comment_count` was omitted on all 2,000 pulled videos and `commentThreads` returned 403 `commentsDisabled`. Henry's assigned brand; kept in the screening log, not in the 30.",
        "- **AESOP**: official-looking `@aesopskincare` (channel header links aesop.com) passed YouTube, and asgm4 used `Aesop`, but a fresh Worldwide related-query pull included Aesop Rock, Aesop's Fables, and Aesop Frontline/login alongside skincare. Excluded to avoid a Celine-type collision.",
        "- **VITRA**: official YouTube pass, but related queries mix the Swiss furniture house with Turkish VitrA bathroom ware. `Vitra furniture` still returned bathroom furniture.",
        "- **CASSINA**: official YouTube pass; bare `Cassina` related queries are led by the town Cassina de' Pecchi. `Cassina furniture` had a usable series but no related queries in the retry, so it was left unchecked and out of the 30.",
        "- **KNOLL** / `Knoll furniture`: related queries mix Parker Knoll, Walter Knoll, and Miller Knoll.",
        "- **LOEWE**: official YouTube pass; related queries include Loewe TV as well as fashion bags.",
        "- **COTOPAXI**: official YouTube pass; brand products dominate but volcano/Ecuador queries are also in the top related list.",
        "- **VISTA ALEGRE**: official YouTube pass; Trends related queries are almost all place/hotel/street names, not the porcelain brand.",
        "- **STANLEY**: official `@Stanley1913` YouTube pass; `Stanley 1913` related queries include `1913 stanley cup` (hockey), and `Stanley tumbler` still surfaces `stanley cup`.",
        "- **KODAK**: official YouTube pass; top related query is Kodak Black (the rapper).",
        "- **HOTO**: official YouTube pass; related queries mix tools with 'hoto meaning' / other-language uses.",
        "- **SAINT-LOUIS** / `Saint-Louis crystal`: series too sparse (20 of 262 weeks non-zero, mean about 3, no related queries).",
        "- **BOTTEGA VENETA**: official channel, but `likeCount` missing on the 15-video sample.",
        "- **TEENAGE ENGINEERING**: official channel, `likeCount` present on only 1 of 15 recent videos.",
        "- **VEUVE CLICQUOT**: official channel, `commentCount` missing on all 15 recent videos.",
        "- **JELLYCAT**: asgm4 Trends-OK, but no YouTube link on jellycat.com (Instagram/TikTok/Facebook/Twitter only). `@jellycatlondon` self-describes as official but was left unverified. `@JellycatOfficial` is an unrelated fan/Roblox channel.",
        "- **LOUISE ROE** and **MISETTE**: first-pass site guesses pointed at the wrong entities (a TV presenter's channel; a French auction-house channel). Not treated as official.",
        "- **LANE CRAWFORD** / **LANE CRAWFORD TRAVEL**: retailer itself, excluded by design.",
        "",
        "See `screening_log.csv` for every brand checked.",
    ]
    (OUT / "shortlist_30.md").write_text("\n".join(lines) + "\n")
    print("wrote shortlist", len(rows))
    for r in rows:
        print(r["brand"], r["youtube_handle"], r["subscriber_count"], r["locked_trends_query"])

if __name__ == "__main__":
    main()
