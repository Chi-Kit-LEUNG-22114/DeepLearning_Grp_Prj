#!/usr/bin/env python3
from __future__ import annotations
import csv
from pathlib import Path

OUT = Path("/workspace/study_notes/capstone_signals/yt_trends_screen")
fields = [
    "brand","in_live_lc_hl","youtube_status","youtube_fail_reason","youtube_url","youtube_handle",
    "channel_id","channel_title","subscriber_count","likes_ok","comments_ok",
    "n_recent_videos_checked","n_with_likes","n_with_comments","evidence_type","evidence_url",
    "locked_trends_query","trends_status","trends_reason","in_shortlist_30","notes",
]

live = {r["brand"].upper(): r for r in csv.DictReader((OUT/"lc_home_lifestyle_brands_live_2026-11-21.csv").open())}
yt = list(csv.DictReader((OUT/"screening_yt_raw.csv").open()))
short = {r["brand"] for r in csv.DictReader((OUT/"shortlist_30.csv").open())}
# trends: last status per brand, plus preferred pass query
tr_rows = list(csv.DictReader((OUT/"trends_checks.csv").open()))
# include retries
retries = []
p = OUT/"trends_retries.jsonl"
if p.exists():
    import json
    for line in p.read_text().splitlines():
        if line.strip():
            retries.append(json.loads(line))

def trend_summary(name: str):
    # map screening / LC names to trends brand keys
    aliases = {
        "TOM DIXON": "Tom Dixon", "FLOS": "Flos", "MOËT & CHANDON": "Moët & Chandon",
        "DOM PÉRIGNON": "Dom Pérignon", "JO MALONE LONDON": "Jo Malone London",
        "BANG & OLUFSEN": "Bang & Olufsen", "HERMAN MILLER": "Herman Miller",
        "FRITZ HANSEN": "Fritz Hansen", "CARL HANSEN & SØN": "Carl Hansen & Søn",
        "B&B ITALIA": "B&B Italia", "BOWERS & WILKINS": "Bowers & Wilkins",
        "MAISON FRANCIS KURKDJIAN": "Maison Francis Kurkdjian",
        "FORTNUM & MASON": "Fortnum & Mason", "THE MACALLAN": "The Macallan",
        "CLASSICON": "ClassiCon", "BORDALLO PINHEIRO": "Bordallo Pinheiro",
        "MASTER & DYNAMIC": "Master & Dynamic", "THERAGUN": "THERAGUN",
        "STEELSERIES": "Steelseries",
    }
    key = aliases.get(name.upper(), name)
    # title case fallback
    cands = [r for r in tr_rows if r["brand"].upper() == key.upper() or r["brand"].upper()==name.upper()]
    # retries
    ret = [r for r in retries if r.get("brand","").upper() in {key.upper(), name.upper()} and not r.get("error")]
    # prefer a human-reviewed pass
    # special overrides
    overrides = {
        "MOËT & CHANDON": ("Moet Chandon", "pass", "related queries are champagne after retry"),
        "BACCARAT": ("Baccarat crystal", "pass", "related queries are crystal products; bare Baccarat fails (casino/perfume)"),
        "AESOP": ("Aesop", "fail", "related queries include Aesop Rock, Aesop's Fables, and Frontline/login as well as skincare"),
        "VITRA": ("Vitra", "fail", "related queries mix Swiss furniture with Turkish VitrA bathroom ware; Vitra furniture still showed bathroom furniture"),
        "CASSINA": ("Cassina", "fail", "bare name led by Cassina de' Pecchi town; Cassina furniture related queries unavailable"),
        "KNOLL": ("Knoll furniture", "fail", "related queries mix Parker Knoll, Walter Knoll, and Miller Knoll"),
        "LOEWE": ("Loewe", "fail", "related queries include Loewe TV as well as fashion"),
        "COTOPAXI": ("Cotopaxi", "fail", "volcano/Ecuador queries appear in top related list alongside brand products"),
        "VISTA ALEGRE": ("Vista Alegre", "fail", "related queries are almost all place/hotel/street names"),
        "STANLEY": ("Stanley 1913", "fail", "Stanley 1913 related includes 1913 stanley cup; Stanley tumbler still surfaces stanley cup"),
        "KODAK": ("Kodak", "fail", "top related query is Kodak Black"),
        "HOTO": ("HOTO", "fail", "related queries mix tools with 'hoto meaning' and other-language uses"),
        "SAINT-LOUIS": ("Saint-Louis crystal", "fail", "series too sparse: 20/262 weeks non-zero, mean ~3, no related queries"),
        "ST. LOUIS LIGHTING": ("Saint-Louis crystal", "fail", "same crystal house as SAINT-LOUIS; Trends series too sparse"),
    }
    if name.upper() in overrides:
        return overrides[name.upper()]
    passes = [r for r in cands if r["status"]=="pass"]
    if passes:
        p0=passes[0]
        return p0["query"], "pass", p0["reason"]
    if cands:
        last=cands[-1]
        return last["query"], last["status"], last["reason"]
    return "", "not_checked", "Trends not run for this brand"

rows_out = []
seen=set()

def add(rec):
    b=rec["brand"].strip()
    key=b.upper()
    if key in seen:
        return
    seen.add(key)
    rec.setdefault("in_live_lc_hl", "yes" if key in live or b.upper() in live else "no")
    # live keys are exact
    rec["in_live_lc_hl"] = "yes" if b.upper() in {x.upper() for x in live} else rec.get("in_live_lc_hl","no")
    rec["in_shortlist_30"] = "yes" if b.upper() in short else "no"
    rows_out.append(rec)

# prior five
prior_notes = {
    "LEGO": dict(youtube_status="fail", youtube_fail_reason="comments_missing", youtube_url="https://www.youtube.com/@LEGO", youtube_handle="@LEGO", channel_id="UCP-Ng5SXUEt0VE-TXqRdL6g", channel_title="LEGO", subscriber_count="22000000", likes_ok="yes", comments_ok="no", n_recent_videos_checked="15", n_with_likes="15", n_with_comments="0", evidence_type="prior_official_pull", evidence_url="https://www.lego.com/en-us/aboutus", locked_trends_query="", trends_status="not_checked", trends_reason="", notes="Official @LEGO. comment_count omitted on all 2,000 videos in the 20 Nov 2026 official pull; commentThreads 403 commentsDisabled. Henry's assigned brand; not in the 30."),
    "TOM DIXON": dict(youtube_status="pass", youtube_fail_reason="", youtube_url="https://www.youtube.com/@tomdixonstudio", youtube_handle="@tomdixonstudio", channel_id="UCYFvC_53VNaaONDneGnLlXg", channel_title="Tom Dixon", subscriber_count="1670", likes_ok="yes", comments_ok="yes", n_recent_videos_checked="6", n_with_likes="6", n_with_comments="6", evidence_type="prior_official_pull", evidence_url="https://www.tomdixon.net/", notes="Prior official pull 20 Nov 2026 HKT."),
    "FLOS": dict(youtube_status="pass", youtube_fail_reason="", youtube_url="https://www.youtube.com/@flosofficialchannel", youtube_handle="@flosofficialchannel", channel_id="UCC51A913fgRpiQMdyesY9Tg", channel_title="Flos Worldwide", subscriber_count="3410", likes_ok="yes", comments_ok="yes", n_recent_videos_checked="15", n_with_likes="15", n_with_comments="15", evidence_type="prior_official_pull", evidence_url="https://www.flos.com/", notes="Prior official pull; sample of 15 most recent of 23 window videos, all had both fields (all 23 did)."),
    "MOËT & CHANDON": dict(youtube_status="pass", youtube_fail_reason="", youtube_url="https://www.youtube.com/@moet", youtube_handle="@moet", channel_id="UCJ8WERTOF24KMoDlh1ntqiQ", channel_title="Moët & Chandon Official", subscriber_count="10800", likes_ok="yes", comments_ok="yes", n_recent_videos_checked="15", n_with_likes="15", n_with_comments="15", evidence_type="prior_official_pull", evidence_url="https://www.moet.com/", notes="Prior official pull. Age-gated alcohol brand."),
    "DOM PÉRIGNON": dict(youtube_status="pass", youtube_fail_reason="", youtube_url="https://www.youtube.com/@domperignonofficial", youtube_handle="@domperignonofficial", channel_id="UCjcOmBKPKzAT6aPPTpKpbKQ", channel_title="Dom Pérignon", subscriber_count="13200", likes_ok="yes", comments_ok="yes", n_recent_videos_checked="15", n_with_likes="15", n_with_comments="15", evidence_type="prior_official_pull", evidence_url="https://www.domperignon.com/", notes="Prior official pull. Official-site HTML backlink was not found; channel title matches. Age-gated alcohol brand."),
}
for brand, d in prior_notes.items():
    q, st, reason = trend_summary(brand)
    rec={"brand": brand, **d, "locked_trends_query": q or d.get("locked_trends_query",""), "trends_status": st, "trends_reason": reason}
    if brand=="LEGO":
        rec["locked_trends_query"]=""; rec["trends_status"]="not_checked"; rec["trends_reason"]="Not required for shortlist after YouTube comments fail"
    add(rec)

# API screened
for r in yt:
    brand=r["brand"].strip()
    q, st, reason = trend_summary(brand)
    # special official fails
    notes=r.get("notes") or ""
    ystatus=r.get("youtube_status")
    yreason=r.get("youtube_fail_reason") or ""
    if brand.upper()=="MISETTE":
        ystatus,yreason="fail","wrong_channel"
        notes="Extracted YouTube channel is Boischaut SAS auction house, not the LC lifestyle brand. Not official."
    if brand.upper()=="LOUISE ROE":
        ystatus,yreason="fail","wrong_channel"
        notes="louiseroe.com is the TV presenter Front Roe blog, not Louise Roe Copenhagen; channel is the presenter's."
    rec=dict(
        brand=brand,
        youtube_status=ystatus,
        youtube_fail_reason=yreason,
        youtube_url=r.get("youtube_url") or r.get("youtube_url_input") or "",
        youtube_handle=r.get("youtube_handle") or "",
        channel_id=r.get("channel_id") or "",
        channel_title=r.get("channel_title") or "",
        subscriber_count=r.get("subscriber_count") or "",
        likes_ok=r.get("likes_ok") or "",
        comments_ok=r.get("comments_ok") or "",
        n_recent_videos_checked=r.get("n_recent_videos_checked") or "",
        n_with_likes=r.get("n_with_likes") or "",
        n_with_comments=r.get("n_with_comments") or "",
        evidence_type=r.get("evidence_type") or "",
        evidence_url=r.get("evidence_url") or "",
        locked_trends_query=q,
        trends_status=st,
        trends_reason=reason,
        notes=notes,
    )
    add(rec)

# Jellycat (checked, no official backlink)
add(dict(
    brand="JELLYCAT",
    youtube_status="unverified",
    youtube_fail_reason="no_official_site_backlink",
    youtube_url="https://www.youtube.com/@jellycatlondon",
    youtube_handle="@jellycatlondon",
    channel_id="UCt0IBbOg8uq2rSdM2S36dsA",
    channel_title="Jellycat",
    subscriber_count="117000",
    likes_ok="", comments_ok="", n_recent_videos_checked="", n_with_likes="", n_with_comments="",
    evidence_type="self_described_only",
    evidence_url="https://jellycat.com/",
    locked_trends_query="Jellycat",
    trends_status="pass",
    trends_reason="asgm4 Worldwide Trends used Jellycat successfully; YouTube official status not verified (site lists IG/TikTok/FB/Twitter only). @JellycatOfficial is an unrelated Roblox/fan channel.",
    notes="Not treated as a YouTube pass. Metrics not collected.",
))

# write
# fill missing keys
for rec in rows_out:
    for f in fields:
        rec.setdefault(f, "")
with (OUT/"screening_log.csv").open("w", newline="") as f:
    w=csv.DictWriter(f, fieldnames=fields)
    w.writeheader()
    w.writerows([{k: rec.get(k,"") for k in fields} for rec in rows_out])
print("screening_log rows", len(rows_out), "shortlisted", sum(1 for r in rows_out if r["in_shortlist_30"]=="yes"))
print("yt pass", sum(1 for r in rows_out if r["youtube_status"]=="pass"))
print("yt fail", sum(1 for r in rows_out if r["youtube_status"]=="fail"))
print("yt unverified", sum(1 for r in rows_out if r["youtube_status"]=="unverified"))
