# YouTube public dataset — STAT6207 LC Home & Lifestyle shortlist (YouTube Data API v3)

Collected 2026-11-21 01:25:16 HKT, with the official YouTube Data API v3 and an API key sent only in the x-goog-api-key header. The key is not stored in this folder.

This pull covers the 30-brand verified shortlist in `../shortlist_30.csv`. Public metadata snapshot, not YouTube Analytics.

## Method

- Channels: `channels.list` with `part=snippet,statistics,contentDetails,brandingSettings`
- Uploads: `playlistItems.list` on each channel's uploads playlist, newest first
- Video metrics: `videos.list` with `part=snippet,statistics,contentDetails,status`
- Video window: published on or after 2023-11-21 UTC, newest first, cap of 2000 videos per channel
- Comment sample (optional): videos published on or after 2025-11-21 UTC, up to 30 newest videos per channel, one page of up to 100 newest top-level threads plus any replies in the same response
- Estimated quota units used for this whole task (screening + collection): 922 of a 5000-unit task cap

## Coverage

- Channels written: 30
- Videos written: 2873
- Comment rows written: 1677

- TOM DIXON: 6 videos in window (listed 7), comments=0 from 0 videos, reached_cutoff=True, truncated_at_cap=False
- FLOS: 23 videos in window (listed 24), comments=0 from 0 videos, reached_cutoff=True, truncated_at_cap=False
- MOËT & CHANDON: 48 videos in window (listed 49), comments=8 from 25 videos, reached_cutoff=True, truncated_at_cap=False
- DOM PÉRIGNON: 19 videos in window (listed 20), comments=0 from 2 videos, reached_cutoff=True, truncated_at_cap=False
- JO MALONE LONDON: 118 videos in window (listed 119), comments=36 from 30 videos, reached_cutoff=True, truncated_at_cap=False
- BUCCELLATI: 87 videos in window (listed 88), comments=25 from 30 videos, reached_cutoff=True, truncated_at_cap=False
- MAISON MARGIELA: 33 videos in window (listed 34), comments=364 from 22 videos, reached_cutoff=True, truncated_at_cap=False
- BANG & OLUFSEN: 145 videos in window (listed 146), comments=37 from 30 videos, reached_cutoff=True, truncated_at_cap=False
- HERMAN MILLER: 33 videos in window (listed 34), comments=11 from 6 videos, reached_cutoff=True, truncated_at_cap=False
- FRITZ HANSEN: 36 videos in window (listed 37), comments=0 from 2 videos, reached_cutoff=True, truncated_at_cap=False
- CARL HANSEN & SØN: 157 videos in window (listed 158), comments=2 from 30 videos, reached_cutoff=True, truncated_at_cap=False
- B&B ITALIA: 17 videos in window (listed 18), comments=1 from 7 videos, reached_cutoff=True, truncated_at_cap=False
- ARTEMIDE: 4 videos in window (listed 5), comments=0 from 0 videos, reached_cutoff=True, truncated_at_cap=False
- LOUIS POULSEN: 74 videos in window (listed 75), comments=12 from 30 videos, reached_cutoff=True, truncated_at_cap=False
- KARTELL: 59 videos in window (listed 60), comments=1 from 18 videos, reached_cutoff=True, truncated_at_cap=False
- DEVIALET: 106 videos in window (listed 107), comments=156 from 19 videos, reached_cutoff=True, truncated_at_cap=False
- BOWERS & WILKINS: 52 videos in window (listed 53), comments=114 from 13 videos, reached_cutoff=True, truncated_at_cap=False
- SENNHEISER: 613 videos in window (listed 614), comments=406 from 30 videos, reached_cutoff=True, truncated_at_cap=False
- CHRISTOFLE: 64 videos in window (listed 65), comments=7 from 21 videos, reached_cutoff=True, truncated_at_cap=False
- FORNASETTI: 9 videos in window (listed 10), comments=0 from 2 videos, reached_cutoff=True, truncated_at_cap=False
- MAISON FRANCIS KURKDJIAN: 55 videos in window (listed 56), comments=35 from 30 videos, reached_cutoff=True, truncated_at_cap=False
- TOM FORD: 103 videos in window (listed 103), comments=166 from 30 videos, reached_cutoff=True, truncated_at_cap=False
- FORTNUM & MASON: 428 videos in window (listed 429), comments=273 from 30 videos, reached_cutoff=True, truncated_at_cap=False
- THE MACALLAN: 19 videos in window (listed 20), comments=13 from 4 videos, reached_cutoff=True, truncated_at_cap=False
- RUINART: 3 videos in window (listed 4), comments=0 from 3 videos, reached_cutoff=True, truncated_at_cap=False
- LASVIT: 45 videos in window (listed 46), comments=5 from 26 videos, reached_cutoff=True, truncated_at_cap=False
- BACCARAT: 285 videos in window (listed 286), comments=1 from 30 videos, reached_cutoff=True, truncated_at_cap=False
- JURA: 219 videos in window (listed 220), comments=2 from 30 videos, reached_cutoff=True, truncated_at_cap=False
- CLASSICON: 3 videos in window (listed 4), comments=0 from 3 videos, reached_cutoff=True, truncated_at_cap=False
- BORDALLO PINHEIRO: 10 videos in window (listed 11), comments=2 from 6 videos, reached_cutoff=True, truncated_at_cap=False

## Errors

- 2026-11-21 01:26:46 HKT: commentThreads status=403 reason=commentsDisabled brand=B&B ITALIA params=None message=The video identified by the <code><a href="/youtube/data/reference/rest/v3/commentThreads/list#videoId">videoId</a></code> parameter has disabled comments.
- 2026-11-21 01:26:47 HKT: commentThreads status=403 reason=commentsDisabled brand=B&B ITALIA params=None message=The video identified by the <code><a href="/youtube/data/reference/rest/v3/commentThreads/list#videoId">videoId</a></code> parameter has disabled comments.
- 2026-11-21 01:26:47 HKT: commentThreads status=403 reason=commentsDisabled brand=B&B ITALIA params=None message=The video identified by the <code><a href="/youtube/data/reference/rest/v3/commentThreads/list#videoId">videoId</a></code> parameter has disabled comments.
- 2026-11-21 01:26:47 HKT: commentThreads status=403 reason=commentsDisabled brand=B&B ITALIA params=None message=The video identified by the <code><a href="/youtube/data/reference/rest/v3/commentThreads/list#videoId">videoId</a></code> parameter has disabled comments.
- 2026-11-21 01:26:47 HKT: commentThreads status=403 reason=commentsDisabled brand=B&B ITALIA params=None message=The video identified by the <code><a href="/youtube/data/reference/rest/v3/commentThreads/list#videoId">videoId</a></code> parameter has disabled comments.
- 2026-11-21 01:26:47 HKT: commentThreads status=403 reason=commentsDisabled brand=B&B ITALIA params=None message=The video identified by the <code><a href="/youtube/data/reference/rest/v3/commentThreads/list#videoId">videoId</a></code> parameter has disabled comments.
- 2026-11-21 01:26:54 HKT: commentThreads status=403 reason=commentsDisabled brand=KARTELL params=None message=The video identified by the <code><a href="/youtube/data/reference/rest/v3/commentThreads/list#videoId">videoId</a></code> parameter has disabled comments.
- 2026-11-21 01:26:55 HKT: commentThreads status=403 reason=commentsDisabled brand=KARTELL params=None message=The video identified by the <code><a href="/youtube/data/reference/rest/v3/commentThreads/list#videoId">videoId</a></code> parameter has disabled comments.
- 2026-11-21 01:26:56 HKT: commentThreads status=403 reason=commentsDisabled brand=KARTELL params=None message=The video identified by the <code><a href="/youtube/data/reference/rest/v3/commentThreads/list#videoId">videoId</a></code> parameter has disabled comments.
- 2026-11-21 01:26:57 HKT: commentThreads status=403 reason=commentsDisabled brand=KARTELL params=None message=The video identified by the <code><a href="/youtube/data/reference/rest/v3/commentThreads/list#videoId">videoId</a></code> parameter has disabled comments.
- 2026-11-21 01:26:57 HKT: commentThreads status=403 reason=commentsDisabled brand=KARTELL params=None message=The video identified by the <code><a href="/youtube/data/reference/rest/v3/commentThreads/list#videoId">videoId</a></code> parameter has disabled comments.
- 2026-11-21 01:26:57 HKT: commentThreads status=403 reason=commentsDisabled brand=KARTELL params=None message=The video identified by the <code><a href="/youtube/data/reference/rest/v3/commentThreads/list#videoId">videoId</a></code> parameter has disabled comments.
- 2026-11-21 01:26:57 HKT: commentThreads status=403 reason=commentsDisabled brand=KARTELL params=None message=The video identified by the <code><a href="/youtube/data/reference/rest/v3/commentThreads/list#videoId">videoId</a></code> parameter has disabled comments.
- 2026-11-21 01:26:57 HKT: commentThreads status=403 reason=commentsDisabled brand=KARTELL params=None message=The video identified by the <code><a href="/youtube/data/reference/rest/v3/commentThreads/list#videoId">videoId</a></code> parameter has disabled comments.
- 2026-11-21 01:27:21 HKT: commentThreads status=403 reason=commentsDisabled brand=FORNASETTI params=None message=The video identified by the <code><a href="/youtube/data/reference/rest/v3/commentThreads/list#videoId">videoId</a></code> parameter has disabled comments.
- 2026-11-21 01:27:21 HKT: commentThreads status=403 reason=commentsDisabled brand=FORNASETTI params=None message=The video identified by the <code><a href="/youtube/data/reference/rest/v3/commentThreads/list#videoId">videoId</a></code> parameter has disabled comments.
- 2026-11-21 01:27:29 HKT: commentThreads status=403 reason=commentsDisabled brand=MAISON FRANCIS KURKDJIAN params=None message=The video identified by the <code><a href="/youtube/data/reference/rest/v3/commentThreads/list#videoId">videoId</a></code> parameter has disabled comments.
- 2026-11-21 01:27:29 HKT: commentThreads status=403 reason=commentsDisabled brand=MAISON FRANCIS KURKDJIAN params=None message=The video identified by the <code><a href="/youtube/data/reference/rest/v3/commentThreads/list#videoId">videoId</a></code> parameter has disabled comments.
- 2026-11-21 01:27:54 HKT: commentThreads status=403 reason=commentsDisabled brand=LASVIT params=None message=The video identified by the <code><a href="/youtube/data/reference/rest/v3/commentThreads/list#videoId">videoId</a></code> parameter has disabled comments.
- 2026-11-21 01:28:07 HKT: commentThreads status=403 reason=commentsDisabled brand=CLASSICON params=None message=The video identified by the <code><a href="/youtube/data/reference/rest/v3/commentThreads/list#videoId">videoId</a></code> parameter has disabled comments.
