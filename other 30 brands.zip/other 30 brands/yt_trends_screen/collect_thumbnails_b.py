#!/usr/bin/env python3
"""Download official YouTube channel + recent-video thumbnails and draw contact sheets.

Uses YouTube Data API v3 channels.list (snippet) and playlistItems for video IDs.
Video images are fetched from i.ytimg.com. The API key is never written or printed.
Quota is tracked only in quota_units_b.json (first-round quota_units.json is left untouched).
"""
from __future__ import annotations

import csv
import json
import re
import sys
import time
import unicodedata
from io import BytesIO
from pathlib import Path

import requests
from PIL import Image, ImageDraw, ImageFont

SCREEN = Path("/workspace/study_notes/capstone_signals/yt_trends_screen")
sys.path.insert(0, str(SCREEN))
import youtube_api_client as yac  # noqa: E402

# Do not touch first-round quota_units.json.
yac.QUOTA_PATH = SCREEN / "quota_units_b.json"
yac.TASK_QUOTA_CAP = 2000

from youtube_api_client import YouTubeClient, now_hkt  # noqa: E402

UA = "Mozilla/5.0 (compatible; STAT6207-research/1.0)"
FONT = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
FONT_BOLD = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"


def slug(brand: str) -> str:
    s = unicodedata.normalize("NFKD", brand)
    s = "".join(c for c in s if not unicodedata.combining(c))
    s = s.replace("&", " and ").replace("'", "").replace(":", " ")
    s = s.lower()
    s = re.sub(r"[^a-z0-9]+", "_", s).strip("_")
    return s


def best_channel_thumb(snippet: dict) -> str:
    thumbs = (snippet or {}).get("thumbnails") or {}
    for key in ("high", "medium", "default", "standard", "maxres"):
        url = (thumbs.get(key) or {}).get("url")
        if url:
            return url
    return ""


def download(url: str, dest: Path, timeout: int = 25) -> bool:
    try:
        r = requests.get(url, headers={"User-Agent": UA, "Accept": "image/*"}, timeout=timeout)
        if r.status_code != 200 or not r.content or len(r.content) < 50:
            return False
        ctype = (r.headers.get("Content-Type") or "").lower()
        if "html" in ctype:
            return False
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(r.content)
        # sanity: open as image
        try:
            im = Image.open(BytesIO(r.content))
            im.load()
        except Exception:
            dest.unlink(missing_ok=True)
            return False
        return True
    except requests.RequestException:
        return False


def download_video_thumb(video_id: str, dest: Path) -> tuple[str, bool]:
    """Try official i.ytimg.com sizes; skip the 120x90 missing-maxres placeholder."""
    names = ["maxresdefault.jpg", "sddefault.jpg", "hqdefault.jpg", "mqdefault.jpg", "default.jpg"]
    for name in names:
        url = f"https://i.ytimg.com/vi/{video_id}/{name}"
        tmp = dest.with_suffix(".tmp")
        if not download(url, tmp):
            continue
        try:
            im = Image.open(tmp)
            w, h = im.size
        except Exception:
            tmp.unlink(missing_ok=True)
            continue
        # YouTube serves a 120x90 placeholder when a size is missing.
        if w <= 120 and h <= 90 and name != "default.jpg":
            tmp.unlink(missing_ok=True)
            continue
        tmp.replace(dest)
        return url, True
    return "", False


def channels_by_ids(client: YouTubeClient, ids: list[str]) -> dict[str, dict]:
    out: dict[str, dict] = {}
    for i in range(0, len(ids), 50):
        chunk = ids[i : i + 50]
        data = client._get(
            "channels",
            {"part": "snippet,contentDetails", "id": ",".join(chunk)},
        )
        raw_path = SCREEN / "channels_snippet_b.jsonl"
        with raw_path.open("a") as f:
            # Do not write any request URL or key. Store only response items + timestamp.
            rec = {
                "retrieved_at_hkt": now_hkt(),
                "n_ids": len(chunk),
                "http_error": data.get("_error") or "",
                "items": data.get("items") or [],
            }
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
        for item in data.get("items") or []:
            cid = item.get("id") or ""
            if cid:
                out[cid] = item
        time.sleep(0.05)
    return out


def most_recent_video_id(client: YouTubeClient, uploads_id: str) -> tuple[str, dict]:
    if not uploads_id:
        return "", {}
    data = client.playlist_items(uploads_id, max_results=5)
    items = data.get("items") or []
    for it in items:
        vid = ((it.get("contentDetails") or {}).get("videoId")) or (
            ((it.get("snippet") or {}).get("resourceId") or {}).get("videoId")
        )
        if vid:
            return vid, it
    return "", {}


def load_shortlist(path: Path) -> tuple[list[str], list[dict]]:
    with path.open() as f:
        rows = list(csv.DictReader(f))
    fields = list(rows[0].keys()) if rows else []
    return fields, rows


def write_csv(path: Path, fields: list[str], rows: list[dict]) -> None:
    with path.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)


def fit_label(draw: ImageDraw.ImageDraw, text: str, font_path: str, max_w: int, start: int = 18) -> ImageFont.FreeTypeFont:
    for size in range(start, 9, -1):
        font = ImageFont.truetype(font_path, size)
        bbox = draw.textbbox((0, 0), text, font=font)
        if bbox[2] - bbox[0] <= max_w:
            return font
    return ImageFont.truetype(font_path, 10)


def wrap_label(text: str, font: ImageFont.FreeTypeFont, draw: ImageDraw.ImageDraw, max_w: int) -> list[str]:
    words = text.split()
    if not words:
        return [""]
    lines: list[str] = []
    cur = words[0]
    for w in words[1:]:
        trial = cur + " " + w
        bbox = draw.textbbox((0, 0), trial, font=font)
        if bbox[2] - bbox[0] <= max_w:
            cur = trial
        else:
            lines.append(cur)
            cur = w
    lines.append(cur)
    return lines[:2]


def draw_contact_sheet(
    items: list[dict],
    dest: Path,
    title: str,
    image_key: str,
) -> None:
    """16:9 sheet, 6x5 grid of 30 labelled thumbnails. Plain text only."""
    W, H = 1920, 1080
    cols, rows_n = 6, 5
    title_h = 56
    margin = 16
    canvas = Image.new("RGB", (W, H), (245, 245, 243))
    draw = ImageDraw.Draw(canvas)
    title_font = ImageFont.truetype(FONT_BOLD, 26)
    sub_font = ImageFont.truetype(FONT, 14)
    draw.rectangle([0, 0, W, title_h], fill=(28, 28, 28))
    draw.text((24, 14), title, font=title_font, fill=(250, 250, 250))
    cell_w = (W - margin * 2) // cols
    cell_h = (H - title_h - margin) // rows_n
    label_h = 40
    thumb_box = min(cell_w - 24, cell_h - label_h - 16)
    for idx, item in enumerate(items[:30]):
        r, c = divmod(idx, cols)
        # wait, we want row-major: idx // cols is row, idx % cols is col
        row, col = divmod(idx, cols)
        x0 = margin + col * cell_w
        y0 = title_h + row * cell_h
        # cell background
        draw.rounded_rectangle(
            [x0 + 6, y0 + 6, x0 + cell_w - 6, y0 + cell_h - 6],
            radius=10,
            fill=(255, 255, 255),
            outline=(220, 220, 218),
        )
        path = item.get(image_key) or ""
        tx = x0 + (cell_w - thumb_box) // 2
        ty = y0 + 12
        if path and Path(path).exists():
            try:
                im = Image.open(path).convert("RGB")
                im.thumbnail((thumb_box, thumb_box), Image.Resampling.LANCZOS)
                px = x0 + (cell_w - im.width) // 2
                py = ty + (thumb_box - im.height) // 2
                canvas.paste(im, (px, py))
            except Exception:
                draw.rectangle([tx, ty, tx + thumb_box, ty + thumb_box], fill=(230, 230, 228))
                draw.text((tx + 16, ty + thumb_box // 2 - 8), "missing", font=sub_font, fill=(90, 90, 90))
        else:
            draw.rectangle([tx, ty, tx + thumb_box, ty + thumb_box], fill=(230, 230, 228))
            draw.text((tx + 16, ty + thumb_box // 2 - 8), "missing", font=sub_font, fill=(90, 90, 90))
        label = item["brand"]
        font = fit_label(draw, label, FONT, cell_w - 20, 16)
        wrapped = wrap_label(label, font, draw, cell_w - 20)
        ly = y0 + 12 + thumb_box + 4
        for i, line in enumerate(wrapped):
            bbox = draw.textbbox((0, 0), line, font=font)
            lw = bbox[2] - bbox[0]
            draw.text((x0 + (cell_w - lw) // 2, ly + i * (bbox[3] - bbox[1] + 2)), line, font=font, fill=(30, 30, 30))
    dest.parent.mkdir(parents=True, exist_ok=True)
    canvas.save(dest, "PNG")
    print("wrote contact sheet", dest, dest.stat().st_size)


def process_shortlist_b(client: YouTubeClient) -> list[dict]:
    fields, rows = load_shortlist(SCREEN / "shortlist_30_b.csv")
    logs = {r["brand"]: r for r in csv.DictReader((SCREEN / "screening_log.csv").open())}
    ids = [r["channel_id"] for r in rows if r.get("channel_id")]
    print("channels.list for", len(ids), "shortlist B ids", flush=True)
    chmap = channels_by_ids(client, ids)
    out_dir_c = SCREEN / "thumbnails_b" / "channel"
    out_dir_v = SCREEN / "thumbnails_b" / "video"
    out_dir_c.mkdir(parents=True, exist_ok=True)
    out_dir_v.mkdir(parents=True, exist_ok=True)
    raw_pl = SCREEN / "playlist_items_b.jsonl"
    if raw_pl.exists():
        raw_pl.unlink()

    for r in rows:
        brand = r["brand"]
        cid = r["channel_id"]
        sl = slug(brand)
        item = chmap.get(cid) or {}
        snippet = item.get("snippet") or {}
        curl = best_channel_thumb(snippet)
        cpath = out_dir_c / f"{sl}_{cid}.jpg"
        cok = download(curl, cpath) if curl else False
        r["channel_thumbnail_url"] = curl if cok else (curl or "")
        r["channel_thumbnail_path"] = str(cpath) if cok else ""
        if not cok:
            print(f"  missing channel thumb: {brand}", flush=True)

        uploads = ((item.get("contentDetails") or {}).get("relatedPlaylists") or {}).get("uploads") or ""
        if not uploads:
            uploads = (logs.get(brand) or {}).get("uploads_playlist_id") or ""
        # screening_log may not have uploads; screening_yt_raw does
        vid, pl_item = most_recent_video_id(client, uploads) if uploads else ("", {})
        with raw_pl.open("a") as f:
            f.write(
                json.dumps(
                    {
                        "brand": brand,
                        "channel_id": cid,
                        "uploads_playlist_id": uploads,
                        "video_id": vid,
                        "retrieved_at_hkt": now_hkt(),
                    },
                    ensure_ascii=False,
                )
                + "\n"
            )
        r["video_id"] = vid
        if vid:
            vpath = out_dir_v / f"{sl}_{vid}.jpg"
            vurl, vok = download_video_thumb(vid, vpath)
            r["video_thumbnail_url"] = vurl if vok else ""
            r["video_thumbnail_path"] = str(vpath) if vok else ""
            if not vok:
                print(f"  missing video thumb: {brand} {vid}", flush=True)
        else:
            r["video_thumbnail_url"] = ""
            r["video_thumbnail_path"] = ""
            print(f"  missing video id: {brand}", flush=True)
        time.sleep(0.05)

    write_csv(SCREEN / "shortlist_30_b.csv", fields, rows)
    print("updated shortlist_30_b.csv with thumbnail columns; units_used=", client.units_used, flush=True)
    return rows


def process_first30(client: YouTubeClient) -> list[dict]:
    ch_rows = list(csv.DictReader((SCREEN / "youtube_data_api" / "channels.csv").open()))
    vid_rows = list(csv.DictReader((SCREEN / "youtube_data_api" / "videos.csv").open()))
    sl_rows = list(csv.DictReader((SCREEN / "shortlist_30.csv").open()))
    order = [r["brand"] for r in sl_rows]
    by_ch = {r["brand"]: r for r in ch_rows}
    # most recent public video per brand
    latest: dict[str, dict] = {}
    for v in vid_rows:
        b = v["brand"]
        if b not in latest or (v.get("published_at") or "") > (latest[b].get("published_at") or ""):
            latest[b] = v
    ids = [by_ch[b]["channel_id"] for b in order if b in by_ch]
    print("channels.list for", len(ids), "first-30 ids", flush=True)
    chmap = channels_by_ids(client, ids)
    out_dir_c = SCREEN / "thumbnails_a" / "channel"
    out_dir_v = SCREEN / "thumbnails_a" / "video"
    out_dir_c.mkdir(parents=True, exist_ok=True)
    out_dir_v.mkdir(parents=True, exist_ok=True)
    sidecar = []
    for brand in order:
        ch = by_ch[brand]
        cid = ch["channel_id"]
        sl = slug(brand)
        item = chmap.get(cid) or {}
        curl = best_channel_thumb(item.get("snippet") or {})
        cpath = out_dir_c / f"{sl}_{cid}.jpg"
        cok = download(curl, cpath) if curl else False
        if not cok:
            print(f"  missing first30 channel thumb: {brand}", flush=True)
        v = latest.get(brand) or {}
        vid = v.get("video_id") or ""
        vurl, vok = "", False
        vpath_s = ""
        if vid:
            vpath = out_dir_v / f"{sl}_{vid}.jpg"
            vurl, vok = download_video_thumb(vid, vpath)
            vpath_s = str(vpath) if vok else ""
            if not vok:
                print(f"  missing first30 video thumb: {brand} {vid}", flush=True)
        else:
            print(f"  missing first30 video id: {brand}", flush=True)
        sidecar.append(
            {
                "brand": brand,
                "channel_id": cid,
                "youtube_url": ch.get("channel_url") or "",
                "youtube_handle": ch.get("handle") or "",
                "channel_thumbnail_url": curl if cok else (curl or ""),
                "channel_thumbnail_path": str(cpath) if cok else "",
                "video_id": vid,
                "video_title": v.get("title") or "",
                "video_published_at": v.get("published_at") or "",
                "video_thumbnail_url": vurl if vok else "",
                "video_thumbnail_path": vpath_s,
            }
        )
        time.sleep(0.03)
    fields = list(sidecar[0].keys())
    write_csv(SCREEN / "thumbnails_a" / "first30_thumbnails.csv", fields, sidecar)
    print("wrote thumbnails_a/first30_thumbnails.csv; units_used=", client.units_used, flush=True)
    return sidecar


def main() -> int:
    # Need uploads playlist IDs for shortlist B from screening_yt_raw
    raw = {r["brand"]: r for r in csv.DictReader((SCREEN / "screening_yt_raw.csv").open())}
    # stash on a module-level via screening_log merge in process
    # We'll attach uploads onto a helper file if missing from API response
    # (channels.list contentDetails should already return uploads)
    client = YouTubeClient(reserve_for_collection=0)
    print("quota file", yac.QUOTA_PATH, "start_units", client.units_used, "cap", yac.TASK_QUOTA_CAP, flush=True)
    if yac.QUOTA_PATH.resolve() == (SCREEN / "quota_units.json").resolve():
        raise SystemExit("refusing to use first-round quota_units.json")
    rows_b = process_shortlist_b(client)
    # attach uploads from screening_yt_raw if a video was missing
    missing_vid = [r for r in rows_b if not r.get("video_id")]
    if missing_vid:
        print("retry missing video ids from screening_yt_raw uploads", flush=True)
        fields, rows = load_shortlist(SCREEN / "shortlist_30_b.csv")
        by = {r["brand"]: r for r in rows}
        for r in missing_vid:
            uploads = (raw.get(r["brand"]) or {}).get("uploads_playlist_id") or ""
            vid, _ = most_recent_video_id(client, uploads) if uploads else ("", {})
            if not vid:
                continue
            sl = slug(r["brand"])
            vpath = SCREEN / "thumbnails_b" / "video" / f"{sl}_{vid}.jpg"
            vurl, vok = download_video_thumb(vid, vpath)
            by[r["brand"]]["video_id"] = vid
            by[r["brand"]]["video_thumbnail_url"] = vurl if vok else ""
            by[r["brand"]]["video_thumbnail_path"] = str(vpath) if vok else ""
        write_csv(SCREEN / "shortlist_30_b.csv", fields, [by[r["brand"]] for r in rows_b])
        fields, rows_b = load_shortlist(SCREEN / "shortlist_30_b.csv")

    rows_a = process_first30(client)
    draw_contact_sheet(
        rows_b,
        SCREEN / "thumbnails_b" / "shortlist_30_b_channel_thumbs.png",
        "Shortlist B — official YouTube channel thumbnails (30 brands)",
        "channel_thumbnail_path",
    )
    draw_contact_sheet(
        rows_b,
        SCREEN / "thumbnails_b" / "shortlist_30_b_video_thumbs.png",
        "Shortlist B — most recent public video thumbnails (30 brands)",
        "video_thumbnail_path",
    )
    draw_contact_sheet(
        rows_a,
        SCREEN / "thumbnails_a" / "shortlist_30_a_channel_thumbs.png",
        "Shortlist A — official YouTube channel thumbnails (first 30 brands)",
        "channel_thumbnail_path",
    )
    draw_contact_sheet(
        rows_a,
        SCREEN / "thumbnails_a" / "shortlist_30_a_video_thumbs.png",
        "Shortlist A — most recent public video thumbnails (first 30 brands)",
        "video_thumbnail_path",
    )
    print("DONE units_used", client.units_used, "remaining", yac.TASK_QUOTA_CAP - client.units_used, flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
